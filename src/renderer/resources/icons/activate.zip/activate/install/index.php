<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8"/>
  <title>Install - LicenseBox</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="../assets/css/material.css" />
  <link rel="stylesheet" href="../assets/css/custom.css" />
  <link rel="stylesheet" href="../assets/vendor/FontAwesome/css/all.min.css"/>
  <link rel="icon" type="image/png" href="../assets/images/favicon-32x32.png" sizes="32x32"/>
  <link rel="icon" type="image/png" href="../assets/images/favicon-16x16.png" sizes="16x16"/>
</head>
<body>
  <?php 
    require "install.php";
  ?>
 <div class="content has-text-centered p-b-sm">
  <p>
   Copyright <?php echo date('Y'); ?> <a href="https://www.licensebox.app" style="color: inherit;" target="_blank" rel="noopener">CodeMonks</a>, All rights reserved.
  </p>
 </div>
</body>
</html>