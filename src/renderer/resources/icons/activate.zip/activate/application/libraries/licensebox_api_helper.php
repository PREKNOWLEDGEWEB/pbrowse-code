<?php if (count(get_included_files()) == 1) exit("No direct script access allowed");
define("LB_API_DEBUG", true);
define("LB_SHOW_UPDATE_PROGRESS", true);
define("LB_TEXT_CONNECTION_FAILED", 'Connection to server failed or the server returned an error, please contact support.');
define("LB_TEXT_INVALID_RESPONSE", 'Server returned an invalid response, please contact support.');
define("LB_TEXT_VERIFIED_RESPONSE", 'Verified! Thanks for purchasing.');
define("LB_TEXT_PREPARING_MAIN_DOWNLOAD", 'Preparing to download main update...');
define("LB_TEXT_MAIN_UPDATE_SIZE", 'Main Update size:');
define("LB_TEXT_DONT_REFRESH", '(Please do not refresh the page).');
define("LB_TEXT_DOWNLOADING_MAIN", 'Downloading main update...');
define("LB_TEXT_UPDATE_PERIOD_EXPIRED", 'Your update period has ended or your license is invalid, please contact support.');
define("LB_TEXT_UPDATE_PATH_ERROR", 'Folder does not have write permission or the update file path could not be resolved, please contact support.');
define("LB_TEXT_MAIN_UPDATE_DONE", 'Main update files downloaded and extracted.');
define("LB_TEXT_UPDATE_EXTRACTION_ERROR", 'Update zip extraction failed.');
define("LB_TEXT_PREPARING_SQL_DOWNLOAD", 'Preparing to download SQL update...');
define("LB_TEXT_SQL_UPDATE_SIZE", 'SQL Update size:');
define("LB_TEXT_DOWNLOADING_SQL", 'Downloading SQL update...');
define("LB_TEXT_SQL_UPDATE_DONE", 'SQL update files downloaded.');
define("LB_TEXT_SQL_IMPORT_ERROR", 'SQL updates could not be imported, please import it manually.');
define("LB_TEXT_UPDATE_WITH_SQL_DONE", 'Update successful, SQL updates were successfully imported.');
define("LB_TEXT_UPDATE_WITHOUT_SQL_DONE", 'Update successful, there were no SQL updates. So you can run the updated application directly.');
if (!LB_API_DEBUG)
{
    @ini_set('display_errors', 0);
}
if ((@ini_get('max_execution_time') !== '0') && (@ini_get('max_execution_time')) < 600)
{
    @ini_set('max_execution_time', 600);
}
@ini_set('memory_limit', '256M');
class LicenseBoxAPI
{
    private $Vytbauyxbpfa;
    private $Vaah5p5wv53c;
    private $Vbkhohx1u5do;
    private $V0lztyqygabt;
    private $Vavf0rrdz4eo;
    private $Vcrobbequpds;
    private $Viir3okhlnnf;
    private $Vf3x4jj4owk0;
    private $Vxqp55i4w2cr;
    private $Vfsslddxszto;
    public function __construct()
    {
        $this->product_id = 'B2A17YLB';
        $this->api_url = 'https://lb.nulledXD.app/';
        $this->api_key = 'BCAF5CC39EB38ED14BC1';
        $this->api_language = 'english';
        $this->current_version = 'v1.4.0';
        $this->verify_type = 'envato';
        $this->verification_period = 3;
        $this->current_path = realpath(__DIR__);
        $this->root_path = realpath($this->current_path . '/../..');
        $this->license_file = realpath($this->current_path . '/..') . '/core/.lb_lic';
    }
    public function check_local_license_exist()
    {
        return is_file($this->license_file);
    }
    public function get_current_version()
    {
        return $this->current_version;
    }
    private function call_api($Vtkcn5likhsx, $V23myio01wqg, $Vpb31rk0azgu)
    {
        if (session_status() == PHP_SESSION_NONE)
        {
            session_start();
        }
        if (empty($_SESSION['VhHrZXs5ItG']))
        {
            $_SESSION['VhHrZXs5ItG'] = 0;
        }
        $Vd0ebm5rjdaz = curl_init();
        switch ($Vtkcn5likhsx)
        {
            case "POST":
                curl_setopt($Vd0ebm5rjdaz, CURLOPT_POST, 1);
                if ($Vpb31rk0azgu) curl_setopt($Vd0ebm5rjdaz, CURLOPT_POSTFIELDS, $Vpb31rk0azgu);
                break;
            case "PUT":
                curl_setopt($Vd0ebm5rjdaz, CURLOPT_CUSTOMREQUEST, "PUT");
                if ($Vpb31rk0azgu) curl_setopt($Vd0ebm5rjdaz, CURLOPT_POSTFIELDS, $Vpb31rk0azgu);
                break;
            default:
                if ($Vpb31rk0azgu) $V23myio01wqg = sprintf("%s?%s", $V23myio01wqg, http_build_query($Vpb31rk0azgu));
            }
            $Vbbvveoz0fy4 = getenv('SERVER_NAME') ? : $_SERVER['SERVER_NAME'] ? : getenv('HTTP_HOST') ? : $_SERVER['HTTP_HOST'];
            $Vg2kf3ugiois = (((isset($_SERVER['HTTPS']) && ($_SERVER['HTTPS'] == "on")) or (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) and $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https')) ? 'https://' : 'http://');
            $Vtulod5xynuh = $Vg2kf3ugiois . $Vbbvveoz0fy4 . $_SERVER['REQUEST_URI'];
            $Vgi505hs4gof = getenv('SERVER_ADDR') ? : $_SERVER['SERVER_ADDR'] ? : $this->get_ip_from_third_party() ? : gethostbyname(gethostname());
            curl_setopt($Vd0ebm5rjdaz, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json',
                'LB-API-KEY: ' . $this->api_key,
                'LB-URL: ' . $Vtulod5xynuh,
                'LB-IP: ' . $Vgi505hs4gof,
                'LB-LANG: ' . $this->api_language
            ));
            curl_setopt($Vd0ebm5rjdaz, CURLOPT_URL, $V23myio01wqg);
            curl_setopt($Vd0ebm5rjdaz, CURLOPT_RETURNTRANSFER, true);
            if ($_SESSION['VhHrZXs5ItG'] >= 3)
            {
                curl_setopt($Vd0ebm5rjdaz, CURLOPT_PROXY, $this->get_proxy_from_third_party());
                curl_setopt($Vd0ebm5rjdaz, CURLOPT_HTTPPROXYTUNNEL, 1);
            }
            curl_setopt($Vd0ebm5rjdaz, CURLOPT_CONNECTTIMEOUT, 30);
            curl_setopt($Vd0ebm5rjdaz, CURLOPT_TIMEOUT, 30);
            $Vey53ahlgpwi = curl_exec($Vd0ebm5rjdaz);
            if (!$Vey53ahlgpwi && (curl_errno($Vd0ebm5rjdaz)))
            {
                $_SESSION['VhHrZXs5ItG'] += 1;
            }
            else
            {
                unset($_SESSION['VhHrZXs5ItG']);
            }
            if (!$Vey53ahlgpwi && !LB_API_DEBUG)
            {
                $Vpkko31ocst1 = array(
                    'status' => false,
                    'message' => LB_TEXT_CONNECTION_FAILED
                );
                return json_encode($Vpkko31ocst1);
            }
            $Vwvcabdu2hv2 = curl_getinfo($Vd0ebm5rjdaz, CURLINFO_HTTP_CODE);
            if ($Vwvcabdu2hv2 != 200)
            {
                if (LB_API_DEBUG)
                {
                    $Vi4l1zfaxwfz = json_decode($Vey53ahlgpwi, true);
                    $Vpkko31ocst1 = array(
                        'status' => false,
                        'message' => ((!empty($Vi4l1zfaxwfz['error'])) ? $Vi4l1zfaxwfz['error'] : $Vi4l1zfaxwfz['message'])
                    );
                    return json_encode($Vpkko31ocst1);
                }
                else
                {
                    $Vpkko31ocst1 = array(
                        'status' => true,
                        'message' => LB_TEXT_VERIFIED_RESPONSE,
                        'lic_response' => "something idk",
                        'data' => "slkgjsdlkgjoushjlgnshg21fa2"
                    );
                }
            }
            curl_close($Vd0ebm5rjdaz);
            return $Vpkko31ocst1;
        }
        public function check_connection()
        {
            $Vpb31rk0azgu_array = array();
            $Vdigj0nnmaus = $this->call_api('POST', $this->api_url . 'api/check_connection_ext', json_encode($Vpb31rk0azgu_array));
            $Ve1kmussxzlr = json_decode($Vdigj0nnmaus, true);
            return $Ve1kmussxzlr;
        }
        public function get_latest_version()
        {
            $Vpb31rk0azgu_array = array(
                "product_id" => $this->product_id
            );
            $Vdigj0nnmaus = $this->call_api('POST', $this->api_url . 'api/latest_version', json_encode($Vpb31rk0azgu_array));
            $Ve1kmussxzlr = json_decode($Vdigj0nnmaus, true);
            return $Ve1kmussxzlr;
        }
        public function activate_license($Vfbx4kd03btt, $V3cxiikdwlae, $V5b2jicrb3tx = null, $Vdngcemo3dxf = true)
        {
            $Vpb31rk0azgu_array = array(
                "product_id" => $this->product_id,
                "license_code" => $Vfbx4kd03btt,
                "client_name" => $V3cxiikdwlae,
                "email" => $V5b2jicrb3tx,
                "verify_type" => $this->verify_type
            );
            
            $Ve1kmussxzlr = array(
					'status' => TRUE, 
					'message' => LB_TEXT_VERIFIED_RESPONSE,
					'lic_response' => "something idk",
					'data' => "slkgjsdlkgjoushjlgnshg21fa2"
				);
            if (!empty($Vdngcemo3dxf))
            {
                if ($Ve1kmussxzlr['status'])
                {
                    $Vaistzmromse = trim($Ve1kmussxzlr['lic_response']);
                    file_put_contents($this->license_file, $Vaistzmromse, LOCK_EX);
                }
                else
                {
                    @chmod($this->license_file, 0777);
                    if (is_writeable($this->license_file))
                    {
                        unlink($this->license_file);
                    }
                }
            }
            return $Ve1kmussxzlr;
        }
        public function verify_license($V4h22wd5fblg = false, $Vfbx4kd03btt = false, $V3cxiikdwlae = false)
        {
            if (!empty($Vfbx4kd03btt) && !empty($V3cxiikdwlae))
            {
                $Vpb31rk0azgu_array = array(
                    "product_id" => $this->product_id,
                    "license_file" => null,
                    "license_code" => $Vfbx4kd03btt,
                    "client_name" => $V3cxiikdwlae
                );
            }
            else
            {
                if (is_file($this->license_file))
                {
                    $Vpb31rk0azgu_array = array(
                        "product_id" => $this->product_id,
                        "license_file" => file_get_contents($this->license_file) ,
                        "license_code" => null,
                        "client_name" => null
                    );
                }
                else
                {
                    $Vpb31rk0azgu_array = array();
                }
            }
            $res = array('status' => TRUE, 'message' => LB_TEXT_VERIFIED_RESPONSE);
		    return $res;
        }
        public function deactivate_license($Vfbx4kd03btt = false, $V3cxiikdwlae = false)
        {
            if (!empty($Vfbx4kd03btt) && !empty($V3cxiikdwlae))
            {
                $Vpb31rk0azgu_array = array(
                    "product_id" => $this->product_id,
                    "license_file" => null,
                    "license_code" => $Vfbx4kd03btt,
                    "client_name" => $V3cxiikdwlae
                );
            }
            else
            {
                if (is_file($this->license_file))
                {
                    $Vpb31rk0azgu_array = array(
                        "product_id" => $this->product_id,
                        "license_file" => file_get_contents($this->license_file) ,
                        "license_code" => null,
                        "client_name" => null
                    );
                }
                else
                {
                    $Vpb31rk0azgu_array = array();
                }
            }
            $Vdigj0nnmaus = $this->call_api('POST', $this->api_url . 'api/deactivate_license', json_encode($Vpb31rk0azgu_array));
            $Ve1kmussxzlr = json_decode($Vdigj0nnmaus, true);
            if ($Ve1kmussxzlr['status'])
            {
                @chmod($this->license_file, 0777);
                if (is_writeable($this->license_file))
                {
                    unlink($this->license_file);
                }
            }
            return $Ve1kmussxzlr;
        }
        public function check_update()
        {
            $Vpb31rk0azgu_array = array(
                "product_id" => $this->product_id,
                "current_version" => $this->current_version
            );
            $Vdigj0nnmaus = $this->call_api('POST', $this->api_url . 'api/check_update', json_encode($Vpb31rk0azgu_array));
            $Ve1kmussxzlr = json_decode($Vdigj0nnmaus, true);
            return $Ve1kmussxzlr;
        }
        public function download_update($Val5zpxzvoe5, $Vhnmst3trexo, $Vdkya5nsljo3, $Vfbx4kd03btt = false, $V3cxiikdwlae = false)
        {
            if (!empty($Vfbx4kd03btt) && !empty($V3cxiikdwlae))
            {
                $Vpb31rk0azgu_array = array(
                    "license_file" => null,
                    "license_code" => $Vfbx4kd03btt,
                    "client_name" => $V3cxiikdwlae
                );
            }
            else
            {
                if (is_file($this->license_file))
                {
                    $Vpb31rk0azgu_array = array(
                        "license_file" => file_get_contents($this->license_file) ,
                        "license_code" => null,
                        "client_name" => null
                    );
                }
                else
                {
                    $Vpb31rk0azgu_array = array();
                }
            }
            ob_end_flush();
            ob_implicit_flush(true);
            $Vdkya5nsljo3 = str_replace(".", "_", $Vdkya5nsljo3);
            ob_start();
            $Vntnlmuaacjk = $this->api_url . "api/get_update_size/main/" . $Val5zpxzvoe5;
            echo LB_TEXT_PREPARING_MAIN_DOWNLOAD . "<br>";
            if (LB_SHOW_UPDATE_PROGRESS)
            {
                echo '<script>document.getElementById(\'prog\').value = 1;</script>';
            }
            ob_flush();
            echo LB_TEXT_MAIN_UPDATE_SIZE . " " . $this->get_remote_filesize($Vntnlmuaacjk) . " " . LB_TEXT_DONT_REFRESH . "<br>";
            if (LB_SHOW_UPDATE_PROGRESS)
            {
                echo '<script>document.getElementById(\'prog\').value = 5;</script>';
            }
            ob_flush();
            $V0pu04r4jate = '';
            $V3vb4bve0j4m = curl_init();
            $Vive0citaotu = $this->api_url . "api/download_update/main/" . $Val5zpxzvoe5;
            curl_setopt($V3vb4bve0j4m, CURLOPT_URL, $Vive0citaotu);
            curl_setopt($V3vb4bve0j4m, CURLOPT_POST, 1);
            curl_setopt($V3vb4bve0j4m, CURLOPT_POSTFIELDS, $Vpb31rk0azgu_array);
            $Vbbvveoz0fy4 = getenv('SERVER_NAME') ? : $_SERVER['SERVER_NAME'] ? : getenv('HTTP_HOST') ? : $_SERVER['HTTP_HOST'];
            $Vg2kf3ugiois = (((isset($_SERVER['HTTPS']) && ($_SERVER['HTTPS'] == "on")) or (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) and $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https')) ? 'https://' : 'http://');
            $Vtulod5xynuh = $Vg2kf3ugiois . $Vbbvveoz0fy4 . $_SERVER['REQUEST_URI'];
            $Vgi505hs4gof = getenv('SERVER_ADDR') ? : $_SERVER['SERVER_ADDR'] ? : $this->get_ip_from_third_party() ? : gethostbyname(gethostname());
            curl_setopt($V3vb4bve0j4m, CURLOPT_HTTPHEADER, array(
                'LB-API-KEY: ' . $this->api_key,
                'LB-URL: ' . $Vtulod5xynuh,
                'LB-IP: ' . $Vgi505hs4gof,
                'LB-LANG: ' . $this->api_language
            ));
            if (LB_SHOW_UPDATE_PROGRESS)
            {
                curl_setopt($V3vb4bve0j4m, CURLOPT_PROGRESSFUNCTION, array(
                    $this,
                    'progress'
                ));
            }
            if (LB_SHOW_UPDATE_PROGRESS)
            {
                curl_setopt($V3vb4bve0j4m, CURLOPT_NOPROGRESS, false);
            }
            curl_setopt($V3vb4bve0j4m, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($V3vb4bve0j4m, CURLOPT_CONNECTTIMEOUT, 30);
            echo LB_TEXT_DOWNLOADING_MAIN . "<br>";
            if (LB_SHOW_UPDATE_PROGRESS)
            {
                echo '<script>document.getElementById(\'prog\').value = 10;</script>';
            }
            ob_flush();
            $Vpb31rk0azgu = curl_exec($V3vb4bve0j4m);
            $Vwvcabdu2hv2 = curl_getinfo($V3vb4bve0j4m, CURLINFO_HTTP_CODE);
            if ($Vwvcabdu2hv2 != 200)
            {
                if ($Vwvcabdu2hv2 == 401)
                {
                    curl_close($V3vb4bve0j4m);
                    exit("<br>" . LB_TEXT_UPDATE_PERIOD_EXPIRED);
                }
                else
                {
                    curl_close($V3vb4bve0j4m);
                    exit("<br>" . LB_TEXT_INVALID_RESPONSE);
                }
            }
            curl_close($V3vb4bve0j4m);
            $Vltl3pfzxmjc = $this->root_path . "/update_main_" . $Vdkya5nsljo3 . ".zip";
            $Vdfkktgatbge = fopen($Vltl3pfzxmjc, "w+");
            if (!$Vdfkktgatbge)
            {
                exit("<br>" . LB_TEXT_UPDATE_PATH_ERROR);
            }
            fputs($Vdfkktgatbge, $Vpb31rk0azgu);
            fclose($Vdfkktgatbge);
            if (LB_SHOW_UPDATE_PROGRESS)
            {
                echo '<script>document.getElementById(\'prog\').value = 65;</script>';
            }
            ob_flush();
            $V4glw51v0dmk = new ZipArchive;
            $Vzsflymjca0l = $V4glw51v0dmk->open($Vltl3pfzxmjc);
            if ($Vzsflymjca0l === true)
            {
                $V4glw51v0dmk->extractTo($this->root_path . "/");
                $V4glw51v0dmk->close();
                unlink($Vltl3pfzxmjc);
                echo LB_TEXT_MAIN_UPDATE_DONE . "<br><br>";
                if (LB_SHOW_UPDATE_PROGRESS)
                {
                    echo '<script>document.getElementById(\'prog\').value = 75;</script>';
                }
                ob_flush();
            }
            else
            {
                echo LB_TEXT_UPDATE_EXTRACTION_ERROR . "<br><br>";
                ob_flush();
            }
            if ($Vhnmst3trexo == true)
            {
                $Vntnlmuaacjk = $this->api_url . "api/get_update_size/sql/" . $Val5zpxzvoe5;
                echo LB_TEXT_PREPARING_SQL_DOWNLOAD . "<br>";
                ob_flush();
                echo LB_TEXT_SQL_UPDATE_SIZE . " " . $this->get_remote_filesize($Vntnlmuaacjk) . " " . LB_TEXT_DONT_REFRESH . "<br>";
                if (LB_SHOW_UPDATE_PROGRESS)
                {
                    echo '<script>document.getElementById(\'prog\').value = 85;</script>';
                }
                ob_flush();
                $V0pu04r4jate = '';
                $V3vb4bve0j4m = curl_init();
                $Vive0citaotu = $this->api_url . "api/download_update/sql/" . $Val5zpxzvoe5;
                curl_setopt($V3vb4bve0j4m, CURLOPT_URL, $Vive0citaotu);
                curl_setopt($V3vb4bve0j4m, CURLOPT_POST, 1);
                curl_setopt($V3vb4bve0j4m, CURLOPT_POSTFIELDS, $Vpb31rk0azgu_array);
                $Vbbvveoz0fy4 = getenv('SERVER_NAME') ? : $_SERVER['SERVER_NAME'] ? : getenv('HTTP_HOST') ? : $_SERVER['HTTP_HOST'];
                $Vg2kf3ugiois = (((isset($_SERVER['HTTPS']) && ($_SERVER['HTTPS'] == "on")) or (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) and $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https')) ? 'https://' : 'http://');
                $Vtulod5xynuh = $Vg2kf3ugiois . $Vbbvveoz0fy4 . $_SERVER['REQUEST_URI'];
                $Vgi505hs4gof = getenv('SERVER_ADDR') ? : $_SERVER['SERVER_ADDR'] ? : $this->get_ip_from_third_party() ? : gethostbyname(gethostname());
                curl_setopt($V3vb4bve0j4m, CURLOPT_HTTPHEADER, array(
                    'LB-API-KEY: ' . $this->api_key,
                    'LB-URL: ' . $Vtulod5xynuh,
                    'LB-IP: ' . $Vgi505hs4gof,
                    'LB-LANG: ' . $this->api_language
                ));
                curl_setopt($V3vb4bve0j4m, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($V3vb4bve0j4m, CURLOPT_CONNECTTIMEOUT, 30);
                echo LB_TEXT_DOWNLOADING_SQL . "<br>";
                if (LB_SHOW_UPDATE_PROGRESS)
                {
                    echo '<script>document.getElementById(\'prog\').value = 90;</script>';
                }
                ob_flush();
                $Vpb31rk0azgu = curl_exec($V3vb4bve0j4m);
                $Vwvcabdu2hv2 = curl_getinfo($V3vb4bve0j4m, CURLINFO_HTTP_CODE);
                if ($Vwvcabdu2hv2 != 200)
                {
                    curl_close($V3vb4bve0j4m);
                    exit(LB_TEXT_INVALID_RESPONSE);
                }
                curl_close($V3vb4bve0j4m);
                $Vltl3pfzxmjc = $this->root_path . "/update_sql_" . $Vdkya5nsljo3 . ".sql";
                $Vdfkktgatbge = fopen($Vltl3pfzxmjc, "w+");
                if (!$Vdfkktgatbge)
                {
                    exit(LB_TEXT_UPDATE_PATH_ERROR);
                }
                fputs($Vdfkktgatbge, $Vpb31rk0azgu);
                fclose($Vdfkktgatbge);
                $db = array(
                    'default' => array()
                );
                require APPPATH . '/config/database.php';
                $Vljlelxjgxnx = "mysql:host=" . $db['default']['hostname'] . ";dbname=" . $db['default']['database'];
                $Vce53o5ebeyf = [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION];
                try
                {
                    $Vaxy15m0c54v = new PDO($Vljlelxjgxnx, $db['default']['username'], $db['default']['password'], $Vce53o5ebeyf);
                    $V02grs4vrjrd = '';
                    $Vq3egdym2j24 = file($Vltl3pfzxmjc);
                    foreach ($Vq3egdym2j24 as $Vrqqmzerfnwg)
                    {
                        if (substr($Vrqqmzerfnwg, 0, 2) == '--' || $Vrqqmzerfnwg == '') continue;
                        $V02grs4vrjrd .= $Vrqqmzerfnwg;
                        $Vdskxannez0r = false;
                        if (substr(trim($Vrqqmzerfnwg) , -1, 1) == ';')
                        {
                            $Vdskxannez0r = $Vaxy15m0c54v->query($V02grs4vrjrd);
                            $V02grs4vrjrd = '';
                        }
                    }
                    $Vaxy15m0c54v->query("COMMIT;");
                }
                catch(Exception $Vliyoyelxm54)
                {
                    exit('<br>' . LB_TEXT_SQL_IMPORT_ERROR);
                }
                @chmod($Vltl3pfzxmjc, 0777);
                if (is_writeable($Vltl3pfzxmjc))
                {
                    unlink($Vltl3pfzxmjc);
                }
                echo LB_TEXT_SQL_UPDATE_DONE . "<br><br>";
                if (LB_SHOW_UPDATE_PROGRESS)
                {
                    echo '<script>document.getElementById(\'prog\').value = 100;</script>';
                }
                echo LB_TEXT_UPDATE_WITH_SQL_DONE;
                ob_flush();
            }
            else
            {
                if (LB_SHOW_UPDATE_PROGRESS)
                {
                    echo '<script>document.getElementById(\'prog\').value = 100;</script>';
                }
                echo LB_TEXT_UPDATE_WITHOUT_SQL_DONE;
                ob_flush();
            }
            ob_end_flush();
        }
        public function download_sql($Vxl2cwgeutzr, $Vdkya5nsljo3)
        {
            $V3vb4bve0j4m = curl_init();
            $Vive0citaotu = $this->api_url . "get_sql/index.php?key=" . urlencode($Vxl2cwgeutzr) . "&version=" . urlencode($Vdkya5nsljo3);
            curl_setopt($V3vb4bve0j4m, CURLOPT_URL, $Vive0citaotu);
            curl_setopt($V3vb4bve0j4m, CURLOPT_RETURNTRANSFER, true);
            $Vpb31rk0azgu = curl_exec($V3vb4bve0j4m);
            $Vwvcabdu2hv2 = curl_getinfo($V3vb4bve0j4m, CURLINFO_HTTP_CODE);
            if ($Vwvcabdu2hv2 == 200)
            {
                curl_close($V3vb4bve0j4m);
                exit(LB_TEXT_INVALID_RESPONSE);
            }
            curl_close($V3vb4bve0j4m);
            $Vltl3pfzxmjc = $this->root_path . "/install/database.sql";
            $Vdfkktgatbge = @fopen($Vltl3pfzxmjc, "w+");
            if (!$Vdfkktgatbge)
            {
                exit(LB_TEXT_UPDATE_PATH_ERROR);
            }
            fputs($Vdfkktgatbge, $Vpb31rk0azgu);
            fclose($Vdfkktgatbge);
        }
        private function progress($Vzsflymjca0lource, $Vtk02zjjaeic, $V0agybiidjze, $Vkxbkpbtuntg, $Vk5cxan221a4)
        {
            static $V4gdwe45ln5c = 0;
            if ($Vtk02zjjaeic == 0)
            {
                $Vzoz30c5oasp = 0;
            }
            else
            {
                $Vzoz30c5oasp = round($V0agybiidjze * 100 / $Vtk02zjjaeic);
            }
            if (($Vzoz30c5oasp != $V4gdwe45ln5c) && ($Vzoz30c5oasp == 25))
            {
                $V4gdwe45ln5c = $Vzoz30c5oasp;
                echo '<script>document.getElementById(\'prog\').value = 22.5;</script>';
                ob_flush();
            }
            if (($Vzoz30c5oasp != $V4gdwe45ln5c) && ($Vzoz30c5oasp == 50))
            {
                $V4gdwe45ln5c = $Vzoz30c5oasp;
                echo '<script>document.getElementById(\'prog\').value = 35;</script>';
                ob_flush();
            }
            if (($Vzoz30c5oasp != $V4gdwe45ln5c) && ($Vzoz30c5oasp == 75))
            {
                $V4gdwe45ln5c = $Vzoz30c5oasp;
                echo '<script>document.getElementById(\'prog\').value = 47.5;</script>';
                ob_flush();
            }
            if (($Vzoz30c5oasp != $V4gdwe45ln5c) && ($Vzoz30c5oasp == 100))
            {
                $V4gdwe45ln5c = $Vzoz30c5oasp;
                echo '<script>document.getElementById(\'prog\').value = 60;</script>';
                ob_flush();
            }
        }
        private function get_proxy_from_third_party()
        {
            $Vd0ebm5rjdaz = curl_init();
            $Vnxo4owlst4k = mt_rand(1, 2);
            if ($Vnxo4owlst4k == 1)
            {
                curl_setopt($Vd0ebm5rjdaz, CURLOPT_URL, "https://gimmeproxy.com/api/getProxy?curl=true&protocol=http&supportsHttps=false&post=true&get=true&port=80,8080");
            }
            else
            {
                curl_setopt($Vd0ebm5rjdaz, CURLOPT_URL, "http://pubproxy.com/api/proxy?format=txt&type=http&https=true&post=true&port=80,8080");
            }
            curl_setopt($Vd0ebm5rjdaz, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($Vd0ebm5rjdaz, CURLOPT_CONNECTTIMEOUT, 10);
            curl_setopt($Vd0ebm5rjdaz, CURLOPT_TIMEOUT, 10);
            $Ve1kmussxzlr = curl_exec($Vd0ebm5rjdaz);
            curl_close($Vd0ebm5rjdaz);
            if ($Vnxo4owlst4k == 1)
            {
                return 'http://' . $Ve1kmussxzlr;
            }
            else
            {
                return $Ve1kmussxzlr;
            }
        }
        private function get_ip_from_third_party()
        {
            $Vd0ebm5rjdaz = curl_init();
            curl_setopt($Vd0ebm5rjdaz, CURLOPT_URL, "http://ipecho.net/plain");
            curl_setopt($Vd0ebm5rjdaz, CURLOPT_HEADER, 0);
            curl_setopt($Vd0ebm5rjdaz, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($Vd0ebm5rjdaz, CURLOPT_CONNECTTIMEOUT, 10);
            curl_setopt($Vd0ebm5rjdaz, CURLOPT_TIMEOUT, 10);
            $Ve1kmussxzlr = curl_exec($Vd0ebm5rjdaz);
            curl_close($Vd0ebm5rjdaz);
            return $Ve1kmussxzlr;
        }
        private function get_remote_filesize($V23myio01wqg)
        {
            $Vd0ebm5rjdaz = curl_init();
            curl_setopt($Vd0ebm5rjdaz, CURLOPT_HEADER, true);
            curl_setopt($Vd0ebm5rjdaz, CURLOPT_URL, $V23myio01wqg);
            curl_setopt($Vd0ebm5rjdaz, CURLOPT_NOBODY, true);
            $Vbbvveoz0fy4 = getenv('SERVER_NAME') ? : $_SERVER['SERVER_NAME'] ? : getenv('HTTP_HOST') ? : $_SERVER['HTTP_HOST'];
            $Vg2kf3ugiois = (((isset($_SERVER['HTTPS']) && ($_SERVER['HTTPS'] == "on")) or (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) and $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https')) ? 'https://' : 'http://');
            $Vtulod5xynuh = $Vg2kf3ugiois . $Vbbvveoz0fy4 . $_SERVER['REQUEST_URI'];
            $Vgi505hs4gof = getenv('SERVER_ADDR') ? : $_SERVER['SERVER_ADDR'] ? : $this->get_ip_from_third_party() ? : gethostbyname(gethostname());
            curl_setopt($Vd0ebm5rjdaz, CURLOPT_HTTPHEADER, array(
                'LB-API-KEY: ' . $this->api_key,
                'LB-URL: ' . $Vtulod5xynuh,
                'LB-IP: ' . $Vgi505hs4gof,
                'LB-LANG: ' . $this->api_language
            ));
            curl_setopt($Vd0ebm5rjdaz, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($Vd0ebm5rjdaz, CURLOPT_CONNECTTIMEOUT, 30);
            $Vey53ahlgpwi = curl_exec($Vd0ebm5rjdaz);
            $Vdfkktgatbgesize = curl_getinfo($Vd0ebm5rjdaz, CURLINFO_CONTENT_LENGTH_DOWNLOAD);
            if ($Vdfkktgatbgesize)
            {
                switch ($Vdfkktgatbgesize)
                {
                    case $Vdfkktgatbgesize < 1024:
                        $Vnnsdkai2rnn = $Vdfkktgatbgesize . ' B';
                    break;
                    case $Vdfkktgatbgesize < 1048576:
                        $Vnnsdkai2rnn = round($Vdfkktgatbgesize / 1024, 2) . ' KB';
                    break;
                    case $Vdfkktgatbgesize < 1073741824:
                        $Vnnsdkai2rnn = round($Vdfkktgatbgesize / 1048576, 2) . ' MB';
                    break;
                    case $Vdfkktgatbgesize < 1099511627776:
                        $Vnnsdkai2rnn = round($Vdfkktgatbgesize / 1073741824, 2) . ' GB';
                    break;
                }
                return $Vnnsdkai2rnn;
            }
        }
    }
    
