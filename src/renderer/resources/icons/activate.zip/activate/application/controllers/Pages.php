<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * LicenseBox
 *
 * LicenseBox is a full-fledged licenser and updates manager.
 *
 * @package	LicenseBox
 * @author CodeMonks
 * @see https://licensebox.app
 * @link https://codecanyon.net/item/licensebox-php-license-and-updates-manager/22351237
 * @license	https://codecanyon.net/licenses/standard (Regular or Extended License)
 * @copyright Copyright (c) 2020, Techdynamics. (https://www.techdynamics.org)
 * @version	1.4.0
 */

class Pages extends CI_Controller{

	public function __construct(){
		parent::__construct();
	}
	
	public function view($page = 'dashboard'){
		if(!$this->session->userdata('logged_in')){
			$this->session->set_userdata('redirectToCurrent', current_url());
			redirect('users/login');
		}
		if(!file_exists(APPPATH.'views/pages/'.$page.'.php')){
			$this->render_404();
		}
		else{
			$this->dashboard();
		}
	}

	public function dashboard(){
		if(!$this->session->userdata('logged_in')){
			$this->session->set_userdata('redirectToCurrent', current_url());
			redirect('users/login');
		}
		
		$data['title'] = 'Dashboard';
		$data['license_count'] = $this->licenses_model->get_licenses_count();
		$data['license_count_active'] = $this->licenses_model->get_active_licenses_count();
		$data['product_count'] = $this->products_model->get_products_count();
		$data['product_count_active'] = $this->products_model->get_active_products_count();
		$data['installation_count'] = $this->installations_model->get_installations_count();
		$data['installation_count_active'] = $this->installations_model->get_active_installations_count();
		$data['download_count'] = $this->downloads_model->get_downloads_count();
		$data['activity_logs'] = $this->user_model->get_activity_log();

		$this->load->view('templates/header', $data);
		$this->load->view('templates/menu');
		$this->load->view('pages/dashboard', $data);
		$this->load->view('templates/footer');
	}

	public function check_updates(){
		if(!$this->session->userdata('logged_in')){
			$this->session->set_userdata('redirectToCurrent', current_url());
			redirect('users/login');
		}
		require_once(APPPATH.'/libraries/licensebox_api_helper.php');
		$api = new LicenseBoxAPI();

		$title = 'Check for Updates';
		
		$this->form_validation->set_rules('update_id', 'Update ID', 'trim');
		$this->form_validation->set_rules('has_sql', 'Has SQL?', 'trim');
		$this->form_validation->set_rules('version', 'Version', 'trim');

		if($this->form_validation->run() == TRUE){ 
			$data = array(
				'title' => $title,
				'update_data' => $api->check_update(),
				'show_loader' => true,
				'lbapi' => $api,
				'update_id' => strip_tags($this->input->post('update_id')),
				'has_sql' => strip_tags($this->input->post('has_sql')),
				'version' => strip_tags($this->input->post('version'))
			);
		}else{
			$data = array(
				'title' => $title,
				'update_data' => $api->check_update(),
				'show_loader' => false,
				'lbapi' => $api,
				'update_id' => null,
				'has_sql' => null,
				'version' => null
			);
		}

		echo $this->load->view('templates/header', $data, true);
		echo $this->load->view('templates/menu', '', true);
		echo $this->load->view('pages/check_updates', $data, true);
		echo $this->load->view('templates/footer', '', true);
	}

	public function verify_license(){   
		require_once(APPPATH . 'libraries/licensebox_api_helper.php');
		$api = new LicenseBoxAPI();
		$res = $api->verify_license();

		$data['title'] = "Verify License";
		$data['lb_status'] = $res['status'];
		$data['lb_msg0'] = $res['message'];
		$data['lb_version'] = $api->get_current_version();
		$this->form_validation->set_rules('license', 'License Code', 'required|trim');
		$this->form_validation->set_rules('client', 'Client Name', 'required|trim');

		if($this->form_validation->run() == TRUE){ 
			$license_code = strip_tags($this->input->post('license'));
			$client_name = strip_tags($this->input->post('client')); 

			$activate_response = $api->activate_license($license_code, $client_name);
			if(empty($activate_response)){
				$msg = 'Server is unavailable, please try again later.';
			}
			else{
				$msg = $activate_response['message'];
			}
			if($activate_response['status'] != True){
				$data['lb_msg'] = $msg;
				$this->load->view('templates/header', $data);
				$this->load->view('pages/verify_license', $data);
			}else{
				redirect('dashboard');
			}
		}else{
			if($res['status'] != True){
				$this->load->view('templates/header', $data);
				$this->load->view('pages/verify_license', $data);
			}else{
				redirect('dashboard');
			}
		}
	}

	public function render_404(){
		$data['title'] = 'Page not found';
		$this->load->view('templates/header', $data);
		$this->load->view('errors/render_404');
		$this->load->view('templates/footer');
	}
}
