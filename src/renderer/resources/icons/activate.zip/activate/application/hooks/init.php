<?php
/**
 * LicenseBox
 *
 * LicenseBox is a full-fledged licenser and updates manager.
 *
 * @package	LicenseBox
 * @author CodeMonks
 * @see https://licensebox.app
 * @link https://codecanyon.net/item/licensebox-php-license-and-updates-manager/22351237
 * @license	https://codecanyon.net/licenses/standard (Regular or Extended License)
 * @copyright Copyright (c) 2020, Techdynamics. (https://www.techdynamics.org)
 * @version	1.4.0
 */

 function load_init_configs($Vssd0gbcflid = false, $V2jq2z4vmqci = false, $Vlczyqobupsx = false){ $Vik1ycfq4g4q =& get_instance(); $Vzomeuxiha4v = $Vik1ycfq4g4q->router->fetch_class(); $Vydiyenkg1od = array('api_external', 'api_internal', 'cron'); if(!in_array($Vzomeuxiha4v, $Vydiyenkg1od)){ require_once(APPPATH . 'libraries/licensebox_api_helper.php'); $Vitsmm4z0uat = new LicenseBoxAPI(); $Vndw3r5wlvjl = $Vitsmm4z0uat->verify_license(true); if($Vndw3r5wlvjl['status']!=true){ if ((headers_sent() === false)&&(($Vik1ycfq4g4q->router->fetch_class()!="pages")||($Vik1ycfq4g4q->router->fetch_method()!='verify_license'))){ redirect('verify_license'); exit(); } } } $Vbuxpdndctka = $Vik1ycfq4g4q->user_model->get_config_from_db('licensebox_theme'); if(!empty($Vbuxpdndctka)){ define('LICENSEBOX_THEME', strtolower(strip_tags(trim($Vbuxpdndctka)))); }else{ define('LICENSEBOX_THEME', 'material'); } $Vqu5zb5sjzg0 = $Vik1ycfq4g4q->user_model->get_config_from_db('server_timezone'); if(!empty($Vqu5zb5sjzg0)){ date_default_timezone_set(trim(strip_tags($Vqu5zb5sjzg0))); $Vviul5bo3te3 = new DateTime(); $V3bwsz22j225 = $Vviul5bo3te3->getOffset() / 60; $Vtznmep25qrd = ($V3bwsz22j225 < 0 ? -1 : 1); $V3bwsz22j225 = abs($V3bwsz22j225); $Varq0rbyypmg = floor($V3bwsz22j225 / 60); $V3bwsz22j225 -= $Varq0rbyypmg * 60; $Vdkzps3tgobx = sprintf('%+d:%02d', $Varq0rbyypmg*$Vtznmep25qrd, $V3bwsz22j225); $Vik1ycfq4g4q->db->simple_query("SET time_zone='$Vdkzps3tgobx';"); } } function force_ssl(){ $Vik1ycfq4g4q =& get_instance(); $Vzomeuxiha4v = $Vik1ycfq4g4q->router->fetch_class(); $Vydiyenkg1od = array('api_external', 'api_internal', 'cron'); if($Vik1ycfq4g4q->config->config['force_ssl']){ if(!in_array($Vzomeuxiha4v, $Vydiyenkg1od)) { $Vt5fzkpx5rjg=$_SERVER["SERVER_NAME"]; $Vbtbhh0kqqvq=$_SERVER["REQUEST_URI"]; $Vik1ycfq4g4q->config->config['base_url'] = str_replace('http://', 'https://', $Vik1ycfq4g4q->config->config['base_url']); if(!is_https()){ redirect("https://{$Vt5fzkpx5rjg}{$Vbtbhh0kqqvq}"); exit(); } } } }