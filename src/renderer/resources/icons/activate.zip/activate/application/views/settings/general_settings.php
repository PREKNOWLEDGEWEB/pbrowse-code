<div class="container is-fluid main_body"> 
<div class="section" >
  <h1 class="title">
    <?php echo $title; ?>
  </h1>
<?php echo generateBreadcrumb('General Settings'); ?>
<?php if($this->session->flashdata('general_status')){
  $flash = $this->session->flashdata('general_status');
  echo '<div class="notification is-'.$flash['type'].'"><button class="delete"></button>'.$flash['message'].'</div>'; 
  if($flash['type']=='success'){
    echo '<script>setTimeout(function(){document.getElementsByClassName("notification")[0].style.display="none";},4000);</script>';
  } 
} ?>
<div class="box">
<?php 
$hidden = array('type' => 'general'); 
echo form_open('general_settings', array('id' => 'general_settings_form'), $hidden); ?>
<div class="columns" style="margin-bottom: 0px;">
<div class="column is-narrow">
  <div class="field">
    <label class="label">LicenseBox Theme</label>
    <div class="control">
      <div class="select" style="width:100%;">
        <select name="licensebox_theme" style="width:100%;" required>
          <?php if($licensebox_theme=="classic"):?>
            <option value="classic" selected>Classic</option>
            <option value="flat">Flat</option>
            <option value="material">Material</option>
          <?php elseif($licensebox_theme=="flat"): ?>
            <option value="classic">Classic</option>
            <option value="flat" selected>Flat</option>
            <option value="material">Material</option>
          <?php else: ?>
            <option value="classic">Classic</option>
            <option value="flat">Flat</option>
            <option value="material" selected>Material</option>
          <?php endif; ?>
        </select>
      </div>
    </div>
    <p class="help" style="padding-top: 4px;">Classic, Flat or Material</p>
  </div>
</div>
<div class="column">
<div class="field">
  <label class="label">License Code Format</label>
  <div class="control">
    <input class="input" type="text" name="license_format" value="<?php 
  echo $license_format; ?>" placeholder="Enter license code format" tabindex="1" required>
  </div>
  <p class="help">{[X]} = any number from 0-9, {[Y]} = any letter from a-z, {[Z]} = any number from 0-9 or letter from a-z, anything else will not be replaced.</p>
</div>
</div>
</div>
<div class="columns" style="margin-bottom: 0px;">
 <div class="column">
  <div class="field">
    <label class="label">Timezone</label>
    <div style="padding-bottom: 3px;">
      <select name="server_timezone" style="width: 100%" class="is-select2" required>
        <?php foreach(get_timezones() as $t) { ?>
          <?php if($t['zone']==$server_timezone){ ?>
            <option value="<?php echo $t['zone']; ?>" selected><?php echo $t['diff_from_GMT'] . ' - ' . $t['zone']; ?></option>
          <?php }else{ ?>
            <option value="<?php echo $t['zone'] ?>"><?php echo $t['diff_from_GMT'] . ' - ' . $t['zone'] ?></option>
          <?php } ?>
        <?php } ?>
      </select>
    </div>
    <?php echo form_error('server_timezone', '<p class="help is-danger">', '</p>'); ?>
  </div>
  <div class="field">
    <label class="label">Entries for failed activation attempts</label>
    <?php if($failed_activation_logs==1):?>
      <input class="is-checkradio is-danger" type="checkbox" name="failed_activation_logs" id="failed_activation_logs" checked>
    <?php else: ?>
      <input class="is-checkradio is-danger" type="checkbox" name="failed_activation_logs" id="failed_activation_logs">
    <?php endif; ?>
    <label for="failed_activation_logs" style="margin-left: 0px !important;">Add entries for failed activation attempts? <small class="tooltip is-tooltip-multiline is-tooltip-right " data-tooltip="Checking it will allow recording/adding of failed activations attempts, if unchecked failed attempts will be only visible in activity logs and not on activations page."><i class="fas fa-question-circle"></i></small></label>
  </div>
 </div>
  <div class="column">
    <div class="field">
      <label class="label">Envato API Token <small toggle="#envato_api_token" class="toggle-password has-text-link">(show)</small> <small class="has-text-weight-normal has-text-grey"> (<a href="https://build.envato.com/create-token/" target="_blank">Don't have a token? Create a new one here.</a>)</small></label>
      <div class="control">
        <input class="input" type="password" id="envato_api_token" name="envato_api_token" value="<?php echo $envato_api_token; ?>" placeholder="Enter your envato api token" tabindex="3">
      </div>
    </div>
    <div class="field">
      <label class="label">Entries for failed update download attempts</label>
      <?php if($failed_update_download_logs==1):?>
        <input class="is-checkradio is-danger" type="checkbox" name="failed_update_download_logs" id="failed_update_download_logs" checked>
      <?php else: ?>
        <input class="is-checkradio is-danger" type="checkbox" name="failed_update_download_logs" id="failed_update_download_logs">
      <?php endif; ?>
      <label for="failed_update_download_logs" style="margin-left: 0px !important;">Add entries for failed update download attempts? <small class="tooltip is-tooltip-multiline is-tooltip-left" data-tooltip="Checking it will allow recording/adding of failed update download attempts, if unchecked failed attempts will be only visible in activity logs and not on update downloads page."><i class="fas fa-question-circle"></i></small></label>
    </div>
  </div>
</div>
<div class="field is-grouped">
  <div class="control">
    <button type="submit" id="general_settings_form_submit" class="button is-link">Save Changes</button>
  </div>
</div>
</form>
</div>
</div>
</div>