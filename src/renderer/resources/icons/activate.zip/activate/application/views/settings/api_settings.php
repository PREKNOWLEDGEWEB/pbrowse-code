<div class="container is-fluid main_body"> 
<div class="section" >
  <h1 class="title">
    <?php echo $title; ?>
  </h1>
<?php echo generateBreadcrumb('API Settings'); ?>
<?php if($this->session->flashdata('api_settings_status')){
  $flash = $this->session->flashdata('api_settings_status');
  echo '<div class="notification is-'.$flash['type'].'"><button class="delete"></button>'.$flash['message'].'</div>'; 
  if($flash['type']=='success'){
    echo '<script>setTimeout(function(){document.getElementsByClassName("notification")[0].style.display="none";},4000);</script>';
  } 
} ?>
<div class="box">
<?php 
$hidden = array('type' => 'general'); 
echo form_open('api_settings', '', $hidden); ?>
<div class="columns">
<div class="column">
  <div class="field">
    <label class="label">Blacklist domain after how many failed attempts? <small class="tooltip is-tooltip-multiline is-tooltip-right " data-tooltip="After the specified number of failed activation and update download attempts the user's domain will get blacklisted automatically. (Note: This will only work if the LicenseBox Cron is setup correctly and 'entries for failed activation and download attempts' are allowed.)" style="font-weight: 400;"><i class="fas fa-question-circle"></i></small></label>
    <div class="control">
      <input class="input" type="number" name="auto_domain_blacklist" value="<?php
      echo $auto_domain_blacklist; ?>" placeholder="Number of failed attempts for auto domain blacklisting." min="1" tabindex="1">
    </div>
  </div>
  <div class="field">
    <label class="label">API Requests Rate Limiting Method <small class="tooltip is-tooltip-right " data-tooltip="API rate limiting can be done per API Key or per IP Address." style="font-weight: 400;"><i class="fas fa-question-circle"></i></small></label>
    <div class="control is-expanded">
      <div class="select is-fullwidth">
        <select id="api_rate_limit_method" name="api_rate_limit_method" required tabindex="3">
          <?php if($api_rate_limit_method=="api_key"):?>
            <option value="api_key" selected>Limit per API Key</option>
            <option value="ip_address">Limit per IP Address</option>
          <?php else: ?>
            <option value="api_key">Limit per API Key</option>
            <option value="ip_address" selected>Limit per IP Address</option>
          <?php endif; ?>
        </select>
      </div>
    </div>
  </div>
  <div class="field">
    <label class="label">API Blacklisted Domains <small class="tooltip is-tooltip-multiline is-tooltip-right " data-tooltip="If provided, these domains will be prevented from accessing the LicenseBox API." style="font-weight: 400;"><i class="fas fa-question-circle"></i></small></label>
    <div class="control">
      <input class="input" type="tags" name="api_blacklisted_domains" value="<?php
      if(!empty(set_value('api_blacklisted_domains'))) {
        echo set_value('api_blacklisted_domains');
      }
      else{ 
        echo $api_blacklisted_domains; 
      }
      ?>" placeholder="Domains to be blacklisted" tabindex="5">
    </div>
    <?php echo form_error('api_blacklisted_domains', '<p class="help is-danger" style="margin-top: 1rem;">', '</p>'); ?>
  </div>
</div>
<div class="column">
  <div class="field">
    <label class="label">Blacklist IP after how many failed attempts? <small class="tooltip is-tooltip-multiline is-tooltip-left " data-tooltip="After the specified number of failed activation and update download attempts the user's IP will get blacklisted automatically. (Note: This will only work if the LicenseBox Cron is setup correctly and 'entries for failed activation and download attempts' are allowed.)" style="font-weight: 400;"><i class="fas fa-question-circle"></i></small></label>
    <div class="control">
      <input class="input" type="number" name="auto_ip_blacklist" value="<?php
      echo $auto_ip_blacklist; ?>" placeholder="Number of failed attempts for auto IP blacklisting." min="1" tabindex="2">
    </div>
  </div>
  <div class="field">
    <label class="label">API Requests Rate Limit (per hour) <small class="tooltip is-tooltip-multiline is-tooltip-left " data-tooltip="Rate limiting API, allows you to limit the number of requests the API processes every hour from any specific API Key or IP Address." style="font-weight: 400;"><i class="fas fa-question-circle"></i></small></label>
    <div class="control">
      <input class="input" type="number" name="api_rate_limit" value="<?php
      echo $api_rate_limit; ?>" placeholder="Requests allowed per hour (leave empty for unlimited use)" min="1" tabindex="4">
    </div>
  </div>
  <div class="field">
    <label class="label">API Blacklisted IPs <small class="tooltip is-tooltip-multiline is-tooltip-right " data-tooltip="If provided, these IP addresses will be prevented from accessing the LicenseBox API." style="font-weight: 400;"><i class="fas fa-question-circle"></i></small></label>
    <div class="control">
      <input class="input" type="tags" name="api_blacklisted_ips" value="<?php
      if(!empty(set_value('api_blacklisted_ips'))) {
        echo set_value('api_blacklisted_ips');
      }
      else{ 
        echo $api_blacklisted_ips; 
      }
      ?>" placeholder="IPs to be blacklisted" tabindex="6">
    </div>
    <?php echo form_error('api_blacklisted_ips', '<p class="help is-danger" style="margin-top: 1rem;">', '</p>'); ?>
  </div>
</div>
</div>
<div class="field is-grouped">
  <div class="control">
    <button type="submit" class="button is-link show_loading">Save Changes</button>
  </div>
</div>
</form>
</div>
<div class="columns">
<div class="column is-one-third">
  <div class="box" name="create_api_key" id="create_api_key">
    <?php 
    $hidden = array('type' => 'api'); 
    echo form_open('api_settings', array('id' => 'api_settings_form'), $hidden); ?>
      <div class="field">
        <label class="label">API Key</label>
        <div class="control">
          <input class="input" type="text" name="api_key" minlength="10" value="<?php echo strtoupper(substr(str_shuffle(MD5(microtime())), 0, 20)); ?>" placeholder="Enter api key to add" required>
        </div>
      </div>
      <div class="field">
        <label class="label">API Key Type <small class="tooltip is-tooltip-multiline is-tooltip-right " data-tooltip="Make sure you use the right API Key for the right purpose, never use the internal API in a client-side implementation." style="font-weight: 400;"><i class="fas fa-question-circle"></i></small></label>
        <div class="control is-expanded">
          <div class="select is-fullwidth">
            <select name="api_type" required>
              <option disabled="" selected="">Select Type</option>
              <option value="external">External/Client (for your clients to verify licenses etc.)</option>
              <option value="internal">Internal (for you to add licenses etc.)</option>
            </select>
          </div>
        </div>
      </div>
      <div class="field p-t-xs">
        <input class="is-checkradio is-danger" type="checkbox" name="ignore_limits" id="ignore_limits">
        <label for="ignore_limits" style="margin-left: 0px !important;">Give special permission? <small class="tooltip is-tooltip-multiline is-tooltip-right " data-tooltip="Selecting this option will give this API key special permission to access the LicenseBox API, thus bypassing any set API restrictions (like rate limit, domain blacklist, IP blacklist etc.) useful if you don't want your personal API keys to be restricted." style="font-weight: 400;"><i class="fas fa-question-circle"></i></small></label>
      </div>
      <div class="field is-grouped p-t-xs">
        <div class="control">
          <button type="submit" id="api_settings_form_submit" class="button is-link">Add</button>
        </div>
      </div>
    </form>
  </div>
  </div>
  <div class="column">
  <div class="box">
    <table class="table nots" style="width: 100%;">
      <thead>
        <tr>
          <th>API Key</th>
          <th>Special</th>
          <th>Type</th>
          <th>Date Added</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($api_keys as $key): ?>
        <tr>
          <td><?php echo $key['key']; ?></td>
          <td><span class='tag is-light is-rounded'><?php 
              if($key['ignore_limits']){
                echo "Yes";
              }else{
                echo "No";
              } ?></span></td>
          <td><?php 
              if($key['controller']=='/api_external'){
                $key_type = "<span class='tag is-success is-rounded'>External</span>";
              }else{
                $key_type = "<span class='tag is-warning is-rounded'>Internal</span>";
              }
            echo $key_type; ?></td>
          <td><?php 
                $originalDate = $key['date_created'];
                $newDate = date($this->config->item('date_format'), strtotime($originalDate));
                echo $newDate; ?></td>
          <td><div class="buttons is-centered"><?php 
            $hidden = array('key' => $key['key']);
            $js = 'id="delete_form_'.$key['id'].'"';
            echo form_open('/settings/delete_api_key',$js, $hidden); ?>
            <button type="button"  id="api_settings_form_submit" data-id="<?php echo $key['id']; ?>" data-title="api key" data-body="Please note that all product integrations which are currently using this api key (<b><?php echo $key['key']; ?></b>) will stop working." title="Delete Api Key" class="button with-delete-confirmation is-danger is-small" style="padding-top: 0px;padding-bottom: 0px;"><i class="fa fa-trash p-r-xs"></i>Delete</button></form></div></td>
        </tr>
        <?php endforeach; ?> 
      </tbody>
    </table>
    <?php if(empty($api_keys)){ ?>
      <center><p class="p-t-sm">No data available in table</p></center>
    <?php }?>
  </div>
</div>
</div> 
</div>
</div>