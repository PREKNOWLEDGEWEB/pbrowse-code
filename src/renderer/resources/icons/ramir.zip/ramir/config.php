<?php
$conn = mysqli_connect("localhost","pritam","pritam@24","ramsir");
$union1 = strpos($_SERVER["REQUEST_URI"], "UNI");
$union8 = strpos($_SERVER["REQUEST_URI"], "uni");
$union2 = strpos($_SERVER["REQUEST_URI"], "alter");
$union3 = strpos($_SERVER["REQUEST_URI"], "table");
$union4 = strpos($_SERVER["REQUEST_URI"], "delete");
if ( $union1 !== false) {
     echo "Attack Detected";
     die();
}
if ( $union8 !== false) {
     echo "Attack Detected";
     die();
}
if ( $union2 !== false) {
     echo "Attack Detected";
     die();
}
if ( $union3 !== false) {
     echo "Attack Detected";
     die();
}
if ( $union4 !== false) {
     echo "Attack Detected";
     die();
}


define('UNDER_DEVELOPEMENT',true);

if(UNDER_DEVELOPEMENT !== true){
    if(file_exists("error_log")){
        unlink("error_log");
    }
}

