<?php
class system
{
	function getadminsession(){
		if (isset($_SESSION['admin'])) {
			return 200;
		}else{
			return 201;
		}
	}
	function getadminid(){
		if (isset($_SESSION['user_admin_id'])) {
			return $_SESSION['user_admin_id'];
		}else{
			return "er";
		}
	}
	function getadminrole(){
		if (isset($_SESSION['user_admin_id'])) {
			
              return $_SESSION['admin_role'];
		}else{
			return "er";
		}
	}
}
$self = new system();