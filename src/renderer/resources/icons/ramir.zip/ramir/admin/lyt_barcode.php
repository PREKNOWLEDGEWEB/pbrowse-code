<a class="btn btn-success" onclick="printDiv('cert')"> <i class="material-icons">print</i> Print</a>
<div id="cert">
    <style>
    table, th, td {
      border: 1px solid black;
    }
    </style>
    <script> document.getElementById('scannedbarcode').value = ""; </script>
    <!--<img src="../img/std/<?=$stdimg?>" style="width:40px; height:50px;" />-->
    <p style="margin-top:200px; margin-left:25px; font-size:20px;"><?php echo $std_name ?></p>
    <p>Father Name : <?php echo $std_father; ?></p>
    <p>Student Course : <?php echo $std_course; ?></p>
    <p>Student Enroll No. : <?php echo $std_course; ?></p>
    <table style="width:20%">
        <thead>
            <th>Subject</th>
            <th>Mark</th>
        </thead>
        <tr>
            <td>DOS</td>
            <td><?php echo $std_mark_dos; ?></td>
        </tr>
        <tr>
            <td>WIN</td>
            <td><?php echo $std_mark_win; ?></td>
        </tr>
         <tr>
            <td>Office</td>
            <td><?php echo $std_mark_office; ?></td>
        </tr>
         <tr>
            <td>DTP</td>
            <td><?php echo $std_mark_dtp; ?></td>
        </tr>
         <tr>
            <td>INT</td>
            <td><?php echo $std_mark_int; ?></td>
        </tr>
         <tr>
            <td>Tally</td>
            <td><?php echo $std_mark_tally; ?></td>
        </tr>
         <tr>
            <td>Pratical</td>
            <td><?php echo $std_mark_pratical; ?></td>
        </tr>
        <tfoot>
            <td>Subjects</td>
            <td>Total : <?php echo $std_total_mark ?> / Scored : <?php echo $std_scored_marks; ?></td>
        </tfoot>
    </table>
</div>

<script>
function printDiv(divName) {
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;
     document.body.innerHTML = printContents;
     window.print();
     document.body.innerHTML = originalContents;
}</script>