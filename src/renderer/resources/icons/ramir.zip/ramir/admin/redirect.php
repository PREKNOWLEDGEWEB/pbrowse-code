<?php
if (isset($_GET['tologin'])) {
	header("Location: login.php");
}