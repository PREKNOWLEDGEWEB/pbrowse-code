<?php
session_start();
$self = null;
$conn = null;
require ("../config.php");
require("../system.php");
require("../vendor/autoload.php");
require("../vendor/qr/phpqrcode.php");

 $qi = "
 Student Name : ".$_GET['name']." 
 Student Enroll No. : ".$_GET['roll_no']." 
 Student Father Name : ".$_GET['father']."
 Student Course : ".$_GET['caur']."
 ";

QRcode::png($qi); 