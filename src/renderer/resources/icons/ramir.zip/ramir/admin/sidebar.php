  <div class="logo">
        <a href="" class="simple-text logo-mini">
          PK
        </a>
        <a href="" class="simple-text logo-normal">
          Preknowledge
        </a>
      </div>
      <div class="sidebar-wrapper">
        <div class="user">
          <div class="photo">
            <img src="assets/img/default-avatar.png" />
          </div>
          <div class="user-info">
            <a data-toggle="collapse" href="#collapseExample" class="username">
              <span>
                <?=$_SESSION['user_admin_username']?>
                <b class="caret"></b>
              </span>
            </a>
            <div class="collapse" id="collapseExample">
              <ul class="nav">
                <?php if($self->getadminrole() == "admin"){ ?>
                <li class="nav-item">
                  <a class="nav-link" href="#">
                    <span class="sidebar-mini"> EP </span>
                    <span class="sidebar-normal"> Edit Profile </span>
                  </a>
                </li>
                <?php } ?>
              </ul>
            </div>
          </div>
        </div>
        
        <ul class="nav">
          <li class="nav-item
          <?php
          if($p == "dashboard"){
              echo "active";
          }
          ?>
          ">
            <a class="nav-link" href="dashboard">
              <i class="material-icons">dashboard</i>
              <p>Dashboard</p>
            </a>
          </li>
          <?php
          if($self->getadminrole() == "admin"){
              ?>
              <li class="nav-item
          <?php
          if($p == "institute"){
              echo "active";
          }
          ?>
          ">
            <a class="nav-link" href="institute">
              <i class="material-icons">apartment</i>
              <p>Institute</p>
            </a>
          </li>
          <?php
          }
          ?>
            <li class="nav-item
          <?php
          if($p == "students"){
              echo "active";
          }
          ?>
          ">
        
            <a class="nav-link" href="students">
              <i class="material-icons">smartphone</i>
              <p>Students</p>
            </a>
            </li>
            
            <li class="nav-item
          <?php
          if($p == "barcode_search"){
              echo "active";
          }
          ?>
          ">
        
            <a class="nav-link" href="barcode_search">
              <i class="material-icons">qr_code</i>
              <p>Barcode Search</p>
            </a>
            </li>
          <!-- your sidebar here -->
        </ul>
      </div>
    </div>
    <div class="main-panel">
     <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-transparent navbar-absolute fixed-top ">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <div class="navbar-minimize">
              <button id="minimizeSidebar" class="btn btn-just-icon btn-white btn-fab btn-round">
                <i class="material-icons text_align-center visible-on-sidebar-regular">more_vert</i>
                <i class="material-icons design_bullet-list-67 visible-on-sidebar-mini">view_list</i>
              </button>
            </div>
            <a class="navbar-brand" href="javascript:;">Dashboard</a>
          </div>
          <button class="navbar-toggler" type="button" data-toggle="collapse" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
            <span class="sr-only">Toggle navigation</span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
          </button>
          <div class="collapse navbar-collapse justify-content-end">
            <form class="navbar-form">
              
            </form>
            <ul class="navbar-nav">
              
  
             
              <li class="nav-item dropdown">
                <a class="nav-link" href="javascript:;" id="navbarDropdownProfile" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <i class="material-icons">person</i>
                  <p class="d-lg-none d-md-block">
                    Account
                  </p>
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownProfile">
                 <!--  <a class="dropdown-item" href="#">Profile</a>
                  <a class="dropdown-item" href="#">Settings</a>
                  <div class="dropdown-divider"></div> -->
                  <a class="dropdown-item" href="logout">Log out</a>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </nav>