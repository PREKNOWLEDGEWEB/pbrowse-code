<?php
session_start();
$self = null;
$conn = null;
require ("../config.php");
require("../system.php");
require("../vendor/autoload.php");
require("../vendor/qr/phpqrcode.php");
if ($self->getadminsession() == 200) {
	if (isset($_GET['page'])) {
		$p = $_GET['page'];
		if ($p == "dashboard") {
			include("dashboard.php");
		}elseif ($p == "logout") {
			unset($_SESSION['admin']);
			unset($_SESSION['user_admin_username']);
			header("Location: ./");
		}elseif ($p == "qrcode") {
			include("qr_code.php");
		}elseif ($p == "generateqr") {
		    $qi = "        Student Name : ".$_GET['name']."
		    Student Roll No. : ".$_GET['roll_no']." ";
			QRcode::png($qi); 
		}elseif ($p == "std_del") {
		    $sql = "DELETE FROM `students` WHERE `students`.`std_id` = '".$_POST['id']."'";
		    //d//ie($sql);
            if(mysqli_query($conn, $sql)){
                    $success=true;
                }else{
                    $success=false;
                }
			header("Location: ./students?suc=".$success."");
		}elseif ($p == "add_student_process") {
		    $image = $_FILES['std_image']['name'];
		    
		    $i = false;
	
		        
		        $target = "../img/std/".basename($image);
		        if (move_uploaded_file($_FILES['std_image']['tmp_name'], $target)) {
		        $barcode = rand(30 * 12,5);
                $barcode_r = rand(30 * 12,5);
                $finalbarocde =str_shuffle("".$barcode_r."".$barcode."");
                $msg = "Image uploaded successfully";
                $sql = "INSERT INTO `students` (`std_name`, `std_father_name`, `std_course`, `std_enroll_no`, `std_mark_dos`, `std_mark_win`, `std_mark_office`, `std_mark_dtp`, `std_mark_int`, `std_mark_tally`, `std_mark_pratical`, `std_total_mark`, `std_scored_marks`, `std_barcode`, `std_image`, `std_inst_id`) 
                                        VALUES ('".$_POST['std_name']."','".$_POST['std_father_name']."', '".$_POST['std_course']."', '".$_POST['std_enroll_no']."', '', '', '', '', '', '', '', '', '', '".$finalbarocde."', '".$image."', '".$_POST['inst_id']."');";
                if(mysqli_query($conn, $sql)){
                    $success=true;
                }else{
                    $success=false;
                }
                }else{
                  die("image cannot uploaded");
                }
		include("students.php");
		}elseif ($p == "institute") {
		include("inst.php");
		}elseif ($p == "generatebarcode") {
		$generator = new Picqer\Barcode\BarcodeGeneratorPNG();
        // echo '<img src="data:image/png;base64,' . base64_encode($generator->getBarcode('081231723897', $generator::TYPE_CODE_128)) . '">';
        include("generatebarcode.php");
		}elseif ($p == "barcode_search") {
		include("barcodesearch.php");
		}elseif ($p == "mark_process") {
		$id=$_POST['id'];
		$dos = $_POST['std_mark_dos'];
		$win = $_POST['std_mark_win'];
		$office = $_POST['std_mark_office'];
		$dtp = $_POST['std_mark_dtp'];
		$int = $_POST['std_mark_int'];
		$tally = $_POST['std_mark_tally'];
		$pratical = $_POST['std_mark_pratical'];
		$total = $_POST['std_total_mark'];
		$scored = $_POST['std_scored_marks'];
		if(mysqli_query($conn,"UPDATE `students` SET `std_mark_dos` = '$dos', `std_mark_win` = '$win', `std_mark_office` = '$office', `std_mark_dtp` = '$dtp', `std_mark_int` = '$int', `std_mark_tally` = '$tally', `std_mark_pratical` = '$pratical', `std_total_mark` = '$total', `std_scored_marks` = '$scored' WHERE `students`.`std_id` = $id;")){
		    header("Location: ./students");
		}else{
		    header("Location: ./students?error");
		}}elseif ($p == "marks") {
		    $sql = "select * from students where std_id = '".$_POST['id']."';";
            $rs_result = mysqli_query($conn, $sql);
            while ($row = mysqli_fetch_array($rs_result)) {
                $std_mark_dos = $row['std_mark_dos'];
                $std_mark_win = $row['std_mark_win'];
                $std_mark_office = $row['std_mark_office'];
                $std_mark_dtp = $row['std_mark_dtp'];
                $std_mark_int = $row['std_mark_int'];
                $std_mark_tally = $row['std_mark_tally'];
                $std_mark_pratical = $row['std_mark_pratical'];
                $std_total_mark = $row['std_total_mark'];
                $std_scored_marks = $row['std_scored_marks'];
            };
		include("marks.php");
		}elseif ($p == "students") {
		include("students.php");
		}elseif ($p == "addstudent") {
		  $p = "students";
		include("add_student.php");
		}elseif ($p == "addstudent") {
		  $p = "students";
		include("add_student.php");
		}elseif ($p == "add_institute_process") {
		  $p = "students";
	 $sqli = "INSERT INTO `institute` (`inst_name`, `inst_code`, `inst_email`) VALUES ('".$_POST['int_name']."', '".$_POST['int_code']."', '".$_POST['int_email']."');";
	 
	        mysqli_query($conn,"INSERT INTO `users` (`admin_name`, `admin_email`, `admin_password`, `admin_role`) VALUES ('".$_POST['int_name']."', '".$_POST['int_email']."', '".sha1($_POST['int_code'])."', 'institute');");
            if(mysqli_query($conn,$sqli)){
                $e = "0";
                include("inst.php");   
            }else{
            $e="1";
            include("inst.php"); 
            }
		}elseif ($p == "addinst") {
            $p = "institute";
            include("addinst.php");
        }elseif ($p == "delete_i") {
            $sqli = "DELETE FROM `institute` WHERE `institute`.`inst_id` = '".$_POST['id']."'";
           if(mysqli_query($conn,$sqli)){
                $de = "0";
                include("inst.php"); 
           }
        }elseif ($p == "std_edit") {
            $p = "students";

            $sql = "select * from students where std_id = '".$_POST['id']."';";
            $rs_result = mysqli_query($conn, $sql);
            while ($row = mysqli_fetch_array($rs_result)) {
                $std_name = $row['std_name'];
                $sid = $row['std_id'];
                $std_father = $row['std_father_name'];
                $std_course = $row['std_course'];
                $std_enroll_no = $row['std_enroll_no'];
                $stdimg = $row['std_image'];
            };

                include("editstudent.php");
        }elseif ($p == "getbarcode") {
            $p = "students";

            $sql = "select * from students where std_barcode = '".$_POST['barcode']."';";
         /*   
            echo $sql; */
            $rs_result = mysqli_query($conn, $sql);
            while ($row = mysqli_fetch_array($rs_result)) {
                $std_name = $row['std_name'];
                $sid = $row['std_id'];
                $std_father = $row['std_father_name'];
                $std_course = $row['std_course'];
                $std_enroll_no = $row['std_enroll_no'];
                $stdimg = $row['std_image'];
                $std_mark_dos = $row['std_mark_dos'];
                $std_mark_win = $row['std_mark_win'];
                $std_mark_office = $row['std_mark_office'];
                $std_mark_dtp = $row['std_mark_dtp'];
                $std_mark_int = $row['std_mark_int'];
                $std_mark_tally = $row['std_mark_tally'];
                $std_mark_pratical = $row['std_mark_pratical'];
                $std_total_mark = $row['std_total_mark'];
                $std_scored_marks = $row['std_scored_marks'];
                
                include("lyt_barcode.php");
            };
        }elseif ($p == "edit_std") {
            $p = "students";

            if (isset($_POST['add_std'])){
                //intialize image
                if (isset($_POST['timg'])){
                    $fimgt = $_POST['timg'];
                }else{
                    $fimg = $_FILES['std_image']['name'];
                    $fimgto = "../img/std/".basename($fimg);
                    $fimgt = basename($fimg);
                    if (move_uploaded_file($_FILES['std_image']['tmp_name'], $fimgto)) {}else{
                        die("Error");
                    }
                }
                //intialize image ends
                //initialize
                $std_id = $_POST['id'];
                $std_name = $_POST['std_name'];
                $std_father_name = $_POST['std_father_name'];
                $std_course = $_POST['std_course'];
                $std_enroll_no = $_POST['std_enroll_no'];
                // i variables
                //UPDATE `students` SET `std_name` = 'Studentzz', `std_father_name` = 'Std d', `std_course` = 'DOCTORS', `std_enroll_no` = '13213454', `std_image` = 'doct.pni' WHERE `students`.`std_id` = 3;
                $sqli = "UPDATE 
                            `students` SET 
                            `std_name` = '".$std_name."', 
                            `std_father_name` = '".$std_father_name."', 
                            `std_course` = '".$std_course."', 
                            `std_enroll_no` = '".$std_enroll_no."', 
                            `std_image` = '".$fimgt."' WHERE 
                            `students`.`std_id` = '".$std_id."';";
                            
                   
                if(mysqli_query($conn,$sqli)){
                    include("students.php");
                }else{
                    echo "Error...";
                }
            }


        }else{
			include ("404.php");
		}
	}else{
	    if($self->getadminsession() == 200){
	        $p="dashboard";
	        include("dashboard.php");
        }else {
            include("login.php");
        }
    }
}else{
	include("login.php");
}