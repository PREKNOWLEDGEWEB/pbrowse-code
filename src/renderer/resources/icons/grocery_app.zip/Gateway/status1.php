<?php
header("Pragma: no-cache");
header("Cache-Control: no-cache");
header("Expires: 0");

// following files need to be included
//require_once("./lib/config_paytm.php");
require_once("./lib/encdec_paytm.php");

$ORDER_ID = "";
$requestParamList = array();
$responseParamList = array();

$requestParamList = array("MID" => 'BISHTT45712521385572' , "ORDERID" => "ORDER200003799");  

$checkSum = getChecksumFromArray($requestParamList,'&rdeq7C4d5t%nKH%');
$requestParamList['CHECKSUMHASH'] = urlencode($checkSum);



//$requestParamList = array("MID" => 'Connec87193644974307' , "ORDERID" => "ORDER48886809917");  

//$checkSum = getChecksumFromArray($requestParamList,'yWk#zI01MvZ2uPgA');
//$requestParamList['CHECKSUMHASH'] = urlencode($checkSum);

$data_string = "JsonData=".json_encode($requestParamList);
echo $data_string;




?>