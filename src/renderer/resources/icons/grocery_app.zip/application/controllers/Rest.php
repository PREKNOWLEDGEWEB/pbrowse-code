<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Rest extends MY_Controller {
    
    private static $API_SERVER_KEY = 'AAAAZ6XzxVM:APA91bHekP2lprylw8eJRtydnfo03uAxsSRFMEx9rAxRmN3E-UyVl9d2iJbNXypRUnCugXsOsLrIff8wPzD-Me_NQ-akYBoSksO3q7Io74teiZ9sHoPuUm5-JviWF4r-cFUkE3Kt_BA1';
    private static $is_background = "TRUE";
   
    public function __construct()
    {
                parent::__construct();
                // Your own constructor code
                $this->load->database();
                $this->load->helper('login_helper');
                $this->load->helper('sms_helper');
                $this->load->helper('gcm_helper');
    }
    function index(){
        $q = $this->db->query("SELECT * FROM `resturant`");
        $data['lists'] = $q->result();
        $this->load->view("admin/resturant/list",$data);
    }
}