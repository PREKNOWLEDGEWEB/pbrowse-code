<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 
 class files extends CI_Controller
 {
 	
 	function __construct()
 	{
 		parent::__construct();
        // Your own constructor code
        $this->load->database();
        $this->load->helper('login_helper');
        $this->load->helper('sms_helper');
        $this->load->helper('gcm_helper');
        $this->load->helper('directory');
 	}

 	/* File index */
 	public function index(){

 	if($_SESSION['user_name']){
 		$this->load->view("admin/files/view");
 	}else{
 		redirect("admin");
 	}

 	}

 	public function rowfiles(){

 	if($_SESSION['user_name']){
 		if (isset($_GET['dir'])) {
 			$dir = $_GET['dir'];
 		}else{
 			$dir = "./uploads";
 		}
 		$data['dir'] = $dir;
 		if (is_dir($dir)){
		  if ($dh = opendir($dir)){
		    while (($file = readdir($dh)) !== false){
		      $data['data'][] = $file ;
		    }
		    $this->load->view("admin/files/row",$data);
		    closedir($dh);
		  }
		}else{
			header("Content-type:application/json");
			?>
			<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
			
			<a href="#" onclick="opendir('./uploads')" class="btn btn-primary" style="color: white ;">
     	    Go Back
     	    </a>
     	    <div class="w3-panel w3-card w3-light-grey"> 
                  <h4><?php echo $dir ; ?></h4>
                  <div class="w3-code jsHigh notranslate">
			<?php
			$f = file_get_contents("./".$dir."");
			echo $f;
			echo '</div>
</div>

<script src="https://www.w3schools.com/lib/w3codecolor.js"></script>';
		}
 	}else{
 		redirect("admin");
 	}

 	}

 	public function delete(){
 		$file = $this->input->get("file");
 		$unl = unlink($file);
 		if($unl){
 			echo json_encode(array("state"=>200));
 		}else{
 			echo json_encode(array("state"=>201));
 		}
 	}


 }