<?php
class Csv extends CI_Controller
{
    public $data;
    public function __construct()
    {
        parent::__construct();
        $this->load->model('csv_model');
        $this->load->helper("login_helper");
    }
    function index()
    {   
        if(_is_user_login($this)){
            $this->load->view('admin/uploadCsvView');
        }else{
            redirect("admin");
        }
    }
    function uploadData()
    {
        if(_is_user_login($this)){
        $this->csv_model->uploadData();
        redirect('csv');
        }else{
            redirect("admin");
        }
    }
    
}
?>