<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class account extends CI_Controller {

   public function __construct()
        {
                parent::__construct();
                // Your own constructor code
                date_default_timezone_set('Asia/Kolkata');
                $this->load->database();
                 $this->load->helper(array('form', 'url'));
                 $this->db->query("SET time_zone='+05:30'");
        }

  public function login()
  {
    $this->load->view('web/login');
  }

  public function login2()
  {
    $data = array(); 
            $_POST = $_REQUEST;      
                $this->load->library('form_validation');
                 $this->form_validation->set_rules('user_email', 'Email Id',  'trim|required');
                 $this->form_validation->set_rules('password', 'Password', 'trim|required');
               
                if ($this->form_validation->run() == FALSE) 
                {
                    $data["responce"] = false;  
                    $data["error"] =  strip_tags($this->form_validation->error_string());
                    
                }else
                {
                   //users.user_email='".$this->input->post('user_email')."' or
 $q = $this->db->query("Select * from registers where(user_email='".$this->input->post('user_email')."' ) and user_password='".md5($this->input->post('password'))."' Limit 1");
                    
                    
                    if ($q->num_rows() > 0)
                    {
                        $row = $q->row(); 
                        if($row->status == "0")
                        {
                                $data["responce"] = false;  
                              $data["error"] = 'Sorry , Your Account is Deactive';
                              $data["error_arb"] = 'حسابك غير نشط حاليًا. الرجاء الاتصال بالمسؤول';
                            
                        }
                       
                        else
                        {
              //                 $data["responce"] = true;  
              // $data["data"] = array("user_id"=>$row->user_id,"user_fullname"=>$row->user_fullname,
              //   "user_email"=>$row->user_email,"user_phone"=>$row->user_phone,"user_image"=>$row->user_image,"wallet"=>$row->wallet,"rewards"=>$row->rewards) ;

                          session_start();

                          $_SESSION['customerid'] = $row->user_id;
                          $_SESSION['customername'] = $row->user_fullname;
                          $_SESSION['customeremail'] = $row->user_email;

                          $_SESSION['customerphone'] = $row->user_phone;
                          $_SESSION['customerimage'] = $row->user_image;

                          redirect("home");
                               
                        }
                    }
                    else
                    {
                              $data["responce"] = false;  
                              $data["error"] = 'Invalide Username or Passwords';
                              $data["error_arb"] = 'اسم المستخدم أو كلمة المرور غير صالحة';
                    }
                   
                    
                }
           echo json_encode($data);
  }


}
