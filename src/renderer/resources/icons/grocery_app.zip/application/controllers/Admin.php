<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends MY_Controller {
    
    private static $API_SERVER_KEY = 'AAAAZ6XzxVM:APA91bHekP2lprylw8eJRtydnfo03uAxsSRFMEx9rAxRmN3E-UyVl9d2iJbNXypRUnCugXsOsLrIff8wPzD-Me_NQ-akYBoSksO3q7Io74teiZ9sHoPuUm5-JviWF4r-cFUkE3Kt_BA1';
    private static $is_background = "TRUE";
   
    public function __construct()
    {
                parent::__construct();
                // Your own constructor code
                $this->load->database();
                $this->load->helper('login_helper');
                $this->load->helper('sms_helper');
                $this->load->helper('gcm_helper');
    }
    function signout(){
        $this->session->sess_destroy();
        redirect("admin");
    }
    public function index()
    {
        // if(_is_user_login($this)){
        //     redirect(_get_user_redirect($this));
        // }else{
            
            $data = array("error"=>"");       
            if(isset($_POST))
            {
                
                $this->load->library('form_validation');
                
                $this->form_validation->set_rules('email', 'Email', 'trim|required');
                $this->form_validation->set_rules('password', 'Password', 'trim|required');
                if ($this->form_validation->run() == FALSE) 
                {
                   if($this->form_validation->error_string()!=""){
                    $data["error"] = '<div class="alert alert-warning alert-dismissible" role="alert">
                                  <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                  <strong>Warning!</strong> '.$this->form_validation->error_string().'
                                </div>';
                    }
                }else
                {
                   
                $q = $this->db->query("Select * from `users` where (`user_email`='".$this->input->post("email")."')
                 and user_password='".md5($this->input->post("password"))."' and user_login_status='1'");
                    
                   // print_r($q) ; 
                    if ($q->num_rows() > 0)
                    {
                        $row = $q->row(); 
                        if($row->user_status == "0")
                        {
                            $data["error"] = '<div class="alert alert-danger alert-dismissible" role="alert">
                                  <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                  <strong>Warning!</strong> Your account currently inactive.</div>';
                        }
                        else
                        {
                            $newdata = array(
                                                   'user_name'  => $row->user_fullname,
                                                   'user_email' => $row->user_email,
                                                   'logged_in' => TRUE,
                                                   'user_id'=>$row->user_id,
                                                   'user_type_id'=>$row->user_type_id
                                                  );
                            $this->session->set_userdata($newdata);
                            redirect(_get_user_redirect($this));
                         
                        }
                    }
                    else
                    {
                        $data["error"] = '<div class="alert alert-danger alert-dismissible" role="alert">
                                  <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                  <strong>Warning!</strong> Invalid User and password. </div>';
                    }
                   
                    
                }
            }
            else
            {
                $this->session->sess_destroy();
            }
            $data["active"] = "login";

            
            
            $this->load->view("admin/login2",$data);
        // }
    }
    public function ajaxeditstock($id){
        $this->load->model("product_model");
        if(_is_user_login($this)){
        
            if(isset($_POST['action']))
            {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('product_id', 'product_id', 'trim|required');
                $this->form_validation->set_rules('qty', 'Qty', 'trim|required');
                $this->form_validation->set_rules('unit', 'Unit', 'trim|required');
                if ($this->form_validation->run() == FALSE)
                {
                  if($this->form_validation->error_string()!="")
                      $data['res'] = false;
                      $data['missing'] = true;
                }
                else
                {
              
                    $this->load->model("common_model");
                    $array = array(
                    "product_id"=>$this->input->post("product_id"),
                    "qty"=>$this->input->post("qty"),
                    "price"=>$this->input->post("price"),
                    "unit"=>$this->input->post("unit")
                    );
                    $this->common_model->data_update("purchase",$array,array("purchase_id"=>$id));
                  $data['res'] = true ;
               //     redirect("admin/add_purchase");
                }
                 
                echo(json_encode($data));
                
            }else{
                $data["purchase"]  = $this->product_model->get_purchase_by_id($id);
                $data["products"]  = $this->product_model->get_products();
                $this->load->view("admin/product/edit_purchase2",$data);  
            }
    }
    else
    {
        $data['res'] = false;
         $data['missing'] = "session";
    }
    }
    public function login_admin()
    {
       

            if (isset($_POST)) {
            
            }else{
                echo json_encode(array('statusCode'=>'300'));
            }
                
            if(isset($_POST))
            {
                
                $this->load->library('form_validation');
                
                $this->form_validation->set_rules('email', 'Email', 'trim|required');
                $this->form_validation->set_rules('password', 'Password', 'trim|required');
                if ($this->form_validation->run() == FALSE) 
                {
                   if($this->form_validation->error_string()!=""){
                  echo json_encode(array('statusCode'=>'590'));
                    }
                }else
                {
                   
                $q = $this->db->query("Select * from `users` where (`user_email`='".$this->input->post("email")."')
                 and user_password='".md5($this->input->post("password"))."' and user_login_status='1'");
                    
                   // print_r($q) ; 
                    if ($q->num_rows() > 0)
                    {
                        $row = $q->row(); 
                        if($row->user_status == "0")
                        {
                            //inactive
                        echo  json_encode(array('statusCode'=>'205'));
                        }
                        else
                        {
                            $newdata = array(
                                                   'user_name'  => $row->user_fullname,
                                                   'user_email' => $row->user_email,
                                                   'logged_in' => TRUE,
                                                   'user_id'=>$row->user_id,
                                                   'user_type_id'=>$row->user_type_id
                                                  );
                            $this->session->set_userdata($newdata);
                        /*
                        toastr["success"]("Welcome admin", "Welcome")

                            toastr.options = {
                              "closeButton": true,
                              "debug": false,
                              "newestOnTop": true,
                              "progressBar": true,
                              "positionClass": "toast-top-right",
                              "preventDuplicates": true,
                              "onclick": null,
                              "showDuration": "300",
                              "hideDuration": "1000",
                              "timeOut": "5000",
                              "extendedTimeOut": "1000",
                              "showEasing": "swing",
                              "hideEasing": "linear",
                              "showMethod": "fadeIn",
                              "hideMethod": "fadeOut"
                            } */
                            $this->session->set_flashdata('welcome',' toastr["success"]("Welcome admin", "Welcome")

                            toastr.options = {
                              "closeButton": true,
                              "debug": false,
                              "newestOnTop": true,
                              "progressBar": true,
                              "positionClass": "toast-top-right",
                              "preventDuplicates": true,
                              "onclick": null,
                              "showDuration": "300",
                              "hideDuration": "1000",
                              "timeOut": "5000",
                              "extendedTimeOut": "1000",
                              "showEasing": "swing",
                              "hideEasing": "linear",
                              "showMethod": "fadeIn",
                              "hideMethod": "fadeOut"
                            }'); 
                           echo json_encode(array('statusCode'=>'200')); //OK
                         
                        }
                    }
                    else
                    {
                        //invalid
               echo  json_encode(array('statusCode'=>'201'));
                    }
                   
                    
                }
            }
            else
            {
                $this->session->sess_destroy();
            }
            $data["active"] = "login";
        // }
    }


    public function dashboard(){
        if(_is_user_login($this)){
            $data = array();
            $this->load->model("product_model");
            $date = date("Y-m-d");
            $data["today_orders"] = $this->product_model->get_sale_orders(" and sale.on_date = '".$date."' ");
             $nexday = date('Y-m-d', strtotime(' +1 day'));
            $data["nextday_orders"] = $this->product_model->get_sale_orders(" and sale.on_date = '".$nexday."' ");
            $this->load->view("admin/dashboard",$data);
        }
        else{
            redirect("admin");
        }
    }
    public function set_limit(){
        if(_is_user_login($this)){
            $data = array();
            $this->load->model("limit_model");
            $data["limit"] = $this->limit_model->get_lim2();
            $this->load->view("admin/limit_set",$data);
        }
        else{
            redirect("admin");
        }
    }
    public function limitupdate()
    {
    $this->load->model("limit_model");
    $result['limit']=$this->limit_model->get_lim2();
    $this->load->view('admin/limit_set',$result);
    
        if($this->input->post('upl'))
        {
        $limit=$this->input->post('limit');
        $limit2=$this->input->post('limit2');
        $this->limit_model->update($limit,$limit2);
        $this->session->set_flashdata("message",'<div class="alert alert-success alert-dismissible" role="alert">
                                  <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                  <strong>Success!</strong>Limit Setted</div>');
        redirect("admin/set_limit");
        }
    }
    public function orders(){
        if(_is_user_login($this)){
            $data = array();
            $this->load->model("product_model");
            $fromdate = date("Y-m-d");
            $todate = date("Y-m-d");
            $data['date_range_lable'] = $this->input->post('date_range_lable');
           
             $filter = "";
            if($this->input->post("date_range")!=""){
                $filter = $this->input->post("date_range");
                $dates = explode(",",$filter);                
                $fromdate =  date("Y-m-d", strtotime($dates[0]));
                $todate =  date("Y-m-d", strtotime($dates[1])); 
                $filter = " and sale.on_date >= '".$fromdate."' and sale.on_date <= '".$todate."' ";
            }
            $data["today_orders"] = $this->product_model->get_sale_orders($filter);
            
            $this->load->view("admin/orders/orderslist2",$data);
        }
        else{
            redirect("admin");
        }
    }
    public function confirm_order($order_id){
        if(_is_user_login($this)){
            $this->load->model("product_model");
            $order = $this->product_model->get_sale_order_by_id($order_id);
            if(!empty($order)){
                $this->db->query("update sale set status = 1 where sale_id = '".$order_id."'");
                 $q = $this->db->query("Select * from registers where user_id = '".$order->user_id."'");
                $user = $q->row();
                
                                $message["title"] = "Confirmed  Order";
                                $message["message"] = "Your order Number '".$order->sale_id."' confirmed successfully";
                                $message["image"] = "http://chilka.in/Grocery/images/confirm_order.png";
                                $message["created_at"] = date("Y-m-d h:i:s"); 
                                $message["obj"] = "";
                            
                            
                            $gcm = new GCM();   
                            if($user->user_gcm_code != ""){
                            $result = $gcm->sen(array($user->user_gcm_code),$message ,"android");
                            }
                             if($user->user_ios_token != ""){
                            $result = $gcm->sen(array($user->user_ios_token),$message ,"ios");
                             }
                $this->session->set_flashdata("message",'<div class="alert alert-success alert-dismissible" role="alert">
                                  <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                  <strong>Success!</strong> Order confirmed. </div>');
            }
            redirect("admin/orders");
        }
        else{
            redirect("admin");
        }
    }

    public function order_recover($order_id){
        if(_is_user_login($this)){
            $this->load->model("product_model");
            $order = $this->product_model->get_sale_order_by_id($order_id);
            if(!empty($order)){
                $this->db->query("update sale set status = 0 where sale_id = '".$order_id."'");
                 $q = $this->db->query("Select * from registers where user_id = '".$order->user_id."'");
                $user = $q->row();
                
                                $message["title"] = "Order Recovered";
                                $message["message"] = "Your order Number '".$order->sale_id."' Recovered successfully";
                                $message["image"] = "http://chilka.in/Grocery/images/recover.png";
                                $message["created_at"] = date("Y-m-d h:i:s"); 
                                $message["obj"] = "";
                            
                            $this->load->helper('gcm_helper');
                            $gcm = new GCM();   
                            if($user->user_gcm_code != ""){
                            $result = $gcm->sen(array($user->user_gcm_code),$message ,"android");
                            }
                             if($user->user_ios_token != ""){
                            $result = $gcm->sen(array($user->user_ios_token),$message ,"ios");
                             }
                $this->session->set_flashdata("message",'<div class="alert alert-success alert-dismissible" role="alert">
                                  <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                  <strong>Success!</strong> Order Recovered. </div>');
            }
            redirect("admin/orders");
        }
        else{
            redirect("admin");
        }
    }
    
    public function delivered_order($order_id){
        if(_is_user_login($this)){
            $this->load->model("product_model");
            $order = $this->product_model->get_sale_order_by_id($order_id);
            if(!empty($order)){
                $this->db->query("update sale set status = 2 where sale_id = '".$order_id."'");
                /* $this->db->query("INSERT INTO delivered_order (sale_id, user_id, on_date, delivery_time_from, delivery_time_to, status, note, is_paid, total_amount, total_rewards, total_kg, total_items, socity_id, delivery_address, location_id, delivery_charge, new_store_id, assign_to, payment_method)
                SELECT sale_id, user_id, on_date, delivery_time_from, delivery_time_to, status, note, is_paid, total_amount, total_rewards, total_kg, total_items, socity_id, delivery_address, location_id, delivery_charge, new_store_id, assign_to, payment_method FROM sale
                where sale_id = '".$order_id."'"); 

                */
                
                $q = $this->db->query("Select * from registers where user_id = '".$order->user_id."'");
                $user = $q->row();
                
                        $message["title"] = "Your order is shipping, Ready to pickup";
                        $message["message"] = "Your order Number '".$order->sale_id."' Delivered successfully. Thank you for being with us";
                        $message["image"] = "http://chilka.in/Grocery/images/confirm_order.png";
                        $message["created_at"] = date("Y-m-d h:i:s"); 
                        $message["obj"] = "";
                            
                            $this->load->helper('gcm_helper');
                            $gcm = new GCM();   
                            if($user->user_gcm_code != ""){
                            $result = $gcm->sen(array($user->user_gcm_code),$message ,"android");
                            }
                             if($user->sen != ""){
                            $result = $gcm->send_notification(array($user->user_ios_token),$message ,"ios");
                             }
                
                $this->session->set_flashdata("message",'<div class="alert alert-info alert-dismissible" role="alert">
                                  <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                  <strong>Success!</strong> Order set to Shipping. </div>');
            }
            $data["error"] = '<div class="alert alert-danger alert-dismissible" role="alert">
                                  <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                  <strong>Warning!</strong> Invalid User and password. </div>';
            redirect("admin/orders");
        }
        else{
            redirect("admin");
        }
    }

    public function paid($order_id){
         $this->db->query("update `sale` set `is_paid` = '1' where `sale`.`sale_id` = '".$order_id."';");
         $this->session->set_flashdata("message",'<div class="alert alert-success alert-dismissible" role="alert">
                                  <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                  <strong>Success!</strong> Order has been <label class="label label-success">PAID</label></div>');
         redirect("admin/orders");
    }
     public function unpaid($order_id){
         $this->db->query("update `sale` set `is_paid` = '0' where `sale`.`sale_id` = '".$order_id."';");
         $this->session->set_flashdata("message",'<div class="alert alert-success alert-dismissible" role="alert">
                                  <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                  <strong>Success!</strong> Order has been <label class="label label-danger">UNPAID</label></div>');
         redirect("admin/orders");
    }
    
    public function delivered_order_complete($order_id){
        if(_is_user_login($this)){
             $this->load->helper('gcm_helper');
            $this->load->model("product_model");
            $order = $this->product_model->get_sale_order_by_id($order_id);
            if(!empty($order)){
                $this->db->query("update sale set status = 4 where sale_id = '".$order_id."'");
                $this->db->query("INSERT INTO delivered_order (sale_id, user_id, on_date, delivery_time_from, delivery_time_to, status, note, is_paid, total_amount, total_rewards, total_kg, total_items, socity_id, delivery_address, location_id, delivery_charge, new_store_id, assign_to, payment_method)
                SELECT sale_id, user_id, on_date, delivery_time_from, delivery_time_to, status, note, is_paid, total_amount, total_rewards, total_kg, total_items, socity_id, delivery_address, location_id, delivery_charge, new_store_id, assign_to, payment_method FROM sale
                where sale_id = '".$order_id."'"); 

                
                $q = $this->db->query("Select * from registers where user_id = '".$order->user_id."'");
                $user = $q->row();
                
                $temp_refer = $user->temp_refer;
                $get_user_id = $user->user_id;
                $rfcn = $user->user_fullname;
                
             

                        $getTemprefer = $user->temp_refer;
                         //gtgt
                  
                      $q =$this->db->query("Select * from registers where temp_refer = '".$getTemprefer."';");
                      $rfff = $q->row();

                        if ($user->temp_refer == "emp") {
                        
                        }else{
                        $rmtemprefer =$this->db->query("update `registers` set `temp_refer` = 'emp' where `registers`.`user_id` = ".$get_user_id.";");
                        //add rewards processs
                        $q = $this->db->query("Select * from registers where refer_code = '".$getTemprefer."';");
                        $msq = $q->row();
                        $puid = $msq->user_id;
                        $custname = $msq->user_fullname;
                        $pwallet = $msq->wallet;
                       
                        $ptowallet = abs($pwallet+200);
                        $ptw = $this->db->query("UPDATE `registers` SET `wallet` = '".$ptowallet."' WHERE `registers`.`user_id` = ".$puid.";");
                        }
                        
                        
                        $message["title"] = "Hi ".$custname." You have Earned Rs.200 ";
                        $message["message"] = "Your earned is Rs.200 by refering ".$rfcn." ";
                        $message["image"] = "http://chilka.in/Grocery/images/confirm_order.png";
                        $message["created_at"] = date("Y-m-d h:i:s");
                        $message["obj"] = "";
                            
                           
                            $gcm = new GCM();   
                            if($user->user_gcm_code != ""){
                            $result = $gcm->sen(array($msq->user_gcm_code),$message ,"android");
                            }
                             if($user->user_ios_token != ""){
                            $result = $gcm->sen(array($msq->user_ios_token),$message ,"ios");
                             }
                    

                $q2 = $this->db->query("Select total_rewards, user_id from sale where sale_id = '".$order_id."'");
                $user2 = $q2->row();
                        
                        $rewrd_by_profile=$user->rewards;
                        $rewrd_by_order=$user2->total_rewards;

                        $new_rewards=$rewrd_by_profile+$rewrd_by_order;
                        $this->db->query("update registers set rewards = '".$new_rewards."' where user_id = '".$user2->user_id."'");

                        $message["title"] = "Thanks For Order, Waiting for your Next order.";
                        $message["message"] = "Your order Number '".$order->sale_id."' Delivered successfully. Thank you for being with us";
                        $message["image"] = "";
                        $message["created_at"] = date("Y-m-d h:i:s");
                        $message["obj"] = "";
                            
                           
                            $gcm = new GCM();   
                            if($user->user_gcm_code != ""){
                            $result = $gcm->sen(array($user->user_gcm_code),$message ,"android");
                            }
                             if($user->user_ios_token != ""){
                            $result = $gcm->sen(array($user->user_ios_token),$message ,"ios");
                             }
                
                $this->session->set_flashdata("message",'<div class="alert alert-success alert-dismissible" role="alert">
                                  <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                  <strong>Success!</strong> Order delivered. </div>');
            }
            redirect("admin/orders");
        }
        else{
            redirect("admin");
        }
    }

    public function cancle_order($order_id){
        if(_is_user_login($this)){
            $this->load->model("product_model");
            $order = $this->product_model->get_sale_order_by_id($order_id);
            $ite = $this->product_model->get_sale_order_items($order_id);
            
            foreach($ite as $dt){
            //    echo $i->product_name;
            //process
            $pr = $this->db->query("Select dp.*,products.*, ( ifnull (producation.p_qty,0)) as stock ,categories.title from products 
                          inner join categories on categories.id = products.category_id
                          left outer join(select qty as p_qty,product_id from purchase group by product_id) as producation on producation.product_id = products.product_id
                         left join deal_product dp on dp.product_id=products.product_id where products.product_id = ".$dt->product_id.";");
            $pd = $pr->row();
            $stk = abs($pd->stock + $dt->qty);
           
            $finalupdatestock = $stk;
            

            $stockupdate = $this->db->query("UPDATE `purchase` SET `qty` = '".$finalupdatestock."' WHERE `purchase`.`product_id` = '".$dt->product_id."';");
              if ($stockupdate) {
               $data["responce"] = true;
            }else{
               $data['data'] = "Stock Error";
            }
            //process
            }
            
           // die(json_encode($ite));
            
            if(!empty($order)){
                $this->db->query("update sale set status = 3 where sale_id = '".$order_id."'");
                //$this->db->delete('sale_items', array('sale_id' => $order_id)); 
                
                 $q = $this->db->query("Select * from users where user_id = '".$order->user_id."'");  
                 $user = $q->row();  
                                $message["title"] = "Cancel  Order";
                                $message["message"] = "Your order Number '".$order->sale_id."' cancel successfully";
                                $message["image"] = "http://chilka.in/Grocery/images/cancle.png";
                                $message["created_at"] = date("Y-m-d h:i:s"); 
                                $message["obj"] = "";
                            
                            $this->load->helper('gcm_helper');
                            $gcm = new GCM();   
                           if($user->user_gcm_code != ""){
                            $result = $gcm->sen(array($user->user_gcm_code),$message ,"android");
                            }
                             if($user->user_ios_token != ""){
                            $result = $gcm->sen(array($user->user_ios_token),$message ,"ios");
                             }
                
                $this->session->set_flashdata("message",'<div class="alert alert-danger alert-dismissible" role="alert">
                                  <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                  <strong>Success!</strong> Order Cancled. | TO Recover Order click the action button you have cancelled and click Recover Order </div>');
            }
            redirect("admin/orders");
        }
        else{
            redirect("admin");
        }
    }
    
    public function delete_order($order_id){
        if(_is_user_login($this)){
            $this->load->model("product_model");
            $order = $this->product_model->get_sale_order_by_id($order_id);
             $ite = $this->product_model->get_sale_order_items($order_id);
            
            foreach($ite as $dt){
            //    echo $i->product_name;
            //process
            $pr = $this->db->query("Select dp.*,products.*, ( ifnull (producation.p_qty,0)) as stock ,categories.title from products 
                          inner join categories on categories.id = products.category_id
                          left outer join(select qty as p_qty,product_id from purchase group by product_id) as producation on producation.product_id = products.product_id
                         left join deal_product dp on dp.product_id=products.product_id where products.product_id = ".$dt->product_id.";");
            $pd = $pr->row();
            $stk = abs($pd->stock + $dt->qty);
           
            $finalupdatestock = $stk;
            

            $stockupdate = $this->db->query("UPDATE `purchase` SET `qty` = '".$finalupdatestock."' WHERE `purchase`.`product_id` = '".$dt->product_id."';");
              if ($stockupdate) {
               $data["responce"] = true;
            }else{
               $data['data'] = "Stock Error";
            }
            //process
            }
            if(!empty($order)){
                $this->db->query("delete from sale where sale_id = '".$order_id."'");
                 $q = $this->db->query("Select * from users where user_id = '".$order->user_id."'");  
                 $user = $q->row();  
                                $message["title"] = "Order deleted";
                                $message["message"] = "Your order Number '".$order->sale_id."' has been deleted";
                                $message["image"] = "http://chilka.in/Grocery/images/cancle.png";
                                $message["created_at"] = date("Y-m-d h:i:s"); 
                                $message["obj"] = "";
                            
                            $this->load->helper('gcm_helper');
                            $gcm = new GCM();   
                          
                            $result = $gcm->sen(array($user->user_ios_token),$message ,"ios");
                            
                $this->session->set_flashdata("message",'<div class="alert alert-danger alert-dismissible" role="alert">
                                  <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                  <strong>Success!</strong> Order deleted. </div>');
            }
            redirect("admin/orders");
        }
        else{
            redirect("admin");
        }
    }

    public function orderdetails($order_id){
        if(_is_user_login($this)){
            $data = array();
            $this->load->model("product_model");
            $data["order"] = $this->product_model->get_sale_order_by_id($order_id);
            $data["order_items"] = $this->product_model->get_sale_order_items($order_id);
            $img = $this->db->query("select * from signature where order_id='".$order_id."'");
            
            if(count($img->result())==0)
            {
                $data["signature"] = array('signature'=>'N/A');
                 
            }
            else
            {
                $d=$img->row();
                $data["signature"] = array('signature'=>$d->signature);
                // echo "yes".count($img->result());
            }
            // var_dump($data["signature"]);
            // //print_r( $data);exit();
            $this->load->view("admin/orders/orderdetails2",$data);
        }
        else{
            redirect("admin");
        }
    }

    public function change_status(){
        $table = $this->input->post("table");
        $id = $this->input->post("id");
        $on_off = $this->input->post("on_off");
        $id_field = $this->input->post("id_field");
        $status = $this->input->post("status");
        
        $this->db->update($table,array("$status"=>$on_off),array("$id_field"=>$id));
    }


  
/* ========== Categories =========== */
    public function addcategories()
    {
       if(_is_user_login($this)){
           
            $data["error"] = "";
            $data["active"] = "addcat";
            if(isset($_REQUEST["addcatg"]))
            {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('cat_title', 'Categories Title', 'trim|required');
                $this->form_validation->set_rules('parent', 'Categories Parent', 'trim|required');
                
                if ($this->form_validation->run() == FALSE)
                {
                   if($this->form_validation->error_string()!=""){
                      $data["error"] = '<div class="alert alert-warning alert-dismissible" role="alert">
                                        <i class="fa fa-warning"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Warning!</strong> '.$this->form_validation->error_string().'
                                    </div>';
                    }
                }
                else
                {
                    $this->load->model("category_model");
                    $this->category_model->add_category(); 
                    $this->session->set_flashdata("message",'<div class="alert alert-success alert-dismissible" role="alert">
                                        <i class="fa fa-check"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Success!</strong> Your request added successfully...
                                    </div>');
                    redirect('admin/addcategories');
                }
            }
        $this->load->view('admin/categories/addcat2',$data);
        }
        else
        {
            redirect('admin');
        }
    }
    
    public function add_header_categories()
    {
       if(_is_user_login($this)){
           
            $data["error"] = "";
            $data["active"] = "addcat";
            if(isset($_REQUEST["addcatg"]))
            {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('cat_title', 'Categories Title', 'trim|required');
                $this->form_validation->set_rules('parent', 'Categories Parent', 'trim|required');
                
                if ($this->form_validation->run() == FALSE)
                {
                   if($this->form_validation->error_string()!=""){
                      $data["error"] = '<div class="alert alert-warning alert-dismissible" role="alert">
                                        <i class="fa fa-warning"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Warning!</strong> '.$this->form_validation->error_string().'
                                    </div>';
                    }
                }
                else
                {
                    $this->load->model("category_model");
                    $this->category_model->add_header_category(); 
                    $this->session->set_flashdata("success_req",'<div class="alert alert-success alert-dismissible" role="alert">
                                        <i class="fa fa-check"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Success!</strong> Your request added successfully...
                                    </div>');
                    redirect('admin/add_header_categories');
                }
            }
        $this->load->view('admin/icon_categories/addcat',$data);
        }
        else
        {
            redirect('admin');
        }
    }
    
    public function editcategory($id)
    {
       if(_is_user_login($this))
       {
            $q = $this->db->query("select * from `categories` WHERE id=".$id);
            $data["getcat"] = $q->row();
            
            $data["error"] = "";
            $data["active"] = "listcat";
            if(isset($_REQUEST["savecat"]))
            {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('cat_title', 'Categories Title', 'trim|required');
                $this->form_validation->set_rules('cat_id', 'Categories Id', 'trim|required');
                $this->form_validation->set_rules('parent', 'Categories Parent', 'trim|required');
                if ($this->form_validation->run() == FALSE)
                {
                   if($this->form_validation->error_string()!=""){
                      $data["error"] = '<div class="alert alert-warning alert-dismissible" role="alert">
                                        <i class="fa fa-warning"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Warning!</strong> '.$this->form_validation->error_string().'
                                    </div>';
                   }
                }
                else
                {
                    $this->load->model("category_model");
                    $this->category_model->edit_category(); 
                    $this->session->set_flashdata("success_req",'<div class="alert alert-success alert-dismissible" role="alert">
                                        <i class="fa fa-check"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Success!</strong> Your category saved successfully...
                                    </div>');
                    redirect('admin/listcategories');
                }
            }
           $this->load->view('admin/categories/editcat2',$data);
        }
        else
        {
            redirect('admin');
        }
    }
    
     public function edit_header_category($id)
    {
       if(_is_user_login($this))
       {
            $q = $this->db->query("select * from `header_categories` WHERE id=".$id);
            $data["getcat"] = $q->row();
            
            $data["error"] = "";
            $data["active"] = "listcat";
            if(isset($_REQUEST["savecat"]))
            {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('cat_title', 'Categories Title', 'trim|required');
                $this->form_validation->set_rules('cat_id', 'Categories Id', 'trim|required');
                $this->form_validation->set_rules('parent', 'Categories Parent', 'trim|required');
                if ($this->form_validation->run() == FALSE)
                {
                   if($this->form_validation->error_string()!=""){
                      $data["error"] = '<div class="alert alert-warning alert-dismissible" role="alert">
                                        <i class="fa fa-warning"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Warning!</strong> '.$this->form_validation->error_string().'
                                    </div>';
                   }
                }
                else
                {
                    $this->load->model("category_model");
                    $this->category_model->edit_header_category(); 
                    $this->session->set_flashdata("success_req",'<div class="alert alert-success alert-dismissible" role="alert">
                                        <i class="fa fa-check"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Success!</strong> Your category saved successfully...
                                    </div>');
                    redirect('admin/header_categories');
                }
            }
           $this->load->view('admin/icon_categories/editcat',$data);
        }
        else
        {
            redirect('admin');
        }
    }
    
    public function listcategories()
    {
       if(_is_user_login($this)){
           $data["error"] = "";
           $data["active"] = "listcat";
           $this->load->model("category_model");
           $data["allcat"] = $this->category_model->get_categories();
           $this->load->view('admin/categories/listcat2',$data);
        }
        else
        {
            redirect('admin');
        }
    }
    
    public function header_categories()
    {
       if(_is_user_login($this)){
           $data["error"] = "";
           $data["active"] = "listcat";
           $this->load->model("category_model");
           $data["allcat"] = $this->category_model->get_header_categories();
           $this->load->view('admin/icon_categories/listcat',$data);
        }
        else
        {
            redirect('admin');
        }
    }
    
    public function deletecat($id)
    {
       if(_is_user_login($this)){
            
            $this->db->delete("categories",array("id"=>$id));
            $this->session->set_flashdata("success_req",'<div class="alert alert-success alert-dismissible" role="alert">
                                        <i class="fa fa-check"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Success!</strong> Your item deleted successfully...
                                    </div>');
            redirect('admin/listcategories');
        }
        else
        {
            redirect('admin');
        }
    }
    
    public function delete_header_categories($id)
    {
       if(_is_user_login($this)){
            
            $this->db->delete("header_categories",array("id"=>$id));
            $this->session->set_flashdata("success_req",'<div class="alert alert-success alert-dismissible" role="alert">
                                        <i class="fa fa-check"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Success!</strong> Your item deleted successfully...
                                    </div>');
            redirect('admin/header_categories');
        }
        else
        {
            redirect('admin');
        }
    }

      
/* ========== End Categories ========== */    
/* ========== Products ==========*/
function products($cat_id=''){
    if(_is_user_login($this)){
        $this->load->model("product_model");
        $data["products"]  = $this->product_model->get_products(false,$cat_id,"","");
        $this->load->view("admin/product/list2",$data);
    }
    else
    {
        redirect('admin');
    }
}
 
 function header_products(){
        $this->load->model("product_model");
        $data["products"]  = $this->product_model->get_header_products();
        $this->load->view("admin/icon_product/list2",$data);    
}



function edit_products($prod_id){
       if(_is_user_login($this)){
        
            if(isset($_POST))
            {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('prod_title', 'Categories Title', 'trim|required');
                $this->form_validation->set_rules('parent', 'Categories Parent', 'trim|required');
                
                if ($this->form_validation->run() == FALSE)
                {
                   if($this->form_validation->error_string()!=""){
                      $this->session->set_flashdata("message", '<div class="alert alert-warning alert-dismissible" role="alert">
                                        <i class="fa fa-warning"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Warning!</strong> '.$this->form_validation->error_string().'
                                    </div>');
                   }
                }
                else
                {


                    if($this->input->post("rewards")=="")
                    {
                        $rewards=0;
                    }
                    else
                    {
                        $rewards=$this->input->post("rewards");
                    }
                    $this->load->model("common_model");
                    $array = array( 
                    "product_name"=>$this->input->post("prod_title"), 
                    "product_arb_name"=>$this->input->post("arb_prod_title"), 
                    "product_arb_description"=>$this->input->post("arb_product_description"),
                    "category_id"=>$this->input->post("parent"), 
                    "product_description"=>$this->input->post("product_description"),
                    "in_stock"=>$this->input->post("prod_status"),
                    "price"=>$this->input->post("price"),
                    "mrp"=>$this->input->post("mrp"),
                    "tax"=>$this->input->post("tax"),
                    "unit_value"=>$this->input->post("qty"),
                    "unit"=>$this->input->post("unit"),
                    "arb_unit"=>$this->input->post("arb_unit"), 
                    "rewards"=>$rewards,
                    "barcode"=>$this->input->post("barcode")
                    
                    );
                    $q = $this->db->query("UPDATE `purchase` SET `qty` = '".$this->input->post("stock")."' WHERE `purchase`.`product_id` = '$prod_id';");
                    if($_FILES["prod_img"]["size"] > 0){
                        $config['upload_path']          = './uploads/products/';
                        $config['allowed_types']        = 'gif|jpg|png|jpeg';
                        $this->load->library('upload', $config);
        
                        if ( ! $this->upload->do_upload('prod_img'))
                        {
                                $error = array('error' => $this->upload->display_errors());
                        }
                        else
                        {
                            $img_data = $this->upload->data();
                            $array["product_image"]=$img_data['file_name'];
                        }
                        
                   }
                    
                    $this->common_model->data_update("products",$array,array("product_id"=>$prod_id)); 
                    $this->session->set_flashdata("message",'<div class="alert alert-success alert-dismissible" role="alert">
                                        <i class="fa fa-check"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Success!</strong> Your request added successfully...
                                    </div>');
                    redirect('admin/products');
                }
            }
            $this->load->model("product_model");
            $data["product"] = $this->product_model->get_product_by_id($prod_id);
            $this->load->view("admin/product/edit2",$data);
        }
        else
        {
            redirect('admin');
        }
    
}

function edit_header_products($prod_id){
       if(_is_user_login($this)){
        
            if(isset($_POST))
            {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('prod_title', 'Categories Title', 'trim|required');
                $this->form_validation->set_rules('parent', 'Categories Parent', 'trim|required');
                
                if ($this->form_validation->run() == FALSE)
                {
                   if($this->form_validation->error_string()!=""){
                      $this->session->set_flashdata("message", '<div class="alert alert-warning alert-dismissible" role="alert">
                                        <i class="fa fa-warning"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Warning!</strong> '.$this->form_validation->error_string().'
                                    </div>');
                   }
                }
                else
                {
                    $this->load->model("common_model");
                    $array = array( 
                    "product_name"=>$this->input->post("prod_title"), 
                    "category_id"=>$this->input->post("parent"), 
                    "product_description"=>$this->input->post("product_description"),
                    "in_stock"=>$this->input->post("prod_status"),
                    "price"=>$this->input->post("price"),
                    "unit_value"=>$this->input->post("qty"),
                    "unit"=>$this->input->post("unit"),
                    "rewards"=>$this->input->post("rewards")
                    
                    );
                    if($_FILES["prod_img"]["size"] > 0){
                        $config['upload_path']          = './uploads/products/';
                        $config['allowed_types']        = 'gif|jpg|png|jpeg';
                        $this->load->library('upload', $config);
        
                        if ( ! $this->upload->do_upload('prod_img'))
                        {
                                $error = array('error' => $this->upload->display_errors());
                        }
                        else
                        {
                            $img_data = $this->upload->data();
                            $array["product_image"]=$img_data['file_name'];
                        }
                        
                   }
                    
                    $this->common_model->data_update("header_products",$array,array("product_id"=>$prod_id)); 
                    $this->session->set_flashdata("message",'<div class="alert alert-success alert-dismissible" role="alert">
                                        <i class="fa fa-check"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Success!</strong> Your request added successfully...
                                    </div>');
                    redirect('admin/header_products');
                }
            }
            $this->load->model("product_model");
            $data["product"] = $this->product_model->get_header_product_by_id($prod_id);
            $this->load->view("admin/icon_product/edit",$data);
        }
        else
        {
            redirect('admin');
        }
    
}

function add_products(){
       if(_is_user_login($this)){
        
            if(isset($_POST))
            {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('prod_title', 'Categories Title', 'trim|required');
                $this->form_validation->set_rules('parent', 'Categories Parent', 'trim|required');
                 $this->form_validation->set_rules('price', 'price', 'trim|required');
                $this->form_validation->set_rules('qty', 'qty', 'trim|required'); 
                $this->form_validation->set_rules('mrp', 'mrp', 'trim|required'); 
                $this->form_validation->set_rules('stock', 'Stock Input', 'trim|required'); 
                
                if ($this->form_validation->run() == FALSE)
                {
                      if($this->form_validation->error_string()!="") { 
                      $this->session->set_flashdata("message", '<div class="alert alert-warning alert-dismissible" role="alert">
                                        <i class="fa fa-warning"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Warning!</strong> '.$this->form_validation->error_string().'
                                    </div>');
                 }
                                   
                }
                else
                {
                    if($this->input->post("rewards")=="")
                    {
                        $rewards=0;
                    }
                    else
                    {
                        $rewards=$this->input->post("rewards");
                    }
                    $this->load->model("common_model");
                    $array = array( 
                    "product_name"=>$this->input->post("prod_title"), 
                    "product_arb_name"=>$this->input->post("arb_prod_title"), 
                    "product_arb_description"=>$this->input->post("arb_product_description"), 
                    "category_id"=>$this->input->post("parent"),
                    "in_stock"=>$this->input->post("prod_status"),
                    "product_description"=>$this->input->post("product_description"),
                    "price"=>$this->input->post("price"),
                    "mrp"=>$this->input->post("mrp"),
                    "unit_value"=>$this->input->post("qty"),
                    "unit"=>$this->input->post("unit"), 
                    "arb_unit"=>$this->input->post("arb_unit"), 
                    "tax"=>$this->input->post("tax"), 
                    "rewards"=>$rewards,
                    "barcode"=>$this->input->post("barcode")
                    );
                    if($_FILES["prod_img"]["size"] > 0){
                        $config['upload_path']          = './uploads/products/';
                        $config['allowed_types']        = 'gif|jpg|png|jpeg';
                        $this->load->library('upload', $config);
        
                        if ( ! $this->upload->do_upload('prod_img'))
                        {
                                $error = array('error' => $this->upload->display_errors());
                        }
                        else
                        {
                            $img_data = $this->upload->data();
                            $array["product_image"]=$img_data['file_name'];
                        }
                        
                   }
                    
                    $in_id = $this->common_model->data_insert("products",$array); 
                    $purchaasr=$this->db->query("Insert into purchase(product_id, qty, unit, date, store_id_login) values('".$in_id."','".$this->input->post("stock")."', '".$this->input->post("unit")."', '".date('d-m-y h:i:s ')."', '"._get_current_user_id($this)."')");
                    if($purchaasr){ $m=1; }else{ $m=0; }
                    $this->session->set_flashdata("message",'<div class="alert alert-success alert-dismissible" role="alert">
                                        <i class="fa fa-check"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Success!</strong> Your request added successfully..."'.$m.'"
                                    </div>');
                    redirect('admin/products');
                }
            }
            if(isset($error)){
            $data['product_name'] = $this->input->post("prod_title");
            $data['product_desc'] = $this->input->post("product_description");
            $data['product_price'] = $this->input->post("price");
            $data['product_mrp'] = $this->input->post("mrp");
            $data['product_unit'] = $this->input->post("unit");
            $data['product_value'] = $this->input->post("qty");
            }else{
            $data['product_name'] = "";
            $data['product_desc'] = "";
            $data['product_price'] = "";
            $data['product_mrp'] = "";
            $data['product_unit'] = "";
            $data['product_value'] = "";
            }
            $this->load->view("admin/product/add2",$data);
        }
        else
        {
            redirect('admin');
        }
    
}

function add_header_products(){
       if(_is_user_login($this)){
        
            if(isset($_POST))
            {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('prod_title', 'Categories Title', 'trim|required');
                $this->form_validation->set_rules('parent', 'Categories Parent', 'trim|required');
                 $this->form_validation->set_rules('price', 'price', 'trim|required');
                $this->form_validation->set_rules('qty', 'qty', 'trim|required'); 
                
                if ($this->form_validation->run() == FALSE)
                {
                      if($this->form_validation->error_string()!="") { 
                      $this->session->set_flashdata("message", '<div class="alert alert-warning alert-dismissible" role="alert">
                                        <i class="fa fa-warning"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Warning!</strong> '.$this->form_validation->error_string().'
                                    </div>');
                 }
                                   
                }
                else
                {
                    $this->load->model("common_model");
                    $array = array( 
                    "product_name"=>$this->input->post("prod_title"), 
                    "category_id"=>$this->input->post("parent"),
                    "in_stock"=>$this->input->post("prod_status"),
                    "product_description"=>$this->input->post("product_description"),
                    "price"=>$this->input->post("price"),
                    "unit_value"=>$this->input->post("qty"),
                    "unit"=>$this->input->post("unit"), 
                    "rewards"=>$this->input->post("rewards")
                    );
                    if($_FILES["prod_img"]["size"] > 0){
                        $config['upload_path']          = './uploads/products/';
                        $config['allowed_types']        = 'gif|jpg|png|jpeg';
                        $this->load->library('upload', $config);
        
                        if ( ! $this->upload->do_upload('prod_img'))
                        {
                                $error = array('error' => $this->upload->display_errors());
                        }
                        else
                        {
                            $img_data = $this->upload->data();
                            $array["product_image"]=$img_data['file_name'];
                        }
                        
                   }
                    
                    $this->common_model->data_insert("header_products",$array); 
                    $this->session->set_flashdata("message",'<div class="alert alert-success alert-dismissible" role="alert">
                                        <i class="fa fa-check"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Success!</strong> Your request added successfully...
                                    </div>');
                    redirect('admin/header_products');
                }
            }
            
            $this->load->view("admin/icon_product/add");
        }
        else
        {
            redirect('admin');
        }
    
}

function delete_product($id,$pim){
        if(_is_user_login($this)){
            $this->db->query("Delete from products where product_id = '".$id."'");
            $this->db->query("Delete from purchase where product_id = '".$id."'");
            unlink("uploads/products/".$pim."");
            redirect("admin/products");
        }
        else
        {
            redirect('admin');
        }
        
}

function delete_user($id){
        if(_is_user_login($this)){
            $this->db->query("DELETE FROM `registers` WHERE `registers`.`user_id` = ".$id."");
            redirect("admin/registers");

             $this->session->set_flashdata("message",'<div class="alert alert-success alert-dismissible" role="alert">
                                  <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                  <strong>Success!</strong>User ID : '.$id.' has been deleted</div>');
        }
        else
        {
            redirect('admin');
        }
        
}

function delete_header_product($id){
        if(_is_user_login($this)){
            $this->db->query("Delete from header_products where product_id = '".$id."'");
            redirect("admin/header_products");
        }
}

/* ========== Products ==========*/  
/* ========== Purchase ==========*/
public function add_purchase(){
    if(_is_user_login($this)){

        $type = "List Purchase";
        
            if(isset($_POST))
            {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('product_id', 'product_id', 'trim|required');
                $this->form_validation->set_rules('qty', 'Qty', 'trim|required');
                $this->form_validation->set_rules('unit', 'Unit', 'trim|required');
                if ($this->form_validation->run() == FALSE)
                {
                  if($this->form_validation->error_string()!="")
                      $this->session->set_flashdata("message", '<div class="alert alert-warning alert-dismissible" role="alert">
                                        <i class="fa fa-warning"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Warning!</strong> '.$this->form_validation->error_string().'
                                    </div>');
                }
                else
                {
              
                    $this->load->model("common_model");
                    $array = array(
                    "product_id"=>$this->input->post("product_id"),
                    "qty"=>$this->input->post("qty"),
                    "price"=>$this->input->post("price"),
                    "unit"=>$this->input->post("unit")
                    );
                    $this->common_model->data_insert("purchase",$array);
                    
                    $this->session->set_flashdata("message",'<div class="alert alert-success alert-dismissible" role="alert">
                                        <i class="fa fa-check"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Success!</strong> Your request added successfully...
                                    </div>');
                    redirect("admin/add_purchase");
                }
                
                $this->load->model("product_model");
                $data["purchases"]  = $this->product_model->get_purchase_list();
                $data["products"]  = $this->product_model->get_products();
                $this->load->view("admin/product/purchase2",$data);  
                
            }
    }
    else
    {
        redirect('admin');
    }
    
}


public function nostock(){
    if(_is_user_login($this)){

            $type = "NoStock Products";
        
            if(isset($_POST))
            {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('product_id', 'product_id', 'trim|required');
                $this->form_validation->set_rules('qty', 'Qty', 'trim|required');
                $this->form_validation->set_rules('unit', 'Unit', 'trim|required');
                if ($this->form_validation->run() == FALSE)
                {
                  if($this->form_validation->error_string()!="")
                      $this->session->set_flashdata("message", '<div class="alert alert-warning alert-dismissible" role="alert">
                                        <i class="fa fa-warning"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Warning!</strong> '.$this->form_validation->error_string().'
                                    </div>');
                }
                else
                {

              
                    $this->load->model("common_model");
                    $array = array(
                    "product_id"=>$this->input->post("product_id"),
                    "qty"=>$this->input->post("qty"),
                    "price"=>$this->input->post("price"),
                    "unit"=>$this->input->post("unit")
                    );
                    $this->common_model->data_insert("purchase",$array);
                    
                    $this->session->set_flashdata("message",'<div class="alert alert-success alert-dismissible" role="alert">
                                        <i class="fa fa-check"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Success!</strong> Your request added successfully...
                                    </div>');
                    redirect("admin/add_purchase");
                }
                
                $this->load->model("product_model");
                $data["purchases"]  = $this->product_model->get_purchase_list2();
                $data["products"]  = $this->product_model->get_products();
                $this->load->view("admin/product/purchase22",$data);  


                
            }
    }
    else
    {
        redirect('admin');
    }
    
}

function edit_purchase($id){
    if(_is_user_login($this)){
        
            if(isset($_POST))
            {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('product_id', 'product_id', 'trim|required');
                $this->form_validation->set_rules('qty', 'Qty', 'trim|required');
                $this->form_validation->set_rules('unit', 'Unit', 'trim|required');
                if ($this->form_validation->run() == FALSE)
                {
                  if($this->form_validation->error_string()!="")
                      $this->session->set_flashdata("message", '<div class="alert alert-warning alert-dismissible" role="alert">
                                        <i class="fa fa-warning"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Warning!</strong> '.$this->form_validation->error_string().'
                                    </div>');
                }
                else
                {
              
                    $this->load->model("common_model");
                    $array = array(
                    "product_id"=>$this->input->post("product_id"),
                    "qty"=>$this->input->post("qty"),
                    "price"=>$this->input->post("price"),
                    "unit"=>$this->input->post("unit")
                    );
                    $this->common_model->data_update("purchase",$array,array("purchase_id"=>$id));
                    
                    $this->session->set_flashdata("message",'<div class="alert alert-success alert-dismissible" role="alert">
                                        <i class="fa fa-check"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Success!</strong> Your request added successfully...
                                    </div>');
                    redirect("admin/add_purchase");
                }
                
                $this->load->model("product_model");
                $data["purchase"]  = $this->product_model->get_purchase_by_id($id);
                $data["products"]  = $this->product_model->get_products();
                $this->load->view("admin/product/edit_purchase2",$data);  
                
            }
    }
    else
    {
        redirect('admin');
    }
}

function nedit_purchase($id){
    if(_is_user_login($this)){
        
            if(isset($_POST))
            {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('product_id', 'product_id', 'trim|required');
                $this->form_validation->set_rules('qty', 'Qty', 'trim|required');
                $this->form_validation->set_rules('unit', 'Unit', 'trim|required');
                if ($this->form_validation->run() == FALSE)
                {
                  if($this->form_validation->error_string()!="")
                      $this->session->set_flashdata("message", '<div class="alert alert-warning alert-dismissible" role="alert">
                                        <i class="fa fa-warning"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Warning!</strong> '.$this->form_validation->error_string().'
                                    </div>');
                }
                else
                {
              
                    $this->load->model("common_model");
                    $array = array(
                    "product_id"=>$this->input->post("product_id"),
                    "qty"=>$this->input->post("qty"),
                    "price"=>$this->input->post("price"),
                    "unit"=>$this->input->post("unit")
                    );
                    $this->common_model->data_update("purchase",$array,array("purchase_id"=>$id));
                    
                    $this->session->set_flashdata("message",'<div class="alert alert-success alert-dismissible" role="alert">
                                        <i class="fa fa-check"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Success!</strong> Your request added successfully...
                                    </div>');
                    redirect("admin/nostock");
                }
                
                $this->load->model("product_model");
                $data["purchase"]  = $this->product_model->get_purchase_by_id($id);
                $data["products"]  = $this->product_model->get_products();
                $this->load->view("admin/product/edit_purchase2",$data);  
                
            }
    }
    else
    {
        redirect('admin');
    }
}

function delete_purchase($id){
    if(_is_user_login($this)){
        $this->db->query("Delete from purchase where purchase_id = '".$id."'");
        redirect("admin/add_purchase");
    }
    else
    {
        redirect('admin');
    }
}

function ndelete_purchase($id){
    if(_is_user_login($this)){
        $this->db->query("Delete from purchase where purchase_id = '".$id."'");
        redirect("admin/nostock");
    }
    else
    {
        redirect('admin');
    }
}
/* ========== Purchase END ==========*/
    public function socity(){
        if(_is_user_login($this)){
            
                if(isset($_POST))
                {
                    $this->load->library('form_validation');
                    $this->form_validation->set_rules('pincode', 'pincode', 'trim|required');
                    $this->form_validation->set_rules('socity_name', 'Socity Name', 'trim|required');
                    $this->form_validation->set_rules('delivery', 'Delivery Charges', 'trim|required');

                    if ($this->form_validation->run() == FALSE)
                    {
                      if($this->form_validation->error_string()!="")
                          $this->session->set_flashdata("message", '<div class="alert alert-warning alert-dismissible" role="alert">
                                            <i class="fa fa-warning"></i>
                                          <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                          <strong>Warning!</strong> '.$this->form_validation->error_string().'
                                        </div>');
                    }
                    else
                    {
                  
                        $this->load->model("common_model");
                        $array = array(
                        "socity_name"=>$this->input->post("socity_name"),
                        "pincode"=>$this->input->post("pincode"),
                          "delivery_charge"=>$this->input->post("delivery"),
                          "min_order"=>$this->input->post("min_order")

                        );
                        $this->common_model->data_insert("socity",$array);
                        
                        $this->session->set_flashdata("message",'<div class="alert alert-success alert-dismissible" role="alert">
                                            <i class="fa fa-check"></i>
                                          <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                          <strong>Success!</strong> Your request added successfully...
                                        </div>');
                        redirect("admin/socity");
                    }
                    
                    $this->load->model("product_model");
                    $data["socities"]  = $this->product_model->get_socities();
                    $this->load->view("admin/socity/list2",$data);  
                    
                }
        }
        else
        {
            redirect('admin');
        }
            
    }

    public function city(){
        if(_is_user_login($this)){


            if(isset($_POST))
            {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('city_name', 'City Name', 'trim|required');

                if ($this->form_validation->run() == FALSE)
                {
                  if($this->form_validation->error_string()!="")
                      $this->session->set_flashdata("message", '<div class="alert alert-warning alert-dismissible" role="alert">
                                        <i class="fa fa-warning"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Warning!</strong> '.$this->form_validation->error_string().'
                                    </div>');
                }
                else
                {
              
                    $this->load->model("common_model");
                    $array = array(
                    "city_name"=>$this->input->post("city_name")
                    );
                    $this->common_model->data_insert("city",$array);
                    
                    $this->session->set_flashdata("message",'<div class="alert alert-success alert-dismissible" role="alert">
                                        <i class="fa fa-check"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Success!</strong> Your request added successfully...
                                    </div>');
                    redirect("admin/city");
                } 
                
            }
        
            $ct  = $this->db->query("select * from `city`");
            $data["cities"] = $ct->result();
            $this->load->view("admin/socity/city_list",$data);  
        }
        else{
            redirect("admin");
        }
        
    }

    public function delete_city($id){
        if(_is_user_login($this)){
            $this->db->query("Delete from city where city_id = '".$id."'");
            redirect("admin/city");
        }
        else
        {
            redirect('admin');
        }
    }
    
    public function declared_rewards(){
        if(_is_user_login($this)){
            
                $this->load->library('form_validation');
               $this->load->model("product_model");
               
                   
                    
                     $this->form_validation->set_rules('delivery', 'Delivery Charges', 'trim|required');

                    if (!$this->form_validation->run() == FALSE)
                    {
                        
                        $point = array(
                           'point' => $this->input->post('delivery')
                          
                        );
                        
                        $this->product_model->update_reward($point);
                        
                        
                      if($this->form_validation->error_string()!="")
                          $this->session->set_flashdata("message", '<div class="alert alert-warning alert-dismissible" role="alert">
                                            <i class="fa fa-warning"></i>
                                          <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                          <strong>Warning!</strong> '.$this->form_validation->error_string().'
                                        </div>');
                    
                    
                   }
                    
                    $data['rewards']  = $this->product_model->rewards_value();
                    //print_r( $data['rewards']);
                    $this->load->view("admin/declared_rewards/edit2",$data);  
        }
        else
        {
            redirect('admin');
        }
    }
    
    public function edit_socity($id){
        if(_is_user_login($this)){
        
            if(isset($_POST))
            {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('pincode', 'pincode', 'trim|required');
                $this->form_validation->set_rules('socity_name', 'Socity Name', 'trim|required');
                $this->form_validation->set_rules('delivery', 'Delivery Charges', 'trim|required');
                $this->form_validation->set_rules('min_order', 'Minium Order Amount', 'trim|required');
                if ($this->form_validation->run() == FALSE)
                {
                  if($this->form_validation->error_string()!="")
                      $this->session->set_flashdata("message", '<div class="alert alert-warning alert-dismissible" role="alert">
                                        <i class="fa fa-warning"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Warning!</strong> '.$this->form_validation->error_string().'
                                    </div>');
                }
                else
                {
              
                    $this->load->model("common_model");
                    $array = array(
                    "socity_name"=>$this->input->post("socity_name"),
                    "pincode"=>$this->input->post("pincode"),
                    "delivery_charge"=>$this->input->post("delivery"),
                    "min_order"=>$this->input->post("min_order")
                    );
                    $this->common_model->data_update("socity",$array,array("socity_id"=>$id));
                    
                    $this->session->set_flashdata("message",'<div class="alert alert-success alert-dismissible" role="alert">
                                        <i class="fa fa-check"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Success!</strong> Your request added successfully...
                                    </div>');
                    redirect("admin/socity");
                }
                
                $this->load->model("product_model");
                $data["socity"]  = $this->product_model->get_socity_by_id($id);
                $this->load->view("admin/socity/edit2",$data);  
                
            }
        }
        else
        {
            redirect('admin');
        }
        
    }
    public function delete_socity($id){
        if(_is_user_login($this)){
            $this->db->query("Delete from socity where socity_id = '".$id."'");
            redirect("admin/socity");
        }
        else
        {
            redirect('admin');
        }
    }

    function registers(){
        if(_is_user_login($this)){
            $this->load->model("product_model");
            $users = $this->product_model->get_all_users();
            $this->load->view("admin/allusers2",array("users"=>$users));
        }
        else
        {
            redirect('admin');
        }
    }

     function adduser(){
        if(_is_user_login($this)){
            $this->load->model("product_model");
            $users = $this->product_model->get_all_users();
            $this->load->view("admin/product/add_user",array("users"=>$users));
        }
        else
        {
            redirect('admin');
        }
    }
 
 /* ========== Page app setting =========*/

    
    public function allpageapp()
    {
       if(_is_user_login($this)){
           $data["error"] = "";
           $data["active"] = "allpage";
           
           $this->load->model("page_app_model");
           $data["allpages"] = $this->page_app_model->get_pages();
           
           $this->load->view('admin/page_app/allpage_app2',$data);
        }
        else
        {
            redirect('login');
        }
    }
    public function editpage_app($id)
    {
       if(_is_user_login($this)){
           $data["error"] = "";
           $data["active"] = "allpage";
           
           $this->load->model("page_app_model");
           $data["onepage"] = $this->page_app_model->one_page($id);
           
           if(isset($_REQUEST["savepageapp"]))
            {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('page_title', 'Page Title', 'trim|required');
                $this->form_validation->set_rules('page_id', 'Page Id', 'trim|required');
                $this->form_validation->set_rules('page_descri', 'Page Description', 'trim|required');
                if ($this->form_validation->run() == FALSE)
                {
                  if($this->form_validation->error_string()!="")
                      $data["error"] = '<div class="alert alert-warning alert-dismissible" role="alert">
                                        <i class="fa fa-warning"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Warning!</strong> '.$this->form_validation->error_string().'
                                    </div>';
                }
                else
                {
                    $this->load->model("page_app_model");
                    $this->page_app_model->set_page(); 
                    $this->session->set_flashdata("success_req",'<div class="alert alert-success alert-dismissible" role="alert"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Success!</strong> Your page saved successfully...</div>');
                    redirect('admin/allpageapp');
                }
            }
           $this->load->view('admin/page_app/editpage_app2',$data);
        }
        else
        {
            redirect('login');
        }
    }
    public function deletepageapp($id)
    {
       if(_is_user_login($this)){
            
            $this->db->delete("pageapp",array("id"=>$id));
            $this->session->set_flashdata("success_req",'<div class="alert alert-success alert-dismissible" role="alert">
                                        <i class="fa fa-check"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Success!</strong> Your page deleted successfully...
                                    </div>');
            redirect('admin/allpage_app');
        }
        else
        {
            redirect('login');
        }
    }

/* ========== End page page setting ========*/

public function setting(){
    if(_is_user_login($this)){
          $this->load->model("setting_model"); 
                $data["settings"]  = $this->setting_model->get_settings(); 
              
                $this->load->view("admin/setting/settings2",$data);  
    }
    else
    {
        redirect('admin');
    }
}

public function edit_settings($id){
    if(_is_user_login($this)){
        
            if(isset($_POST))
            {
                $this->load->library('form_validation');
                 
                $this->form_validation->set_rules('value', 'Amount', 'trim|required');
                if ($this->form_validation->run() == FALSE)
                {
                  if($this->form_validation->error_string()!="")
                      $this->session->set_flashdata("message", '<div class="alert alert-warning alert-dismissible" role="alert">
                                        <i class="fa fa-warning"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Warning!</strong> '.$this->form_validation->error_string().'
                                    </div>');
                }
                else
                {
              
                    $this->load->model("common_model");
                    $array = array(
                    "title"=>$this->input->post("title"), 
                    "value"=>$this->input->post("value")
                    );
                    
                    $this->common_model->data_update("settings",$array,array("id"=>$id));
                    
                    $this->session->set_flashdata("message",'<div class="alert alert-success alert-dismissible" role="alert">
                                        <i class="fa fa-check"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Success!</strong> Your request added successfully...
                                    </div>');
                    redirect("admin/setting");
                }
                
                $this->load->model("setting_model");
                $data["editsetting"]  = $this->setting_model->get_setting_by_id($id);
                $this->load->view("admin/setting/edit_settings2",$data);  
                
            }
    }
    else
        {
            redirect('admin');
        }
}
    
public function stock(){
    if(_is_user_login($this)){
        $this->load->model("product_model");
        $data["stock_list"] = $this->product_model->get_leftstock();
        $this->load->view("admin/product/stock2",$data);
    }
    else
        {
            redirect('admin');
        }
}
/* ========== End page page setting ========*/
   function testnoti(){
        $token =  "dLmBHiGL_6g:APA91bGp5L_mZ0NwPZiihxIDVmo-d-UV05fvmcIDzDiyJ82ztCelmFl4oFRD2hEOPT2lE--ze-yH6Nac6KxbHspYWSQw4mmw8AZ-3HRrwD_crCO1o3p9mRu9WvOOsaw_vvScMnIIv2np";
    }

    function notification(){
        if(_is_user_login($this)){
        
            if(isset($_POST))
            {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('descri', 'Description', 'trim|required');
                  if ($this->form_validation->run() == FALSE)
                  {
                              if($this->form_validation->error_string()!="")
                      $this->session->set_flashdata("message", '<div class="alert alert-warning alert-dismissible" role="alert">
                                        <i class="fa fa-warning"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Warning!</strong> '.$this->form_validation->error_string().'
                                    </div>');
                  }else{
                            // $message["title"] = 'Chilka Grocery';
                            $message= $this->input->post("descri");
                            ///$message["created_at"] = date("Y-m-d h:i:s");
                            
                            //$msg = $this->input->post("descri");
                            if($_FILES["image"]["size"] > 0){
                                    $config['upload_path']          = './uploads/open_app/';
                                    $config['allowed_types']        = 'gif|jpg|png|jpeg';
                                    $this->load->library('upload', $config);
                    
                                    if ( ! $this->upload->do_upload('image'))
                                    {
                                            $error = array('error' => $this->upload->display_errors());
                                    }
                                    else
                                    {
                                        $img_data = $this->upload->data();
                                        $imag=$img_data['file_name'];
                                    }
                                    
                               }
                            $message=array('title' => $this->config->item('company_title'), 'body' => $message ,'sound'=>'Default','image'=>"https://media.discordapp.net/attachments/808947086716305421/817647395973365800/pk-pc.PNG?width=951&height=427");
                            
                            $this->load->helper('gcm_helper');
                            $gcm = new GCM();   
                            //$result = $gcm->send_topics("/topics/rabbitapp",$message ,"ios"); 
                            
                            $result = $gcm->send_topics("Chilka_Grocery",$message ,"android");
                            $result = $gcm->send_notification("Chilka_Grocery", $message,"android");
                            
                                                                        
                    //  if(count($registatoin_ids) > 1000){
                      
                    //   $chunk_array = array_chunk($registatoin_ids,1000);
                    //   foreach($chunk_array as $chunk){
                    //     $result = $gcm->send_notification($chunk, $message,"android");
                    //   }
                      
                    //  }
                    //  else{
    
                    //   //$result = $gcm->send_notification($registatoin_ids, $message,"android");
                    //     }  
                            
                             redirect("admin/notification");
                  }
                   
                   $this->load->view("admin/product/notification2");
                
            }
        }
        else
        {
            redirect('admin');
        }
        
    }

    function notify1(){
        $id = $this->input->post("user_id");  
         $messagefa= $this->input->post("noft");    
        
                            
                            $this->load->helper('gcm_helper');
                            $gcm = new GCM();   
                            //$result = $gcm->send_topics("/topics/rabbitapp",$message ,"ios"); 
                            
                            //$result = $gcm->send_topics("Chilka_Grocery",$message ,"android");
                            //$result = $gcm->send_notification("Chilka_Grocery", $message,"android");
                            
                            
                            
                                $q = $this->db->query("Select user_ios_token from registers where user_id = '$id';");
                                $user = $q->row();
                                if($_FILES["image"]["size"] > 0){
                                    $config['upload_path']          = './uploads/open_app/';
                                    $config['allowed_types']        = 'gif|jpg|png|jpeg';
                                    $this->load->library('upload', $config);
                    
                                    if ( ! $this->upload->do_upload('image'))
                                    {
                                            $error = array('error' => $this->upload->display_errors());
                                    }
                                    else
                                    {
                                        $img_data = $this->upload->data();
                                        $imag=$img_data['file_name'];
                                    }
                                    
                               }
                          $message= $this->input->post("descri");
                            ///$message["created_at"] = date("Y-m-d h:i:s");
                            
                            //$msg = $this->input->post("descri");
                            
                            $message=array('title' => $this->config->item('company_title'), 'body' => $message ,'sound'=>'Default','image'=>base_url("uploads/open_app/".$imag." "));
                            
                            $gcm = new GCM();   
                          
                             
                            $result = $gcm->sen(array($user->user_ios_token),$message ,"ios");
                            
                            print_r($message);
                            
       
                             
                

    //  redirect("admin/notify_user/$id/?error=0");
    //  print_r($re);

    }
    
    function time_slot(){
        if(_is_user_login($this)){
                $this->load->model("time_model");
                $timeslot = $this->time_model->get_time_slot();
                
                $this->load->library('form_validation');
                $this->form_validation->set_rules('opening_time', 'Opening Hour', 'trim|required');
                $this->form_validation->set_rules('closing_time', 'Closing Hour', 'trim|required');
                if ($this->form_validation->run() == FALSE)
                {
                  if($this->form_validation->error_string()!="")
                      $this->session->set_flashdata("message", '<div class="alert alert-warning alert-dismissible" role="alert">
                                        <i class="fa fa-warning"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Warning!</strong> '.$this->form_validation->error_string().'
                                    </div>');
                }
                else
                {
                  if(empty($timeslot)){
                    $q = $this->db->query("Insert into time_slots(opening_time,closing_time,time_slot) values('".date("H:i:s",strtotime($this->input->post('opening_time')))."','".date("H:i:s",strtotime($this->input->post('closing_time')))."','".$this->input->post('interval')."')");
                  }else{
                    $q = $this->db->query("Update time_slots set opening_time = '".date("H:i:s",strtotime($this->input->post('opening_time')))."' ,closing_time = '".date("H:i:s",strtotime($this->input->post('closing_time')))."',time_slot = '".$this->input->post('interval')."' ");
                  }  
                }            
            
            $timeslot = $this->time_model->get_time_slot();
            $this->load->view("admin/timeslot/edit2",array("schedule"=>$timeslot));
        }
        else
        {
            redirect('admin');
        }
    }

    function closing_hours(){
        if(_is_user_login($this)){
            $this->load->library('form_validation');
            $this->form_validation->set_rules('date', 'Date', 'trim|required');
                    $this->form_validation->set_rules('opening_time', 'Start Hour', 'trim|required');
                    $this->form_validation->set_rules('closing_time', 'End Hour', 'trim|required');
                    if ($this->form_validation->run() == FALSE)
                    {
                      if($this->form_validation->error_string()!="")
                          $this->session->set_flashdata("message", '<div class="alert alert-warning alert-dismissible" role="alert">
                                            <i class="fa fa-warning"></i>
                                          <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                          <strong>Warning!</strong> '.$this->form_validation->error_string().'
                                        </div>');
                    }
                    else
                    {
                          $array = array("date"=>date("Y-m-d",strtotime($this->input->post("date"))),
                          "from_time"=>date("H:i:s",strtotime($this->input->post("opening_time"))),
                          "to_time"=>date("H:i:s",strtotime($this->input->post("closing_time")))
                          ); 
                          $this->db->insert("closing_hours",$array); 
                    }
            
             $this->load->model("time_model");
             $timeslot = $this->time_model->get_closing_date(date("Y-m-d"));
             $this->load->view("admin/timeslot/closing_hours2",array("schedule"=>$timeslot));
        }
        else
        {
            redirect('admin');
        }
            
    }
    
     
    function delete_closing_date($id){
        if(_is_user_login($this)){
            $this->db->query("Delete from closing_hours where id = '".$id."'");
            redirect("admin/closing_hours");
        }
        else
        {
            redirect('admin');
        }
    }

    public function addslider()
    {
       if(_is_user_login($this)){
           
            $data["error"] = "";
            $data["active"] = "addslider";
            
            if(isset($_REQUEST["addslider"]))
            {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('slider_title', 'Slider Title', 'trim|required');
                if (empty($_FILES['slider_img']['name']))
                {
                    $this->form_validation->set_rules('slider_img', 'Slider Image', 'required');
                }
                
                if ($this->form_validation->run() == FALSE)
                {
                      $data["error"] = '<div class="alert alert-warning alert-dismissible" role="alert">
                                        <i class="fa fa-warning"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Warning!</strong> '.$this->form_validation->error_string().'
                                    </div>';
                }
                else
                {
                    $add = array(
                                    "slider_title"=>$this->input->post("slider_title"),
                                    "slider_status"=>$this->input->post("slider_status"),
                                    "slider_url"=>$this->input->post("slider_url"),
                                    "sub_cat"=>$this->input->post("sub_cat")
                                    );
                    
                        if($_FILES["slider_img"]["size"] > 0){
                            $config['upload_path']          = './uploads/sliders/';
                            $config['allowed_types']        = 'gif|jpg|png|jpeg';
                            $this->load->library('upload', $config);
            
                            if ( ! $this->upload->do_upload('slider_img'))
                            {
                                    $error = array('error' => $this->upload->display_errors());
                            }
                            else
                            {
                                $img_data = $this->upload->data();
                                $add["slider_image"]=$img_data['file_name'];
                            }
                            
                       }
                       
                       $this->db->insert("slider",$add);
                    
                    $this->session->set_flashdata("success_req",'<div class="alert alert-success alert-dismissible" role="alert">
                                        <i class="fa fa-check"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Success!</strong> Your Slider added successfully...
                                    </div>');
                    redirect('admin/addslider');
                }
            }
        $this->load->view('admin/slider/addslider2',$data);
        }
        else
        {
            redirect('admin');
        }
    }
 
    public function listslider()
    {
        if(_is_user_login($this)){
           $data["error"] = "";
           $data["active"] = "listslider";
           $this->load->model("slider_model");
           $data["allslider"] = $this->slider_model->get_slider();
           $this->load->view('admin/slider/listslider2',$data);
        }
        else
        {
            redirect('admin');
        }
    }
    
    
    public function add_Banner()
    {
       if(_is_user_login($this)){
           
            $data["error"] = "";
            $data["active"] = "addslider";
            
            if(isset($_REQUEST["addslider"]))
            {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('slider_title', 'Slider Title', 'trim|required');
                if (empty($_FILES['slider_img']['name']))
                {
                    $this->form_validation->set_rules('slider_img', 'Slider Image', 'required');
                }
                
                if ($this->form_validation->run() == FALSE)
                {
                      $data["error"] = '<div class="alert alert-warning alert-dismissible" role="alert">
                                        <i class="fa fa-warning"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Warning!</strong> '.$this->form_validation->error_string().'
                                    </div>';
                }
                else
                {
                    $add = array(
                                    "slider_title"=>$this->input->post("slider_title"),
                                    "slider_status"=>$this->input->post("slider_status"),
                                    "slider_url"=>$this->input->post("slider_url"),
                                    "sub_cat"=>$this->input->post("sub_cat")
                                    );
                    
                        if($_FILES["slider_img"]["size"] > 0){
                            $config['upload_path']          = './uploads/sliders/';
                            $config['allowed_types']        = 'gif|jpg|png|jpeg';
                            $this->load->library('upload', $config);
            
                            if ( ! $this->upload->do_upload('slider_img'))
                            {
                                    $error = array('error' => $this->upload->display_errors());
                            }
                            else
                            {
                                $img_data = $this->upload->data();
                                $add["slider_image"]=$img_data['file_name'];
                            }
                            
                       }
                       
                       $this->db->insert("banner",$add);
                    
                    $this->session->set_flashdata("success_req",'<div class="alert alert-success alert-dismissible" role="alert">
                                        <i class="fa fa-check"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Success!</strong> Your Slider added successfully...
                                    </div>');
                    redirect('admin/add_Banner');
                }
            }
        $this->load->view('admin/banner/addslider2',$data);
        }
        else
        {
            redirect('admin');
        }
    }
    
    //ban2
    
     public function add_Banner_2()
    {
       if(_is_user_login($this)){
           
            $data["error"] = "";
            $data["active"] = "addslider";
            
            if(isset($_REQUEST["addslider"]))
            {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('slider_title', 'Slider Title', 'trim|required');
                if (empty($_FILES['slider_img']['name']))
                {
                    $this->form_validation->set_rules('slider_img', 'Slider Image', 'required');
                }
                
                if ($this->form_validation->run() == FALSE)
                {
                      $data["error"] = '<div class="alert alert-warning alert-dismissible" role="alert">
                                        <i class="fa fa-warning"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Warning!</strong> '.$this->form_validation->error_string().'
                                    </div>';
                }
                else
                {
                    $add = array(
                                    "slider_title"=>$this->input->post("slider_title"),
                                    "slider_status"=>$this->input->post("slider_status"),
                                    "slider_url"=>$this->input->post("slider_url"),
                                    "sub_cat"=>$this->input->post("sub_cat")
                                    );
                    
                        if($_FILES["slider_img"]["size"] > 0){
                            $config['upload_path']          = './uploads/sliders/';
                            $config['allowed_types']        = 'gif|jpg|png|jpeg';
                            $this->load->library('upload', $config);
            
                            if ( ! $this->upload->do_upload('slider_img'))
                            {
                                    $error = array('error' => $this->upload->display_errors());
                            }
                            else
                            {
                                $img_data = $this->upload->data();
                                $add["slider_image"]=$img_data['file_name'];
                            }
                            
                       }
                       
                       $this->db->insert("banner_2",$add);
                    
                    $this->session->set_flashdata("success_req",'<div class="alert alert-success alert-dismissible" role="alert">
                                        <i class="fa fa-check"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Success!</strong> Your Slider added successfully...
                                    </div>');
                    redirect('admin/add_Banner');
                }
            }
        $this->load->view('admin/banner/addslider2',$data);
        }
        else
        {
            redirect('admin');
        }
    }
    
    public function banner()
    {
       if(_is_user_login($this)){
           $data["error"] = "";
           $data["active"] = "listslider";
           $this->load->model("slider_model");
           $data["allslider"] = $this->slider_model->banner();
           $this->load->view('admin/banner/listslider2',$data);
        }
        else
        {
            redirect('admin');
        }
    }
    public function banner_2()
    {
       if(_is_user_login($this)){
           $data["error"] = "";
           $data["active"] = "listslider";
           $this->load->model("slider_model");
           $data["allslider"] = $this->slider_model->banner_2();
           $this->load->view('admin/banner/listslider22',$data);
        }
        else
        {
            redirect('admin');
        }
    }
     public function notify_user($id)
    {
       if(_is_user_login($this)){
           $data['user_id']=$id;
           $this->load->view('admin/notify_user',$data);
        }
        else
        {
            redirect('admin');
        }
    }

    public function edit_banner($id)
    {
       if(_is_user_login($this))
       {
            
            $this->load->model("slider_model");
           $data["slider"] = $this->slider_model->get_banner($id);
           
            $data["error"] = "";
            $data["active"] = "listslider";
            if(isset($_REQUEST["saveslider"]))
            {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('slider_title', 'Slider Title', 'trim|required');
               
                  if ($this->form_validation->run() == FALSE)
                {
                  if($this->form_validation->error_string()!="")
                      $data["error"] = '<div class="alert alert-warning alert-dismissible" role="alert">
                                        <i class="fa fa-warning"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Warning!</strong> '.$this->form_validation->error_string().'
                                    </div>';
                }
                else
                {
                    $this->load->model("slider_model");
                    $this->slider_model->edit_banner($id); 
                    $this->session->set_flashdata("success_req",'<div class="alert alert-success alert-dismissible" role="alert">
                                        <i class="fa fa-check"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Success!</strong> Your Slider saved successfully...
                                    </div>');
                    redirect('admin/banner');
                }
            }
           $this->load->view('admin/banner/editslider2',$data);
        }
        else
        {
            redirect('admin');
        }
    }
    
    public function edit_banner2($id)
    {
       if(_is_user_login($this))
       {
            
            $this->load->model("slider_model");
           $data["slider"] = $this->slider_model->get_banner($id);
           
            $data["error"] = "";
            $data["active"] = "listslider";
            if(isset($_REQUEST["saveslider"]))
            {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('slider_title', 'Slider Title', 'trim|required');
               
                  if ($this->form_validation->run() == FALSE)
                {
                  if($this->form_validation->error_string()!="")
                      $data["error"] = '<div class="alert alert-warning alert-dismissible" role="alert">
                                        <i class="fa fa-warning"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Warning!</strong> '.$this->form_validation->error_string().'
                                    </div>';
                }
                else
                {
                    $this->load->model("slider_model");
                    $this->slider_model->edit_banner($id); 
                    $this->session->set_flashdata("success_req",'<div class="alert alert-success alert-dismissible" role="alert">
                                        <i class="fa fa-check"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Success!</strong> Your Slider saved successfully...
                                    </div>');
                    redirect('admin/banner');
                }
            }
           $this->load->view('admin/banner/editslider2',$data);
        }
        else
        {
            redirect('admin');
        }
    }
    
    public function editslider($id)
    {
       if(_is_user_login($this))
       {
            
            $this->load->model("slider_model");
           $data["slider"] = $this->slider_model->get_slider_by_id($id);
           
            $data["error"] = "";
            $data["active"] = "listslider";
            if(isset($_REQUEST["saveslider"]))
            {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('slider_title', 'Slider Title', 'trim|required');
               
                  if ($this->form_validation->run() == FALSE)
                {
                  if($this->form_validation->error_string()!="")
                      $data["error"] = '<div class="alert alert-warning alert-dismissible" role="alert">
                                        <i class="fa fa-warning"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Warning!</strong> '.$this->form_validation->error_string().'
                                    </div>';
                }
                else
                {
                    $this->load->model("slider_model");
                    $this->slider_model->edit_slider($id); 
                    $this->session->set_flashdata("success_req",'<div class="alert alert-success alert-dismissible" role="alert">
                                        <i class="fa fa-check"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Success!</strong> Your Slider saved successfully...
                                    </div>');
                    redirect('admin/listslider');
                }
            }
           $this->load->view('admin/slider/editslider2',$data);
        }
        else
        {
            redirect('admin');
        }
    }
    
    public function deleteslider($id){

        if(_is_user_login($this))
        {
            $data = array();
            $this->load->model("slider_model");
            $slider  = $this->slider_model->get_slider_by_id($id);
            if($slider){
                $this->db->query("Delete from slider where id = '".$slider->id."'");
                unlink("uploads/sliders/".$slider->slider_image);
                redirect("admin/listslider");
           }
        }
        else
        {
            redirect('admin');
        }
    }
    
    public function delete_banner($id){
        if(_is_user_login($this))
        {
            $data = array();
            $this->db->query("Delete from banner where id = '".$id."'");
            $this->load->model("slider_model");
            $slider  = $this->slider_model->get_slider_by_id($id);
            //$slider = $_GET['image'];
            redirect("admin/banner");
        }
        else
        {
            redirect('admin');
        }   
           
    }
    public function delete_banner2($id){
        if(_is_user_login($this))
        {
            $data = array();
            $this->db->query("Delete from banner_2 where id = '".$id."'");
            $this->load->model("slider_model");
            $slider  = $this->slider_model->get_slider_by_id($id);
            //$slider = $_GET['image'];
            redirect("admin/banner");
        }
        else
        {
            redirect('admin');
        }   
           
    }
    
    public function coupons(){
        if(_is_user_login($this)){
            $this->load->helper('form');
            $this->load->model('product_model');
            $this->load->library('session');
           
            $this->load->library('form_validation');
            $this->form_validation->set_rules('coupon_title', 'Coupon name', 'trim|required|max_length[6]|alpha_numeric');
            $this->form_validation->set_rules('coupon_code', 'Coupon Code', 'trim|required|max_length[6]|alpha_numeric');
            $this->form_validation->set_rules('from', 'From', 'required|callback_date_valid');
            $this->form_validation->set_rules('to', 'To', 'required|callback_date_valid');
            
            $this->form_validation->set_rules('value', 'Value', 'required|numeric');
            $this->form_validation->set_rules('cart_value', 'Cart Value', 'required|numeric');
            $this->form_validation->set_rules('restriction', 'Uses restriction', 'required|numeric');

            $data= array();
            $data['coupons'] = $this->product_model->coupon_list();
            if($this->form_validation->run() == FALSE)
            {
                $this->form_validation->set_error_delimiters('<div class="text-danger">not wor', '</div>');
                
                $this->load->view("admin/coupons/coupon_list2",$data); 
                 
            }
            else{
                $data = array(
                'coupon_name'=>$this->input->post('coupon_title'),
                'coupon_code'=> $this->input->post('coupon_code'),
                'valid_from'=> $this->input->post('from'),
                'valid_to'=> $this->input->post('to'),
                'validity_type'=> $this->input->post('product_type'),
                'product_name'=> $this->input->post('printable_name'),
                'discount_type'=> $this->input->post('discount_type'),
                'discount_value'=> $this->input->post('value'),
                'cart_value'=> $this->input->post('cart_value'),
                'uses_restriction'=> $this->input->post('restriction')
                 );
                 //print_r($data);
                 if($this->product_model->coupon($data))
                 {
                     $this->session->set_flashdata('addmessage','Coupon added Successfully.');
                    $data['coupons'] = $this->product_model->coupon_list();
                    $this->load->view("admin/coupons/coupon_list2",$data);
                 }
            }
        }
        else
        {
            redirect('admin');
        }
        
    }  

    public function add_coupons(){
        if(_is_user_login($this))
        {
            $this->load->helper('form');
            $this->load->model('product_model');
            $this->load->library('session');
           
            $this->load->library('form_validation');
            $this->form_validation->set_rules('coupon_title', 'Coupon name', 'trim|required|max_length[6]|alpha_numeric');
            $this->form_validation->set_rules('coupon_code', 'Coupon Code', 'trim|required|max_length[6]|alpha_numeric');
            $this->form_validation->set_rules('from', 'From', 'required|callback_date_valid');
            $this->form_validation->set_rules('to', 'To', 'required|callback_date_valid');
            
            $this->form_validation->set_rules('value', 'Value', 'required|numeric');
            $this->form_validation->set_rules('cart_value', 'Cart Value', 'required|numeric');
            $this->form_validation->set_rules('restriction', 'Uses restriction', 'required|numeric');

            $data= array();
            $data['coupons'] = $this->product_model->coupon_list();
            if($this->form_validation->run() == FALSE)
            {
                $this->form_validation->set_error_delimiters('<div class="text-danger">not wor', '</div>');
                
                $this->load->view("admin/coupons/add_coupons",$data); 
                 
            }else{
                $data = array(
                'coupon_name'=>$this->input->post('coupon_title'),
                'coupon_code'=> $this->input->post('coupon_code'),
                'valid_from'=> $this->input->post('from'),
                'valid_to'=> $this->input->post('to'),
                'validity_type'=> "",
                'product_name'=> "",
                'discount_type'=> "",
                'discount_value'=> $this->input->post('value'),
                'cart_value'=> $this->input->post('cart_value'),
                'uses_restriction'=> $this->input->post('restriction')
                 );
                 //print_r($data);
                 if($this->product_model->coupon($data))
                 {
                     $this->session->set_flashdata('addmessage','Coupon added Successfully.');
                    $data['coupons'] = $this->product_model->coupon_list();
                    $this->load->view("admin/coupons/add_coupons",$data);
                 }
            }
        }
    } 

    public function date_valid($date)
    {
        $parts = explode("/", $date);
        if (count($parts) == 3) {      
            if (checkdate($parts[1], $parts[0], $parts[2]))
            {
                return TRUE;
            }
        }
        $this->form_validation->set_message('date_valid', 'The Date field must be dd/mm/yyyy');
        return false;
    }

    function lookup(){  
        $this->load->model("product_model");  
        $this->load->helper("url");  
        $this->load->helper('form');
        // process posted form data  
        $keyword = $this->input->post('term');
        $type = $this->input->post('type');  
        $data['response'] = 'false'; //Set default response  
        if($type=='Category')
        {
            
        } 
        elseif ($type=='Sub Category') {
            
        }
        else{
            $query = $this->product_model->lookup($keyword); //Search DB 
        }
        if( ! empty($query) )  
        {  
            $data['response'] = 'true'; //Set response  
            $data['message'] = array(); //Create array  
            foreach( $query as $row )  
            {  
                $data['message'][] = array(   
                                          
                                        'value' => $row->product_name 
                                         
                                     );  //Add a row to array  
            }  
        }
        //print_r( $data['message']);
        if('IS_AJAX')  
        {  
            echo json_encode($data); //echo json string if ajax request 
            //$this->load->view('admin/coupons/coupon_list',$data);
        }  
        else 
        {  
            $this->load->view('admin/coupons/coupon_list',$data); //Load html view of search results  
        }  
    }  
    
    function looku(){

        $this->load->model("product_model");  
        $this->load->helper("url");  
        $this->load->helper('form');
        // process posted form data  
        $keyword = $this->input->post('term');
        $type = $this->input->post('type');  
        $data['response'] = 'false'; //Set default response  
        
            $query = $this->product_model->looku($keyword); //Search DB 
        
        if( ! empty($query) )  
        {  
            $data['response'] = 'true'; //Set response  
            $data['message'] = array(); //Create array  
            foreach( $query as $row )  
            {  
                $data['message'][] = array(   
                                          
                                        'value' => $row->title 
                                         
                                     );  //Add a row to array  
            }  
        }
        //print_r( $data['message']);
        if('IS_AJAX')  
        {  
            echo json_encode($data); //echo json string if ajax request 
            //$this->load->view('admin/coupons/coupon_list',$data);
        }  
        else 
        {  
            $this->load->view('admin/coupons/coupon_list',$data); //Load html view of search results  
        }  
    }

    function look(){

        $this->load->model("product_model");  
        $this->load->helper("url");  
        $this->load->helper('form');
        // process posted form data  
        $keyword = $this->input->post('term');
        $type = $this->input->post('type');  
        $data['response'] = 'false'; //Set default response  
        if($type=='Category')
        {
            
        } 
        elseif ($type=='Sub Category') {
            
        }
        else{
            $query = $this->product_model->look($keyword); //Search DB 
        }
        if( ! empty($query) )  
        {  
            $data['response'] = 'true'; //Set response  
            $data['message'] = array(); //Create array  
            foreach( $query as $row )  
            {  
                $data['message'][] = array(   
                                          
                                        'value' => $row->title 
                                         
                                     );  //Add a row to array  
            }  
        }
        //print_r( $data['message']);
        if('IS_AJAX')  
        {  
            echo json_encode($data); //echo json string if ajax request 
            //$this->load->view('admin/coupons/coupon_list',$data);
        }  
        else 
        {  
            $this->load->view('admin/coupons/coupon_list',$data); //Load html view of search results  
        }  
    }
    
    function lookname(){
        $name= $this->input->get("name");
        $dbi = $this->db->query("SELECT * FROM products WHERE product_name LIKE '%".$name."%';");
        $rows = $dbi->num_rows();
        if($rows != 0){
            if(!empty($name)){echo"<p class='text text-danger text-center'>Looks Product ".$name." Already Exists</p>";}else{
                echo"<p class='text text-success text-center'>All Ok..</p>";
            }
        }else{
            echo"<p class='text text-success text-center'>All Ok..</p>";
        }
        
    }

    function editCoupon($id){
        if(_is_user_login($this)){
            //echo $id;die();
            $this->load->helper('form');
            $this->load->library('form_validation');
           
            $this->load->model('product_model');

            $this->load->model('product_model');
            $this->load->library('form_validation');
            $this->form_validation->set_rules('coupon_title', 'Coupon name', 'trim|required|max_length[6]|alpha_numeric');
            $this->form_validation->set_rules('coupon_code', 'Coupon Code', 'trim|required|max_length[6]|alpha_numeric');
            $this->form_validation->set_rules('from', 'From', 'required|callback_date_valid');
            $this->form_validation->set_rules('to', 'To', 'required|callback_date_valid');

            $this->form_validation->set_rules('value', 'Value', 'required|numeric');
            $this->form_validation->set_rules('cart_value', 'Cart Value', 'required|numeric');
            $this->form_validation->set_rules('restriction', 'Uses restriction', 'required|numeric');

            $data= array();
            if($this->form_validation->run() == FALSE)
            {
                $this->form_validation->set_error_delimiters('<div class="text-danger">', '</div>');
                $data['coupon'] = $this->product_model->getCoupon($id);
                $this->load->view("admin/coupons/edit_coupon",$data); 
                 
            }
            else{
                $data = array(
                'coupon_name'=>$this->input->post('coupon_title'),
                'coupon_code'=> $this->input->post('coupon_code'),
                'valid_from'=> $this->input->post('from'),
                'valid_to'=> $this->input->post('to'),
                'validity_type'=> "",
                'product_name'=> "",
                'discount_type'=> "",
                'discount_value'=> $this->input->post('value'),
                'cart_value'=> $this->input->post('cart_value'),
                'uses_restriction'=> $this->input->post('restriction')
                 );
                 print_r($data);
                 if($this->product_model->editCoupon($id,$data)){
                    $this->session->set_flashdata('addmessage','Coupon edited Successfully.');
                    redirect("admin/coupons");
                }
            }
        }
        else
        {
            redirect('admin');
        }
    }

    function deleteCoupon($id)
    {
        if(_is_user_login($this)){
            $this->load->model('product_model');
            if($this->product_model->deleteCoupon($id))
            {
                $this->session->set_flashdata('addmessage','One Coupon deleted Successfully.');
                redirect("admin/coupons");
            }
        }
        else
        {
            redirect('admin');
        }
    }

    function cartmanage($user_id){
        $url = "".$this->config->item('base_url')."index.php/api/view_cart?user_id=".$user_id."";
        $ch = curl_init();
        //set the url, number of POST vars, POST data
        curl_setopt($ch,CURLOPT_URL,$url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        //execute post
        $result = curl_exec($ch);

        $res = json_decode($result,"false");
        $data['res'] = $res;
        $data['user_id'] = $user_id;

        $this->load->view('admin/registers/cart',$data);

    }

    function delcart($cart_id,$user_id){
        $url = "".$this->config->item('base_url')."index.php/api/delete_from_cart?cart_id=".$cart_id."";
        $ch = curl_init();
        //set the url, number of POST vars, POST data
        curl_setopt($ch,CURLOPT_URL,$url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        //execute post
        $result = curl_exec($ch);

        $res = json_decode($result,"false");
        $data['res'] = $res;

        $this->load->view('admin/registers/cart',$data);

        redirect("admin/cartmanage/".$user_id."");

    }

    function dealofday()
    {

        $this->load->model("product_model");
        $data["deal_products"]  = $this->product_model->getdealproducts(); 

        $this->load->view('admin/deal/deal_list2',$data);
    }

    function add_dealproduct(){
        $this->load->helper('form');

        if(_is_user_login($this)){
       
          

            if(isset($_POST))
            {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('prod_title', 'Product', 'trim|required');
                $this->form_validation->set_rules('deal_price', 'Price', 'trim|required');
                $this->form_validation->set_rules('start_date', 'Start Date', 'trim|required');
                $this->form_validation->set_rules('start_time', 'Start Time', 'trim|required');
                $this->form_validation->set_rules('end_date', 'End Date', 'trim|required'); 
                $this->form_validation->set_rules('end_time', 'End Time', 'trim|required');  
                
                if ($this->form_validation->run() == FALSE)
                {
                      if($this->form_validation->error_string()!="") { 
                      $this->session->set_flashdata("message", '<div class="alert alert-warning alert-dismissible" role="alert">
                                        <i class="fa fa-warning"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Warning!</strong> '.$this->form_validation->error_string().'
                                    </div>');
                 }
                                   
                }
                else
                {
                    $this->load->model("product_model");
                    $array = array( 
                    "product_name"=>$this->input->post("prod_title"), 
                    "deal_price"=>$this->input->post("deal_price"),
                    "start_date"=>$this->input->post("start_date"),
                    "start_time"=>$this->input->post("start_time"),
                    "end_date"=>$this->input->post("end_date"),
                    "end_time"=>$this->input->post("end_time")
                    
                    );
                    
                    
                    $this->product_model->adddealproduct($array); 
                    $this->session->set_flashdata("message",'<div class="alert alert-success alert-dismissible" role="alert">
                                        <i class="fa fa-check"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Success!</strong> Your request added successfully...
                                    </div>');
                    redirect('admin/dealofday');
                }
            }
            
            $this->load->view("admin/deal/add2");
        }
        else
        {
            redirect('admin');
        }
    
    }
    
    function edit_deal_product($id){
       if(_is_user_login($this)){
        
            if(isset($_POST))
            {
                $this->load->library('form_validation');
                 $this->form_validation->set_rules('prod_title', 'Product', 'trim|required');
                $this->form_validation->set_rules('deal_price', 'Price', 'trim|required');
                $this->form_validation->set_rules('start_date', 'Start Date', 'trim|required');
                $this->form_validation->set_rules('start_time', 'Start Time', 'trim|required');
                $this->form_validation->set_rules('end_date', 'End Date', 'trim|required'); 
                $this->form_validation->set_rules('end_time', 'End Time', 'trim|required');  
                
                if ($this->form_validation->run() == FALSE)
                {
                   if($this->form_validation->error_string()!=""){
                      $this->session->set_flashdata("message", '<div class="alert alert-warning alert-dismissible" role="alert">
                                        <i class="fa fa-warning"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Warning!</strong> '.$this->form_validation->error_string().'
                                    </div>');
                   }
                }
                else
                {
                    $this->load->model("product_model");
                    $array = array( 
                    "product_name"=>$this->input->post("prod_title"), 
                    "deal_price"=>$this->input->post("deal_price"),
                    "start_date"=>$this->input->post("start_date"),
                    "start_time"=>$this->input->post("start_time"),
                    "end_date"=>$this->input->post("end_date"),
                    "end_time"=>$this->input->post("end_time")
                    
                    );
                    
                   $this->product_model->edit_deal_product($id,$array); 
                    $this->session->set_flashdata("message",'<div class="alert alert-success alert-dismissible" role="alert">
                                        <i class="fa fa-check"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Success!</strong> Your request edited successfully...
                                    </div>');
                    redirect('admin/dealofday');
                }
            }
            $this->load->model("product_model");
            $data["product"] = $this->product_model->getdealproduct($id);
            $this->load->view("admin/deal/edit2",$data);
        }
        else
        {
            redirect('admin');
        }
    }

    function delete_deal_product($id){
        if(_is_user_login($this)){
            $this->db->query("Delete from deal_product where id = '".$id."'");
            redirect("admin/dealofday");
        }
        else
        {
            redirect('admin');
        }
    }

    public function feature_banner()
    {
       if(_is_user_login($this)){
           $data["error"] = "";
           $data["active"] = "listslider";
           $this->load->model("slider_model");
           $data["allslider"] = $this->slider_model->feature_banner();
           $this->load->view('admin/feature_banner/listslider2',$data);
        }
        else
        {
            redirect('admin');
        }
    }

    public function add_feature_Banner()
    {
       if(_is_user_login($this)){
           
            $data["error"] = "";
            $data["active"] = "addslider";
            
            if(isset($_REQUEST["addslider"]))
            {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('slider_title', 'Slider Title', 'trim|required');
                if (empty($_FILES['slider_img']['name']))
                {
                    $this->form_validation->set_rules('slider_img', 'Slider Image', 'required');
                }
                
                if ($this->form_validation->run() == FALSE)
                {
                      $data["error"] = '<div class="alert alert-warning alert-dismissible" role="alert">
                                        <i class="fa fa-warning"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Warning!</strong> '.$this->form_validation->error_string().'
                                    </div>';
                }
                else
                {
                    $add = array(
                                    "slider_title"=>$this->input->post("slider_title"),
                                    "slider_status"=>$this->input->post("slider_status"),
                                    "slider_url"=>$this->input->post("slider_url"),
                                    "sub_cat"=>$this->input->post("sub_cat")
                                    );
                    
                        if($_FILES["slider_img"]["size"] > 0){
                            $config['upload_path']          = './uploads/sliders/';
                            $config['allowed_types']        = 'gif|jpg|png|jpeg';
                            $this->load->library('upload', $config);
            
                            if ( ! $this->upload->do_upload('slider_img'))
                            {
                                    $error = array('error' => $this->upload->display_errors());
                            }
                            else
                            {
                                $img_data = $this->upload->data();
                                $add["slider_image"]=$img_data['file_name'];
                            }
                            
                       }
                       
                       $this->db->insert("feature_slider",$add);
                    
                    $this->session->set_flashdata("success_req",'<div class="alert alert-success alert-dismissible" role="alert">
                                        <i class="fa fa-check"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Success!</strong> Your Slider added successfully...
                                    </div>');
                    redirect('admin/feature_banner');
                }
            }
        $this->load->view('admin/feature_banner/addslider2',$data);
        }
        else
        {
            redirect('admin');
        }
    }
        
    public function edit_feature_banner($id)
    {
       if(_is_user_login($this))
       {
            
            $this->load->model("slider_model");
           $data["slider"] = $this->slider_model->get_feature_banner($id);
           
            $data["error"] = "";
            $data["active"] = "listslider";
            if(isset($_REQUEST["saveslider"]))
            {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('slider_title', 'Slider Title', 'trim|required');
               
                  if ($this->form_validation->run() == FALSE)
                {
                  if($this->form_validation->error_string()!="")
                      $data["error"] = '<div class="alert alert-warning alert-dismissible" role="alert">
                                        <i class="fa fa-warning"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Warning!</strong> '.$this->form_validation->error_string().'
                                    </div>';
                }
                else
                {
                    $this->load->model("slider_model");
                    $this->slider_model->edit_feature_banner($id); 
                    $this->session->set_flashdata("success_req",'<div class="alert alert-success alert-dismissible" role="alert">
                                        <i class="fa fa-check"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Success!</strong> Your Slider saved successfully...
                                    </div>');
                    redirect('admin/feature_banner');
                }
            }
           $this->load->view('admin/feature_banner/editslider2',$data);
        }
        else
        {
            redirect('admin');
        }
    }

    public function delete_feature_banner($id){
        if(_is_user_login($this)){
            $data = array();
            $this->db->query("Delete from feature_slider where id = '".$id."'");
            unlink("uploads/sliders/".$slider->slider_image);
            redirect("admin/feature_banner");
        }
        else
        {
            redirect('admin');
        }   
    }
        
    public function help()
    {
        if(_is_user_login($this)){
           
            $data["error"] = "";
            $data["active"] = "addcat";
            if(isset($_REQUEST["addcatg"]))
            {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('mobile', 'Categories Title', 'trim|required');
                $this->form_validation->set_rules('email', 'Categories Parent', 'trim|required');
                
                if ($this->form_validation->run() == FALSE)
                {
                   if($this->form_validation->error_string()!=""){
                      $data["error"] = '<div class="alert alert-warning alert-dismissible" role="alert">
                                        <i class="fa fa-warning"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Warning!</strong> '.$this->form_validation->error_string().'
                                    </div>';
                    }
                }
                else
                {
                    $this->load->model("category_model");
                    $this->category_model->add_category(); 
                    $this->session->set_flashdata("success_req",'<div class="alert alert-success alert-dismissible" role="alert">
                                        <i class="fa fa-check"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Success!</strong> Your request Send successfully...
                                    </div>');
                    redirect('admin/addcategories');
                }
            }
            $this->load->view('admin/help/form');
        }
        else
        {
            redirect('admin');
        }
    }
        
   
    
    // public function payment(){
    //     if(_is_user_login($this)){
    //     $data["paypal"]=$this->db->query("SELECT status FROM `paypal` where id = 1");
    //     $data["razor"]=$this->db->query("SELECT status FROM `razorpay` where id = 1");
    //     $this->load->view("admin/payment/list",$data);
    //     }
    //     else
    //     {
    //         redirect('admin');
    //     }
    // }

    // public function paypal_detail(){
        
    //     if(_is_user_login($this)){
               
    //         $data["error"] = "";
    //         $data["active"] = "pp";
    //         if(isset($_POST["pp"]))
    //         {
    //             $this->load->library('form_validation');
    //             $this->form_validation->set_rules('client_id', 'Client ID', 'trim|required');
                
    //             if ($this->form_validation->run() == FALSE)
    //             {
    //                if($this->form_validation->error_string()!=""){
    //                   $data["error"] = '<div class="alert alert-warning alert-dismissible" role="alert">
    //                                     <i class="fa fa-warning"></i>
    //                                   <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
    //                                   <strong>Warning!</strong> '.$this->form_validation->error_string().'
    //                                 </div>';
    //                 }
    //             }
    //             else
    //             {
    //                 $client_id = $this->input->post("client_id");
    //                 //$emp_fullname = $this->input->post("emp_fullname");
    //                 $status = ($this->input->post("status")=="on")? 1 : 0;
    //                 $array = array(
    //                     'client_id'=>$client_id,
    //                     'status'=>$status
    //                     );
                    
    //                 $this->load->model("common_model");
    //                 $this->common_model->data_update("paypal",$array,array("id"=>1)); 
    //                 $this->session->set_flashdata("success_req",'<div class="alert alert-success alert-dismissible" role="alert">
    //                                     <i class="fa fa-check"></i>
    //                                   <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
    //                                   <strong>Success!</strong> Your request Send successfully...
    //                                 </div>');
    //                 redirect('admin/payment');
    //             }
    //         }
                

    //         $data["paypal"]=$this->db->query("SELECT * FROM `paypal` where id = 1");
    //         $this->load->view("admin/payment/edit_paypal",$data);
    //     }
    //     else
    //     {
    //         redirect('admin');
    //     }
         
    // }
    
    // public function razorpay_detail(){
    //     if(_is_user_login($this)){
    //         $data["error"] = "";
    //         $data["active"] = "pp";
    //         if(isset($_POST["pp"]))
    //         {
    //             $this->load->library('form_validation');
    //             $this->form_validation->set_rules('api_key', 'Client ID', 'trim|required');
                
    //             if ($this->form_validation->run() == FALSE)
    //             {
    //                if($this->form_validation->error_string()!=""){
    //                   $data["error"] = '<div class="alert alert-warning alert-dismissible" role="alert">
    //                                     <i class="fa fa-warning"></i>
    //                                   <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
    //                                   <strong>Warning!</strong> '.$this->form_validation->error_string().'
    //                                 </div>';
    //                 }
    //             }
    //             else
    //             {
    //                 $api_key = $this->input->post("api_key");
    //                 //$emp_fullname = $this->input->post("emp_fullname");
    //                 $status = ($this->input->post("status")=="on")? 1 : 0;
    //                 $array = array(
    //                     'api_key'=>$api_key,
    //                     'status'=>$status
    //                     );
                    
    //                 $this->load->model("common_model");
    //                 $this->common_model->data_update("razorpay",$array,array("id"=>1)); 
    //                 $this->session->set_flashdata("success_req",'<div class="alert alert-success alert-dismissible" role="alert">
    //                                     <i class="fa fa-check"></i>
    //                                   <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
    //                                   <strong>Success!</strong> Your request Send successfully...
    //                                 </div>');
    //                 redirect('admin/payment');
    //             }
    //         }
            

    //         $data["razor"]=$this->db->query("SELECT * FROM `razorpay` where id = 1");
    //         $this->load->view("admin/payment/edit_razorpay",$data);
    //     }
    //     else
    //     {
    //         redirect('admin');
    //     }
         
    // }

    public function open_app(){
        if(_is_user_login($this))
        {
            $q = $this->db->query("SELECT * FROM `open_app`");
            $data["openapp"]=$q->result();
            
            $this->load->view("admin/open_app",$data);
        }
         else
            {
                redirect('admin');
            }
    }
    
    public function pos(){
        if(_is_user_login($this))
        {
            $q = $this->db->query("SELECT * FROM `products`");
            $data["openapp"]=$q->result();
            
            $this->load->view("admin/pos_app",$data);
        }
         else
            {
                redirect('admin');
            }
    }
    
    public function editoap($id){
        if(_is_user_login($this)){
            $q = $this->db->query("select * from open_app where id = '".$id."';");
            $data["openapp"]=$q->result();
            
            $this->load->view("admin/editoapp",$data);
        }else{
            redirect("admin");
        }
    }
    
    public function suc_editop(){
        if(_is_user_login($this)){
            $q = $this->db->query("select * from open_app where id = '1';");
            $data["openapp"]=$q->result();
            
            if($_FILES["image"]["size"] > 0){
                        $config['upload_path']          = './uploads/open_app/';
                        $config['allowed_types']        = 'gif|jpg|png|jpeg';
                        $this->load->library('upload', $config);
        
                        if ( ! $this->upload->do_upload('image'))
                        {
                                $error = array('error' => $this->upload->display_errors());
                        }
                        else
                        {
                            $img_data = $this->upload->data();
                            $image=$img_data['file_name'];
                        }
                        
            }
         //   $image = "";
            $title = $this->input->post("title");
            $is_v = $this->input->post("is_v");
            $this->db->query("UPDATE `open_app` SET `title` = '$title', `image` = '$image', `is_visible` = '$is_v' WHERE `open_app`.`id` = 1;");
            
            redirect("admin/open_app");
        }else{
            redirect("admin");
        }
    }

    // public function edit_ads($id){
    //     if(_is_user_login($this)){
    //         $data["error"] = "";
    //         $data["active"] = "pp";
    //         if(isset($_POST["pp"]))
    //         {
    //             $this->load->library('form_validation');
    //             $this->form_validation->set_rules('ads_key', 'Client ID', 'trim|required');
                
    //             if ($this->form_validation->run() == FALSE)
    //             {
    //                if($this->form_validation->error_string()!=""){
    //                   $data["error"] = '<div class="alert alert-warning alert-dismissible" role="alert">
    //                                     <i class="fa fa-warning"></i>
    //                                   <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
    //                                   <strong>Warning!</strong> '.$this->form_validation->error_string().'
    //                                 </div>';
    //                 }
    //             }
    //             else
    //             {
    //                 $ads_key = $this->input->post("ads_key");
    //                 $status = ($this->input->post("status")=="on")? 1 : 0;
    //                 $array = array(
    //                     'ads_key'=>$ads_key,
    //                     'status'=>$status
    //                     );
                    
    //                 $this->load->model("common_model");
    //                 $this->common_model->data_update("ads",$array,array("id"=>$id)); 
    //                 $this->session->set_flashdata("success_req",'<div class="alert alert-success alert-dismissible" role="alert">
    //                                     <i class="fa fa-check"></i>
    //                                   <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
    //                                   <strong>Success!</strong> Your request Send successfully...
    //                                 </div>');
    //                 redirect('admin/ads');
    //             }
    //         }
            

    //         $data["ads"]=$this->db->query("SELECT * FROM `ads` where id ='".$id."'");
    //         $this->load->view("admin/ads/edit_ads",$data);
    //     }
    //     else
    //     {
    //         redirect('admin');
    //     }
         
    // }
    
    public function user_action($user_id){
        if(_is_user_login($this)){
        
            if(isset($_POST['profile']))
            {
                $this->load->library('form_validation');
                $this->form_validation->set_rules('name', 'Name', 'trim|required');
                $this->form_validation->set_rules('email', 'Email', 'trim|required');
                $this->form_validation->set_rules('password', 'Password', 'trim|required');
                
                if ($this->form_validation->run() == FALSE)
                {
                   if($this->form_validation->error_string()!=""){
                      $this->session->set_flashdata("message", '<div class="alert alert-warning alert-dismissible" role="alert">
                                        <i class="fa fa-warning"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Warning!</strong> '.$this->form_validation->error_string().'
                                    </div>');
                   }
                }
                else
                {
                    extract($_POST);
                    $status = ($this->input->post("status")=="on")? 1 : 0;
                    $this->db->select('user_password'); // Change it to what column name you have for id
                      $this->db->from('registers');
                      $this->db->where('user_id',$user_id ); // 'Yes' or 'yes', depending on what you have in db
                      $query = $this->db->get();
                      $pass= $query->row();
                    
                    if($pass->user_password==$password) 
                    {
                        $password_new=$password;
                    }
                    else
                    {
                        $password_new=md5($password);
                    }
                    
                    $update=$this->db->query("UPDATE `registers` SET `user_phone`='".$phone."',`user_fullname`='".$name."',`user_email`='".$email."',`user_password`='".$password_new."',`socity_id`='".$society."',`house_no`='".$home."',status='".$status."' WHERE `user_id`='".$user_id."'");
                    if(!$update){
                        redirect('admin/registers');
                    }
                    
                   //$this->product_model->edit_deal_product($id,$array); 
                    $this->session->set_flashdata("message",'<div class="alert alert-success alert-dismissible" role="alert">
                                        <i class="fa fa-check"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Success!</strong> Your request edited successfully...
                                    </div>');
                    redirect('admin/registers');
                }
            }
            
            if(isset($_POST['amount']))
            {


                $this->load->library('form_validation');
                $this->form_validation->set_rules('wallet', 'Name', 'trim|required');
                $this->form_validation->set_rules('rewards', 'Email', 'trim|required');
                
                if ($this->form_validation->run() == FALSE)
                {
                   if($this->form_validation->error_string()!=""){
                      $this->session->set_flashdata("message", '<div class="alert alert-warning alert-dismissible" role="alert">
                                        <i class="fa fa-warning"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Warning!</strong> '.$this->form_validation->error_string().'
                                    </div>');
                   }
                }
                else
                {
                    extract($_POST);
                    
                    $update=$this->db->query("UPDATE `registers` SET `wallet`='".$wallet."',`rewards`='".$rewards."' WHERE `user_id`='".$user_id."'");
                    if(!$update){
                        //header('location:w3school.com');
                        echo '<script language="javascript"> alert(Somthing Went Wrong. Uodate Not Successfull. ) </script>';
                        exit;
                    }
                    
                   //$this->product_model->edit_deal_product($id,$array); 
                    $this->session->set_flashdata("message",'<div class="alert alert-success alert-dismissible" role="alert">
                                        <i class="fa fa-check"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                      <strong>Success!</strong> Your request edited successfully...
                                    </div>');
                    redirect('admin/registers');
                }
            }
            $this->load->model("product_model");
            $qry=$this->db->query("SELECT * FROM `registers` where user_id = '".$user_id."'");
            $data["user"] = $qry->result();
            $data["order"] = $this->product_model->get_sale_orders(" and sale.user_id = '".$user_id."' AND sale.status=4 ");
            $this->load->view("admin/registers/useraction",$data);
        }
        else
        {
            redirect('admin');
        }
    }
    
    public function notification22(){
        if(_is_user_login($this)){
            $serverObject = new SendNotification(); 
            $jsonString = $serverObject->sendPushNotificationToFCMSever( $token, $message, $order_id );  
            $jsonObject = json_decode($jsonString);
            return $jsonObject;
        }
        else
        {
            redirect('admin');
        }
    
    }
    
    // public function language_status()
    // {
    //    if(_is_user_login($this))
    //    {
    //         $q = $this->db->query("select * from `language_setting` WHERE id=1");
    //         $data["status"] = $q->row();
            
    //         $data["error"] = "";
    //         $data["active"] = "listcat";
    //         if(isset($_REQUEST["update"]))
    //         {
    //             extract($_POST);
    //             if($status=="")
    //             {
    //                 $status="0";
    //             }

    //             $this->load->library('form_validation');
    //             $update=$this->db->query("UPDATE `language_setting` SET `status`='".$status."' WHERE `id`=1 ");
                

    //             if (!$update)
    //             {
                   
    //                   $data["error"] = '<div class="alert alert-warning alert-dismissible" role="alert">
    //                                     <i class="fa fa-warning"></i>
    //                                   <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
    //                                   <strong>Warning!</strong> Update Not Successfull. Something wents Wrong</div>';
                   
    //             }
    //             else
    //             {
    //                 $this->session->set_flashdata("success_req",'<div class="alert alert-success alert-dismissible" role="alert">
    //                                     <i class="fa fa-check"></i>
    //                                   <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
    //                                   <strong>Success!</strong> Update Successfull </div>');
    //                 redirect('admin/language_status');
    //             }
    //         }
    //        $this->load->view('admin/setting/language',$data);
    //     }
    //     else
    //     {
    //         redirect('admin');
    //     }
    // }
    
    public function mobile_number()
    {
        $q = $this->db->query("select * from `tbl_numbers` WHERE id=1");
        $data["numbers"] = $q->row();
        
        if(isset($_REQUEST["update"]))
        {
            extract($_POST);

            $update=$this->db->query("UPDATE `tbl_numbers` SET `whatsapp`='".$whatsapp."',`calling`='".$call."' WHERE `id`=1");
            

            if (!$update)
            {
                $data["error"] = '<div class="alert alert-warning alert-dismissible" role="alert">
                                    <i class="fa fa-warning"></i>
                                  <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                  <strong>Warning!</strong> Update Not Successfull. Something wents Wrong</div>';
                
            }
            else
            {
                $this->session->set_flashdata("success_req",'<div class="alert alert-success alert-dismissible" role="alert">
                                    <i class="fa fa-check"></i>
                                  <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                  <strong>Success!</strong> Update Successfull </div>');
                redirect('admin/mobile_number');
            }
        }
        $q = $this->db->query("select * from `tbl_numbers` WHERE id=1");
        $data["numbers"] = $q->row();
        $this->load->view('admin/number_update',$data);
            
    }
     
     /* user registration */               
public function add_user(){
       $data = array(); 
            $_POST = $_REQUEST;      
                $this->load->library('form_validation');
                /* add registers table validation */
                $this->form_validation->set_rules('user_name', 'Full Name', 'trim|required');
                $this->form_validation->set_rules('user_mobile', 'Mobile Number', 'trim|required|is_unique[registers.user_phone]');
                $this->form_validation->set_rules('user_email', 'User Email', 'trim|required|is_unique[registers.user_email]');
                 $this->form_validation->set_rules('password', 'Password', 'trim|required');
                
                
                if ($this->form_validation->run() == FALSE) 
                {
                    // $data["responce"] = false;  
                    // $data["error"] = strip_tags($this->form_validation->error_string());

                    redirect("admin/adduser?error=1");
                    
                    
                }else
                {
                    
                    $date = date('d/m/y');
                    $this->db->insert("registers", array("user_phone"=>$this->input->post("user_mobile"),
                                             "user_fullname"=>$this->input->post("user_name"),
                                             "user_email"=>$this->input->post("user_email"),
                                             "user_password"=>md5($this->input->post("password")),
                                            "status" => 1
                                            ));
                    $user_id =  $this->db->insert_id();  
                   
                   redirect("admin/adduser?error=0");
                    
                  }                  
           
                   //  echo json_encode($data);
}     

function delete_install(){
    error_reporting(0);
    unlink("install/index.php");
    unlink("install/error_log");
    unlink("install/database.sql");
   $rmdir =  rmdir("install/");

    if ($rmdir) {
        ?>
        <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="<?php echo base_url($this->config->item("new_theme")."/assets/img/apple-icon.png"); ?>" />
    <link rel="icon" type="image/png" href="<?php echo base_url($this->config->item("new_theme")."/assets/img/favicon.png"); ?>" />
    <title><?php echo $this->config->item('company_title');  ?> | Dashboard</title>
    <!-- Canonical SEO -->
    <link rel="canonical" href="https://www.creative-tim.com/product/material-dashboard-pro" />
    <!--  Social tags      -->
    <!-- Bootstrap core CSS     -->
    <link href="<?php echo base_url($this->config->item("new_theme")."/assets/css/bootstrap.min.css"); ?>" rel="stylesheet" />
    <!--  Material Dashboard CSS    -->
    <link href="<?php echo base_url($this->config->item("new_theme")."/assets/css/material-dashboard.css"); ?>" rel="stylesheet" />
    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="<?php echo base_url($this->config->item("new_theme")."/assets/css/demo.css"); ?>" rel="stylesheet" />
    <!--     Fonts and icons     -->
    <link href="<?php echo base_url($this->config->item("new_theme")."/assets/css/font-awesome.css"); ?>" rel="stylesheet" />
    <link href="<?php echo base_url($this->config->item("new_theme")."/assets/css/google-roboto-300-700.css"); ?>" rel="stylesheet" />

    <div class="alert alert-success">
          Success
       </div>
        <?php
    }else{ ?>
        <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="<?php echo base_url($this->config->item("new_theme")."/assets/img/apple-icon.png"); ?>" />
    <link rel="icon" type="image/png" href="<?php echo base_url($this->config->item("new_theme")."/assets/img/favicon.png"); ?>" />
    <title><?php echo $this->config->item('company_title');  ?> | Dashboard</title>
    <!-- Canonical SEO -->
    <link rel="canonical" href="https://www.creative-tim.com/product/material-dashboard-pro" />
    <!--  Social tags      -->
    <!-- Bootstrap core CSS     -->
    <link href="<?php echo base_url($this->config->item("new_theme")."/assets/css/bootstrap.min.css"); ?>" rel="stylesheet" />
    <!--  Material Dashboard CSS    -->
    <link href="<?php echo base_url($this->config->item("new_theme")."/assets/css/material-dashboard.css"); ?>" rel="stylesheet" />
    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="<?php echo base_url($this->config->item("new_theme")."/assets/css/demo.css"); ?>" rel="stylesheet" />
    <!--     Fonts and icons     -->
    <link href="<?php echo base_url($this->config->item("new_theme")."/assets/css/font-awesome.css"); ?>" rel="stylesheet" />
    <link href="<?php echo base_url($this->config->item("new_theme")."/assets/css/google-roboto-300-700.css"); ?>" rel="stylesheet" />
       <div class="alert alert-danger">
           Error
       </div>
        <?php
    }
}
   
}


