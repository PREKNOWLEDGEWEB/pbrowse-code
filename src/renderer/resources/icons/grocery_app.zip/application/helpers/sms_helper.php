<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
function send_sms($mobilenumber,$textmessage){
   
    return true;
}
?>