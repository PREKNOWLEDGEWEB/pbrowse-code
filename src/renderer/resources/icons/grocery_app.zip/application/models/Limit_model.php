<?php
class limit_model extends CI_Model 
{
   /*View*/
	function get_lim2()
	{
	$query=$this->db->query("SELECT * FROM `limit_settings`");
	return $query->result();
	}
	function update($limit,$limit2)
	{
	$query=$this->db->query("UPDATE `limit_settings` SET `liset` = '$limit', `liset2` = '$limit2' WHERE `limit_settings`.`id` = 1");
	}
	
} 