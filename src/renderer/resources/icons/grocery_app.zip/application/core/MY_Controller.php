<?php
Class MY_Controller Extends CI_Controller{

    public function __construct(){
        parent::__construct();
        if($this->session->userdata('language') == "arabic"){
            $this->lang->load('ps', 'arabic');
        }else{
            $this->lang->load('ps', 'english');
        }
        if($this->input->get('lang')){
            if($this->input->get('lang') == "arabic"){
                 $this->session->set_userdata(array("language"=>$this->input->get('lang')));
                  $this->lang->load('ps', $this->input->get('lang'));
            }elseif($this->input->get('lang') == "english"){
                $this->session->set_userdata(array("language"=>$this->input->get('lang')));
                 $this->lang->load('ps', $this->input->get('lang'));
            }
            elseif($this->input->get('lang') == "en"){
                $this->session->set_userdata(array("language"=>"english"));
                $this->lang->load('ps', "english");
            }
            elseif($this->input->get('lang') == "ar"){
                $this->session->set_userdata(array("language"=>"arabic"));
                $this->lang->load('ps', "arabic");
            }else{
                 $this->session->set_flashdata('welcome',' toastr["error"]("Error", "Language not found")

                            toastr.options = {
                              "closeButton": true,
                              "debug": false,
                              "newestOnTop": true,
                              "progressBar": true,
                              "positionClass": "toast-top-right",
                              "preventDuplicates": true,
                              "onclick": null,
                              "showDuration": "300",
                              "hideDuration": "1000",
                              "timeOut": "5000",
                              "extendedTimeOut": "1000",
                              "showEasing": "swing",
                              "hideEasing": "linear",
                              "showMethod": "fadeIn",
                              "hideMethod": "fadeOut"
                            }'); 
                redirect("admin/dashboard");
            }
            
           
        }
    }
    
}
?>