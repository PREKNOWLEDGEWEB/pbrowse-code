<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#"><?php echo $this->config->item('app_name');  ?></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="<?php echo $this->config->item('base_url');?>index.php/home">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo $this->config->item('base_url');?>index.php/home/products">Products</a>
      </li>

      <?php
      if (isset($_SESSION['customerid'])) { ?>
       <li class="nav-item">
        <a class="nav-link" href="<?php echo $this->config->item('base_url');?>index.php/account/profile">Account</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="<?php echo $this->config->item('base_url');?>index.php/cart/view_cart">Cart</a>
      </li>
      <?php }else{ ?> 
      <li class="nav-item">
        <a class="nav-link" href="<?php echo $this->config->item('base_url');?>index.php/account/login">Login</a>
      </li>   
      <?php } ?>

    </ul>
    <form class="form-inline my-2 my-lg-0" action="<?php echo $this->config->item('base_url');?>index.php/home/search" method="post">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search" name="search">
      <button class="btn btn-success my-2 my-sm-0 btn-round" type="submit"><i class="fa fa-search"></i></button>
    </form>
  </div>
</nav>