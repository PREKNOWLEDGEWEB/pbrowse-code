<div class="row" style="margin:0;">

   <?php foreach($allcat as $acat){ ?>
  <div class="col-sm-2">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title"><?php echo $acat->title; ?></h5>
        <a href="<?php echo $this->config->item('base_url'); ?>index.php/home/subcat/<?php echo $acat->id; ?>" class="btn btn-primary">View</a>
      </div>
    </div>
  </div>
   <?php } ?>
</div>