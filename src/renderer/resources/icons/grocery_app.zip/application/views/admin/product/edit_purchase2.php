
                    <?php  if(isset($error)){ echo $error; }
                        echo $this->session->flashdata('message'); 
                    ?>
                    <div class="row" id="#<?php echo $purchase->purchase_id ?>">
                        <form form action="" method="post" enctype="multipart/form-data" class="form-horizontal" >
                            <?php if($this->session->userdata('language') == "arabic")
                                {
                                ?>
                                <div class="col-md-3">
                                </div>
                                <?php
                                }
                                ?>
                        <div class="col-md-9">
                            <div class="card">
                                <div class="card-header card-header-icon" data-background-color="rose">
                                    <i class="material-icons">contacts</i>
                                </div>
                                <div class="card-content">
                                    <h4 class="card-title"><?php echo $this->lang->line("Purchase products");?></h4>
                                        <div class="row" style=" margin-top: 50px;">
                                            <label class="col-md-3 label-on-left"><?php echo $this->lang->line("Product");?>: *</label>
                                            <div class="col-md-9">
                                                <div class="form-group label-floating is-empty">
                                                    <label class="control-label"></label>
                                                    <select class="text-input form-control" id="idp" name="product_id">
                                                        <?php foreach($products as $product)
                                                        {
                                                            ?>
                                                            <option value="<?php echo $product->product_id; ?>" <?php if($product->product_id == $purchase->product_id) { echo "selected"; } ?> >
                                                                <?= $product->product_name; ?>
                                                            </option>
                                                        <?php } ?>
                                                    </select>
                                                <span class="material-input"></span></div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <label class="col-md-3 label-on-left"><?php echo $this->lang->line("(Qty must be in KG or NOS) 1000gram = 1 KG");?></label>
                                            <div class="col-md-9">
                                                <div class="form-group label-floating is-empty">
                                                    <input type="text" id="pqty" name="qty" class="form-control" value="<?php echo $purchase->qty; ?>"  placeholder="00"/>
                                                <span class="material-input"></span></div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <label class="col-md-3 label-on-left"><?php echo $this->lang->line("Unit");?>:</label>
                                            <div class="col-md-9">
                                                <div class="form-group label-floating is-empty" >
                                                    <input type="unit" id="qunit" name="unit" class="form-control" value="<?php echo $purchase->unit; ?>"placeholder="KG/ BAG/ NOS/ QTY / etc"/>
                                                <span class="material-input"></span></div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <label class="col-md-3"></label>
                                            <div class="col-md-9">
                                                <div class="form-group form-button">
                                                    
                                                </div>
                                            </div>
                                        </div>
                                </div>
                            </div>
                        </div>
                        </form>
                    </div>
                </div>
                <!--<button  class="btn btn-fill btn-rose" onclick="finaledit($purchase->purchase_id)">-->
                <!--                                    <?php echo $this->lang->line("Save Purchase");?></button>-->
                <a href="#" onclick="finaledit(<?php echo $purchase->purchase_id ?>)" class="btn btn-fill btn-rose">Save</a>
            