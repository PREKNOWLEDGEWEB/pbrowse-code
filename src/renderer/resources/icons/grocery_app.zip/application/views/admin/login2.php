<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="<?php echo base_url($this->config->item("new_theme")."/assets/img/apple-icon.png");?>" />
     <title><?php echo $this->config->item('company_title');  ?> | Login</title>
    <link rel="icon" type="image/png" href="<?php echo base_url($this->config->item("new_theme")."/assets/img/favicon.png"); ?>" />
    <!-- Canonical SEO -->
    <link rel="canonical" href="//www.creative-tim.com/product/material-dashboard-pro" />
    <!--  Social tags      -->
    <!-- Bootstrap core CSS     -->
    <link href="<?php echo base_url($this->config->item("new_theme")."/assets/css/bootstrap.min.css"); ?>" rel="stylesheet" />
    <!--  Material Dashboard CSS    -->
    <link href="<?php echo base_url($this->config->item("new_theme")."/assets/css/material2.css"); ?>" rel="stylesheet" />
    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="<?php echo base_url($this->config->item("new_theme")."/assets/css/demo.css"); ?>" rel="stylesheet" />
    <!--     Fonts and icons     -->
    <link href="<?php echo base_url($this->config->item("new_theme")."/assets/css/font-awesome.css"); ?>" rel="stylesheet" />
    <link href="<?php echo base_url($this->config->item("new_theme")."/assets/css/google-roboto-300-700.css"); ?>" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>

<body style="background-color: white;">
    <nav class="navbar navbar-primary navbar-transparent navbar-absolute">
        <div class="container">
            <div class="navbar-header">
               
               <!-- <a class="navbar-brand" href="../dashboard.html">Material Dashboard Pro</a>-->
            </div>
            <div class="collapse navbar-collapse">
                <ul class="nav navbar-nav navbar-right">
                    <li>
                       <!-- <a href="../dashboard.html">
                            <i class="material-icons">dashboard</i> Dashboard
                        </a> -->
                    </li>
                    <!--<li class="">
                        <a href="register.html">
                            <i class="material-icons">person_add</i> Register
                        </a>
                    </li>-->
                    <li class=" active ">
                        <a href="#">
                            <i class="material-icons">fingerprint</i> Login
                        </a>
                    </li>
        
                </ul>
            </div>
        </div>
    </nav>
    <div class="wrapper wrapper-full-page">
        <div class="full-page login-page" data-image="<?php echo base_url($this->config->item("new_theme")."/assets/img/login.jpg"); ?>">
            <!--   you can change the color of the filter page using: data-color="blue | purple | green | orange | red | rose " -->
            <div class="content">
                <div class="container">
                    <div class="row">
                        <div class="col-md-4 col-sm-6 col-md-offset-4 col-sm-offset-3">
                            <?php if(isset($error) && $error!=""){
                            echo $error;
                        } ?>
                       <div class="alert alert-success alert-dismissible" role="alert" style="display: none;" id="success">
                        <b id="area"></b>
                                  <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                       </div>

                       <div class="alert alert-danger alert-dismissible" role="alert" style="display: none;" id="danger">
                        <b id="darea"></b>
                                  <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                       </div>
                            <form method="post" action="<?php echo $this->config->item('base_url').'index.php/admin/login_admin' ?>">
                               <img src="<?php echo $this->config->item('base_url').'/new_theme/assets/img/apple-icon.png' ?>" height="120px" style="border-radius:50%; margin-left:35%;box-shadow:0px 2px 25px 10px #fff;" >
                                <div class="card card-login">
                                    <div class="card-header text-center" data-background-color="blue">
									    <h3 class="card-title" style="line-height:3px">Admin<h3>
                                        <h4 >Login</h4>
                                        <!--<div class="social-line">-->
                                        <!--    <a href="#btn" class="btn btn-just-icon btn-simple">-->
                                        <!--        <i class="fa fa-facebook-square"></i>-->
                                        <!--    </a>-->
                                        <!--    <a href="#pablo" class="btn btn-just-icon btn-simple">-->
                                        <!--        <i class="fa fa-twitter"></i>-->
                                        <!--    </a>-->
                                        <!--    <a href="#eugen" class="btn btn-just-icon btn-simple">-->
                                        <!--        <i class="fa fa-google-plus"></i>-->
                                        <!--    </a>-->
                                        <!--</div> -->
                                    </div>
                                    <!--<p class="category text-center">-->
                                    <!--    <h4>Chilka Admin</h4>-->
                                    <!--</p>-->
                                    <div class="card-content">
                                        <!--div class="input-group">
                                            <span class="input-group-addon">
                                                <i class="material-icons">face</i>
                                            </span>
                                            <div class="form-group label-floating">
                                                <label class="control-label">First Name</label>
                                                <input type="text" class="form-control">
                                            </div>
                                        </div-->
                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                <i class="material-icons">email</i>
                                            </span>
                                            <div class="form-group label-floating">
                                                <label class="control-label">Admin</label>
                                                <input type="email" name="email" class="form-control" id="email">
                                            </div>
                                        </div>
                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                <i class="material-icons">lock_outline</i>
                                            </span>
                                            <div class="form-group label-floating">
                                                <label class="control-label">Password</label>
                                                <input type="password" name="password" class="form-control" id="password">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="footer text-center">
                                        <button type="submit" class="btn btn-rose btn-round" id="logintoapp">Signin</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <footer class="footer">
                <div class="container">
                    <!--<nav class="pull-left">
                        <ul>
                            <li>
                                <a href="#">
                                    Home
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    Company
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    Portfolio
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    Blog
                                </a>
                            </li>
                        </ul>>
                    </nav>-->
                   <p class="copyright pull-right">
                        &copy;
                        <script>
                            document.write(new Date().getFullYear())
                        </script>
                        <a href="http://www.Chilka.in/"></a>
                    </p>
                </div>
            </footer>
        </div>
    </div>
</body>

</div>
</body>
<!--   Core JS Files   -->
<script src="<?php echo base_url($this->config->item("new_theme")."/assets/js/jquery-3.1.1.min.js"); ?>" type="text/javascript"></script>
<script src="<?php echo base_url($this->config->item("new_theme")."/assets/js/jquery-ui.min.js"); ?>" type="text/javascript"></script>
<script src="<?php echo base_url($this->config->item("new_theme")."/assets/js/bootstrap.min.js"); ?>" type="text/javascript"></script>
<script src="<?php echo base_url($this->config->item("new_theme")."/assets/js/material.min.js"); ?>" type="text/javascript"></script>
<script src="<?php echo base_url($this->config->item("new_theme")."/assets/js/perfect-scrollbar.jquery.min.js"); ?>" type="text/javascript"></script>
<!-- Forms Validations Plugin -->
<script src="<?php echo base_url($this->config->item("new_theme")."/assets/js/jquery.validate.min.js"); ?>"></script>
<!--  Plugin for Date Time Picker and Full Calendar Plugin-->
<script src="<?php echo base_url($this->config->item("new_theme")."/assets/js/moment.min.js"); ?>"></script>
<!--  Charts Plugin -->
<script src="<?php echo base_url($this->config->item("new_theme")."/assets/js/chartist.min.js"); ?>"></script>
<!--  Plugin for the Wizard -->
<script src="<?php echo base_url($this->config->item("new_theme")."/assets/js/jquery.bootstrap-wizard.js"); ?>"></script>
<!--  Notifications Plugin    -->
<script src="<?php echo base_url($this->config->item("new_theme")."/assets/js/bootstrap-notify.js"); ?>"></script>
<!--   Sharrre Library    -->
<script src="<?php echo base_url($this->config->item("new_theme")."/assets/js/jquery.sharrre.js"); ?>"></script>
<!-- DateTimePicker Plugin -->
<script src="<?php echo base_url($this->config->item("new_theme")."/assets/js/bootstrap-datetimepicker.js"); ?>"></script>
<!-- Vector Map plugin -->
<script src="<?php echo base_url($this->config->item("new_theme")."/assets/js/jquery-jvectormap.js"); ?>"></script>
<!-- Sliders Plugin -->
<script src="<?php echo base_url($this->config->item("new_theme")."/assets/js/nouislider.min.js"); ?>"></script>
<!--  Google Maps Plugin    -->
<!--<script src="https://maps.googleapis.com/maps/api/js"></script>-->
<!-- Select Plugin -->
<script src="<?php echo base_url($this->config->item("new_theme")."/assets/js/jquery.select-bootstrap.js"); ?>"></script>
<!--  DataTables.net Plugin    -->
<script src="<?php echo base_url($this->config->item("new_theme")."/assets/js/jquery.datatables.js"); ?>"></script>
<!-- Sweet Alert 2 plugin -->
<script src="<?php echo base_url($this->config->item("new_theme")."/assets/js/sweetalert2.js"); ?>"></script>
<!--	Plugin for Fileupload, full documentation here: http://www.jasny.net/bootstrap/javascript/#fileinput -->
<script src="<?php echo base_url($this->config->item("new_theme")."/assets/js/jasny-bootstrap.min.js"); ?>"></script>
<!--  Full Calendar Plugin    -->
<script src="<?php echo base_url($this->config->item("new_theme")."/assets/js/fullcalendar.min.js"); ?>"></script>
<!-- TagsInput Plugin -->
<script src="<?php echo base_url($this->config->item("new_theme")."/assets/js/jquery.tagsinput.js"); ?>"></script>
<!-- Material Dashboard javascript methods -->
<script src="<?php echo base_url($this->config->item("new_theme")."/assets/js/material-dashboard.js"); ?>"></script>
<!-- Material Dashboard DEMO methods, don't include it in your project! -->
<script src="<?php echo base_url($this->config->item("new_theme")."/assets/js/demo.js"); ?>"></script>

<script>
$(document).ready(function() {
    $('#logintoapp').on('click', function() {
        $("#logintoapp").attr("disabled", "disabled");
        var email = $('#email').val();
        var password = $('#password').val();
        if(email!="" && password!=""){
            $.ajax({
                url: "<?php echo $this->config->item('base_url').'index.php/admin/login_admin' ?>",
                type: "POST",
                data: {
                    email: email,
                    password: password            
                },
                cache: false,
                success: function(dataResult){
                    var dataResult = JSON.parse(dataResult);
                    if(dataResult.statusCode==200){
                        $("#logintoapp").removeAttr("disabled");
                        $("#success").show();
                         location.replace("<?php echo $this->config->item('base_url').'index.php/admin/dashboard' ?>");
                        $('#area').html('Login Successfully');                        
                    }
                    else if(dataResult.statusCode==201){
                    $("#logintoapp").removeAttr("disabled");
                    $("#danger").show();
                    $("#success").hide();
                    $('#darea').html('Invalid Email & Password'); 
                    }
                    else if(dataResult.statusCode==205){
                    $("#logintoapp").removeAttr("disabled");
                    $("#danger").show();
                     $("#success").hide();
                    $('#darea').html('User is Inactive'); 
                    }
                    else if(dataResult.statusCode==590){
                    $("#logintoapp").removeAttr("disabled");
                    $("#danger").show();
                     $("#success").hide();
                    $('#darea').html('Form Validation Error'); 
                    }
                    else if(dataResult.statusCode==300){
                    $("#logintoapp").removeAttr("disabled");
                    $("#danger").show();
                     $("#success").hide();
                    $('#darea').html('Data not Posted'); 
                    }
                    
                }
            });
        }
        else{
             $("#logintoapp").removeAttr("disabled");
             $("#danger").show();
             $("#success").hide();
             $('#darea').html('Fill all the Fields');   
        }
    });
});
</script>

</html>