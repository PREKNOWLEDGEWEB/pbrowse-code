<div class="container" style="overflow: auto; height: 500px">
     	<a href="#" onclick="opendir('<?php echo "".$dir."/"; ?>../')" class="btn btn-primary" style="color: white ;">
     	    Go Back
     	    </a>
 <div class="row"> 
<?php
foreach ($data as $file) {
	?>
	<div class="col-lg-6 mb-4" id="f<?php echo $file ; ?>"> 
                <div class="card">
                	<?php
                	
                	?>
				  <div class="card-body">
				  	 <?php $ext = pathinfo("".$dir."/".$file."", PATHINFO_EXTENSION);?>

				  	 <?php
				  	 if ($ext == "png") {
				  	  	?>
				  	  	 <img style="width: 50px; height: auto" src="<?php echo base_url("".$dir."/".$file.""); ?>" class="card-img-top" alt="...">
				  	  	
				    	<?php echo $file ; ?>
				     	
				  	  	<?php
				 
				  	  }elseif ($ext == "jpg") {
				  	  	?>
				  	  	 <img style="width: 50px; height: auto" src="<?php echo base_url("".$dir."/".$file.""); ?>" class="card-img-top" alt="...">
				  	  	
				    	<?php echo $file ; ?>
				     	
				  	  	<?php
				  	  }elseif ($ext == "gif") {
				  	  	?>
				  	  	 <img style="width: 50px; height: auto" src="<?php echo base_url("".$dir."/".$file.""); ?>" class="card-img-top" alt="...">
				  	  	
				    	<?php echo $file ; ?>
				     	
				  	  	<?php
				  	  }elseif ($ext == "jpeg") {
				  	  	?>
				  	  	 <img style="width: 50px; height: auto" src="<?php echo base_url("".$dir."/".$file.""); ?>" class="card-img-top" alt="...">
				  	  	
				    	<?php echo $file ; ?>
				     	
				  	  	<?php
				  	  }elseif ($ext == "bmp") {
				  	  	?>
				  	  	 <img style="width: 50px; height: auto" src="<?php echo base_url("".$dir."/".$file.""); ?>" class="card-img-top" alt="...">
				  	  	
				    	<?php echo $file ; ?>
				     	
				  	  	<?php
				  	  }elseif ($ext == "zip") {
				  	  	?>
				  	  	
				    	<?php echo $file ; ?>
				    	<a href="<?php echo base_url("".$dir."/".$file.""); ?>" class="btn btn-success"><?php echo $file ; ?></a>
				     	
				  	  	<?php
				  	  }elseif ($ext == "csv") {
				  	  	?>
				  	  	
				    	<?php echo $file ; ?>
				    	<a href="<?php echo base_url("".$dir."/".$file.""); ?>" class="btn btn-success"><?php echo $file ; ?></a>
				     	
				  	  	<?php
				  	  }else{
				  	  	?>
				  	  	<a href="#" onclick="opendir('<?php echo "".$dir."/".$file."" ; ?>')" class="btn btn-primary" style="color: white ;">
				    	<?php echo $file ; ?>
				     	</a>
				  	  <?php
				  	}
				  	 ?>
				  	 <a href="#del" class="btn btn-danger btn-just-icon btn-round" onclick="del('<?php echo "".$dir."/".$file."" ; ?>','<?php echo $file ?>')"><i class="material-icons">delete</i></a>
				  </div>
				</div>
            </div> 
         <?php	
		} 
		?>
		</div>
</div>