<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>orders</title>
    <link rel="apple-touch-icon" sizes="76x76" href="<?php echo base_url($this->config->item("new_theme")."/assets/img/apple-icon.png"); ?>" />
    <link rel="icon" type="image/png" href="<?php echo base_url($this->config->item("new_theme")."/assets/img/favicon.png"); ?>" />
    <title><?php echo $this->config->item('company_title');  ?> | Orders</title>
    <!-- Canonical SEO -->
    <link rel="canonical" href="//www.creative-tim.com/product/material-dashboard-pro" />

    <!-- Bootstrap core CSS     -->
    <link href="<?php echo base_url($this->config->item("new_theme")."/assets/css/bootstrap.min.css"); ?>" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo base_url($this->config->item("theme_admin")."/bootstrap/css/bootstrap.min.css"); ?>" />
    <!--  Material Dashboard CSS    -->
    <link href="<?php echo base_url($this->config->item("new_theme")."/assets/css/material-dashboard.css"); ?>" rel="stylesheet" />
    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="<?php echo base_url($this->config->item("new_theme")."/assets/css/demo.css"); ?>" rel="stylesheet" />
    <!--     Fonts and icons     -->
    <link href="<?php echo base_url($this->config->item("new_theme")."/assets/css/font-awesome.css"); ?>" rel="stylesheet" />
    <link href="<?php echo base_url($this->config->item("new_theme")."/assets/css/google-roboto-300-700.css"); ?>" rel="stylesheet" />

    
</head>

<body>
    <div class="wrapper">
        <!--sider -->
        <?php  $this->load->view("admin/common/sidebar"); ?>
        
        <div class="main-panel">
            <!--head -->
            <?php  $this->load->view("admin/common/header"); ?>
            <!--content -->
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                              <?php echo $this->session->flashdata("message"); ?>
                              <div class="alert alert-success alert-dismissible" role="alert" style="display: none;" id="deleted">
                                     <i class="fa fa-success"></i>
                                      <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                                     <strong>Orders: has been deleted</strong>
                                  </div>
                            <div class="card">
                                
                                <div class="card-header card-header-icon" data-background-color="purple">
                                    <i class="material-icons">assignment</i>
                                </div>
                                <div class="card-content">
                                    <h4 class="card-title"><?php echo $this->lang->line("Orders List");?></h4>
                                    <!--a class="text-right" href="<?php echo site_url("admin/add_products"); ?>">ADD</a-->
                                    <div  class="toolbar">
                                        <!--        Here you can write extra buttons/actions for the toolbar              -->
                                    </div>
                                    <?php
                                   // print_r($_POST);
                                    if (isset($_POST['filter'])) {
                                        echo "<div class='alert alert-success'>
                                        DataTable was filtered Date from : ".$_POST['date_range']."
                                        to ".$_POST['date_range_lable']."
                                        <a class='btn btn-success' href='?'>Back to Normal</a>
                                        </div>";
                                     } 
                                    ?>
                                     <form action="" method="post">
                        <input type="hidden" name="date_range" id="date_range_field" />
                        <input type="hidden" name="date_range_lable" id="date_range_lable" />
                    <div class="form-group">
                        <label> <?php echo $this->lang->line("Date range button:");?></label>
                        <div class="input-group">
                          <button class="btn btn-primary" type="button" id="daterange-btn">
                            <i class="fa fa-calendar"></i> <span id="reportrange"><?php if(!empty($date_range_lable)){ echo $date_range_lable; } else { echo date("M , d Y"); } ?></span> 
                            <i class="fa fa-caret-down"></i>
                          </button>
                          <input type="submit" name="filter" class="btn active" style="border: 0; display: inline-block; width: 50px; background: linear-gradient(60deg, green, blue); ;
                            " value="Filter" />
                          
                        </div>
                      </div>
                    </form>
                                    <div class="material-datatables table-responsive">
                                        <table id="datatables" class="table table-striped table-bordered  table-hover" cellspacing="0" width="100%" style="width:100%">
                                            <thead>
                                                <tr>
                                                    <th class="text-center"><?php echo $this->lang->line("Order");?></th>
                                                    <th class="text-center"><?php echo $this->lang->line("Customer Name");?></th>
                                                    <th class="text-center"><?php echo $this->lang->line("Socity");?></th>
                                                    <th class="text-center"><?php echo $this->lang->line("Customer Phone");?> </th>
                                                    <th class="text-center"><?php echo $this->lang->line("Date");?></th>
                                                    <th class="text-center"><?php echo $this->lang->line("Order Amount");?></th>
                                           <!--          <th class="text-center"><?php echo $this->lang->line("Store");?></th> -->
                                                    <th class="text-center">Is Paid</th>
                                                    <th class="text-center"><?php echo $this->lang->line("Total Rewards");?></th>
                                                    <th class="text-center"><?php echo $this->lang->line("Payment Method");?></th>
                                                    <th class="text-center"><?php echo $this->lang->line("Status");?></th>
                                                    <th class="text-center"><?php echo $this->lang->line("Action");?></th>
                                                </tr>
                                            </thead>
                                            <tfoot>
                                                <tr>
                                                     <th class="text-center"><?php echo $this->lang->line("Order");?>ID</th>
                                                    <th class="text-center"><?php echo $this->lang->line("Customer Name");?></th>
                                                    <th class="text-center"><?php echo $this->lang->line("Socity");?></th>
                                                    <th class="text-center"><?php echo $this->lang->line("Customer Phone");?> </th>
                                                    <th class="text-center"><?php echo $this->lang->line("Date");?></th>
                                                    <th class="text-center"><?php echo $this->lang->line("Order Amount");?></th>
                                                  <!--   <th class="text-center"><?php echo $this->lang->line("Store");?></th> -->
                                                    <th class="text-center">Is Paid</th>
                                                    <th class="text-center"><?php echo $this->lang->line("Total Rewards");?></th>
                                                    <th class="text-center"><?php echo $this->lang->line("Payment Method");?></th>
                                                    <th class="text-center"><?php echo $this->lang->line("Status");?></th>
                                                    <th class="text-center"><?php echo $this->lang->line("Action");?></th>
                                                </tr>
                                            </tfoot>
                                            <tbody>
                                                <?php foreach($today_orders as $order){ ?>
                                                <tr>
                                                    <td><?php echo $order->sale_id; ?></td>
                                                    <td><?php echo $order->user_fullname; ?></td>
                                                    <td><?php echo $order->socity_name; ?></td>
                                                    <td><?php echo $order->user_phone; ?></td>
                                                    <td><?php echo $order->on_date.'<br>'.date("H:i A", strtotime($order->delivery_time_from))." - ".date("H:i A", strtotime($order->delivery_time_to)); ; ?></td>
                                                    <td><?php echo $order->total_amount; ?></td>
                                                    <!-- <td><?php echo $order->new_store_id ?></td> -->
                                                     <td>
                                                        <?php
                                                        if ($order->is_paid == "1") { ?>
                                                              <label class='label label-success'><a style="color:white;" href="<?php echo site_url("admin/unpaid/".$order->sale_id); ?>">Paid</a></label>
                                                          <?php }else{ ?>
                                                              <label class='label label-danger'><a style="color:white;" href='<?php echo site_url("admin/paid/".$order->sale_id); ?>'>UNPaid</a></label>
                                                          <?php }
                                                        ?>
                                                        
                                                     </td>
                                                    <td><?php echo $order->total_rewards; ?></td>
                                                    <td><?php echo $order->payment_method;; ?></td>
                                                    <td><?php if($order->status == 0){
                                                        echo "<span class='label label-default'>Pending</span>";
                                                    }else if($order->status == 1){
                                                        echo "<span class='label label-success'>Confirm</span>";
                                                    }else if($order->status == 2){
                                                        echo "<span class='label label-info'>Out</span>";
                                                    }else if($order->status == 3){
                                                        echo "<span class='label label-danger'>Cancel</span>";
                                                    }else if($order->status == 4){
                                                        echo "<span class='label label-info'>complete</span>";
                                                    } ?>
                                                    </td>
                    <td><a href="<?php echo site_url("admin/orderdetails/".$order->sale_id); ?>" class="btn btn-success"> <?php echo $this->lang->line("Details");?></a>
                        <div class="dropdown">
  <button class="btn btn-success dropdown-toggle" type="button" data-toggle="dropdown"> <?php echo $this->lang->line("Action");?>
  <span class="caret"></span></button>
  <ul class="dropdown-menu">
    <li><a href="<?php echo site_url("admin/cancle_order/".$order->sale_id); ?>"> <?php echo $this->lang->line("Cancel");?></a></li>
        <?php if($order->status == 0){
                        echo "<li><a href='".site_url("admin/confirm_order/".$order->sale_id)."'>Confirm</a></li>";
                    }else if($order->status == 1){
                        echo "<li><a class='r_out' href='".site_url("admin/delivered_order/".$order->sale_id)."'>Out</a></li>";
                    } 
                    else if($order->status == 2){
                        echo "<li><a href='".site_url("admin/delivered_order_complete/".$order->sale_id)."'>Complete</a></li>";
                    } 
                    else if($order->status == 3){
                        echo "<li><a href='".site_url("admin/order_recover/".$order->sale_id)."'>Recover</a></li>";
                    } ?>
    <li><a class="r_del" href="<?php echo site_url("admin/delete_order/".$order->sale_id); ?>"> <?php echo $this->lang->line("Delete");?></a></li>
  </ul>
</div>
                    </td>
                </tr>
            <?php
          }
          ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <!-- end content-->
                            </div>
                            <!--  end card  -->
                        </div>
                        <!-- end col-md-12 -->
                    </div>
                    <!-- end row -->
                </div>
            </div>
            <!--footer -->
            <?php  $this->load->view("admin/common/footer"); ?>
        </div>
    </div>
    <!--fixed -->
    <?php  $this->load->view("admin/common/fixed"); ?>
</body>
<!--   Core JS Files   -->
<script src="<?php echo base_url($this->config->item("new_theme")."/assets/js/jquery-3.1.1.min.js"); ?>" type="text/javascript"></script>
<script src="<?php echo base_url($this->config->item("new_theme")."/assets/js/jquery-ui.min.js"); ?>" type="text/javascript"></script>
<script src="<?php echo base_url($this->config->item("new_theme")."/assets/js/bootstrap.min.js"); ?>" type="text/javascript"></script>
<script src="<?php echo base_url($this->config->item("new_theme")."/assets/js/material.min.js"); ?>" type="text/javascript"></script>
<script src="<?php echo base_url($this->config->item("new_theme")."/assets/js/perfect-scrollbar.jquery.min.js"); ?>" type="text/javascript"></script>
<!-- Forms Validations Plugin -->
<script src="<?php echo base_url($this->config->item("new_theme")."/assets/js/jquery.validate.min.js"); ?>"></script>
<!--  Plugin for Date Time Picker and Full Calendar Plugin-->
<script src="<?php echo base_url($this->config->item("new_theme")."/assets/js/moment.min.js"); ?>"></script>
<!--  Charts Plugin -->
<script src="<?php echo base_url($this->config->item("new_theme")."/assets/js/chartist.min.js"); ?>"></script>
<!--  Plugin for the Wizard -->
<script src="<?php echo base_url($this->config->item("new_theme")."/assets/js/jquery.bootstrap-wizard.js"); ?>"></script>
<!--  Notifications Plugin    -->
<script src="<?php echo base_url($this->config->item("new_theme")."/assets/js/bootstrap-notify.js"); ?>"></script>
<!--   Sharrre Library    -->
<script src="<?php echo base_url($this->config->item("new_theme")."/assets/js/jquery.sharrre.js"); ?>"></script>
<!-- DateTimePicker Plugin -->
<script src="<?php echo base_url($this->config->item("new_theme")."/assets/js/bootstrap-datetimepicker.js"); ?>"></script>
<!-- Vector Map plugin -->
<script src="<?php echo base_url($this->config->item("new_theme")."/assets/js/jquery-jvectormap.js"); ?>"></script>
<!-- Sliders Plugin -->
<script src="<?php echo base_url($this->config->item("new_theme")."/assets/js/nouislider.min.js"); ?>"></script>
<!--  Google Maps Plugin    -->
<!--<script src="https://maps.googleapis.com/maps/api/js"></script>-->
<!-- Select Plugin -->
<script src="<?php echo base_url($this->config->item("new_theme")."/assets/js/jquery.select-bootstrap.js"); ?>"></script>
<!--  DataTables.net Plugin    -->
<script src="<?php echo base_url($this->config->item("new_theme")."/assets/js/jquery.datatables.js"); ?>"></script>
<!-- Sweet Alert 2 plugin -->
<script src="<?php echo base_url($this->config->item("new_theme")."/assets/js/sweetalert2.js"); ?>"></script>
<!--    Plugin for Fileupload, full documentation here: http://www.jasny.net/bootstrap/javascript/#fileinput -->
<script src="<?php echo base_url($this->config->item("new_theme")."/assets/js/jasny-bootstrap.min.js"); ?>"></script>
<!--  Full Calendar Plugin    -->
<script src="<?php echo base_url($this->config->item("new_theme")."/assets/js/fullcalendar.min.js"); ?>"></script>
<!-- TagsInput Plugin -->
<script src="<?php echo base_url($this->config->item("new_theme")."/assets/js/jquery.tagsinput.js"); ?>"></script>
<!-- Material Dashboard javascript methods -->
<script src="<?php echo base_url($this->config->item("new_theme")."/assets/js/material-dashboard.js"); ?>"></script>
<!-- Material Dashboard DEMO methods, don't include it in your project! -->
<script src="<?php echo base_url($this->config->item("new_theme")."/assets/js/demo.js"); ?>"></script>
<!-- Lightbox -->
<script type="text/javascript">
    $(document).ready(function() {
        $('#datatables').DataTable({
            "pagingType": "full_numbers",
            "lengthMenu": [
                [10, 25, 50, -1],
                [10, 25, 50, "All"]
            ],
            responsive: true,
            language: {
                search: "_INPUT_",
                searchPlaceholder: "Search records",
            }
        });

         
         $("input").addClass("form-control");

        var table = $('#datatables').DataTable();
        // Edit record
        table.on('click', '.edit', function() {
            $tr = $(this).closest('tr');

            var data = table.row($tr).data();
            alert('You press on Row: ' + data[0] + ' ' + data[1] + ' ' + data[2] + '\'s row.');
        });

        // Delete a record
        table.on('click', '.remove', function(e) {
            $tr = $(this).closest('tr');
            table.row($tr).remove().draw();
            e.preventDefault();
        });

        //Like record
        table.on('click', '.like', function() {
            alert('You clicked on Like button');
        });

        $('.card .material-datatables label').addClass('form-group');
        setTimeout(function() {
            $(".sorting_asc").trigger('click');
        }, 2000);
    });
</script>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.22/css/jquery.dataTables.min.css">
<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.5.2/js/dataTables.buttons.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.html5.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#example').DataTable( {
                dom: 'Bfrtip',
                buttons: [
                    'copyHtml5',
                    'excelHtml5',
                    'csvHtml5',
                    'pdfHtml5'
                ]
            } );
        $(document).on('click','.r_out',function(){
            e.preventDefault();
            var ourl=$(this).attr('href');
            $('.label-info').text('Out');
            $(this).parent().remove();
           $.ajax({
                url : ourl,
                type : 'POST',
                success : function(data){
                    $(this).parent().remove();
                }
            });
        });
        $(document).on('click','.r_del',function(e){
            e.preventDefault();
            var durl=$(this).attr('href');
             $(this).parent().parent().parent().parent().parent().remove();
            $.ajax({
                url : durl,
                type : 'POST',
                success : function(data){
                    $(this).parent().parent().parent().parent().parent().remove();
                     $("#deleted").show();
                }
            });
        });
        } );
    </script>

   <link rel="stylesheet" href="<?php echo base_url($this->config->item("theme_admin")."/plugins/daterangepicker/daterangepicker-bs3.css"); ?>">
    <script src="<?php echo base_url($this->config->item("theme_admin")."/plugins/daterangepicker/daterangepicker.js"); ?>"></script>
    <script>
    $(function () {
        $('#daterange-btn').daterangepicker(
            {
              ranges: {
                'Today': [moment(), moment()],
                'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                'This Month': [moment().startOf('month'), moment().endOf('month')],
                'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
              },
              startDate: moment().subtract(29, 'days'),
              endDate: moment()
            },
        function (start, end) {
          $('#reportrange').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
          $('#date_range_lable').val(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
          $('#date_range_field').val(start.format('YYYY-MM-D')+','+end.format('YYYY-MM-D'));
        }
        );
    });
    </script>

</html>