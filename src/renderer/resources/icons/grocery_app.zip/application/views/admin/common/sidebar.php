<?php 
if($this->session->userdata('language') == "arabic")
{
    echo "<style> .main-panel.ps-container.ps-theme-default.ps-active-y { float: left; } </style>";
?>

<?php
}
?>

<div class="sidebar" data-active-color="blue"  data-background-color="white"
<?php if($this->session->userdata('language') == "arabic"){ echo 'style="left: unset;right: 0"'; } ?> >
            <!--
            Tip 1: You can change the color of active element of the sidebar using: data-active-color="purple | blue | green | orange | red | rose"
            Tip 2: you can also add an image using data-image tag
            Tip 3: you can change the color of the sidebar with data-background-color="white | black"-->
           
            
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
            
            <script type="text/javascript">
	$(function(){
		$('.nav a').filter(function(){return this.href==location.href}).parent().addClass('active').siblings().removeClass('active')
		$('.nav a').click(function(){
			$(this).parent().addClass('active').siblings().removeClass('active')	
		})
	})
	</script>
          
          
            <div class="sidebar-wrapper" >

                <div class="user">
                    <h2 align="center" class="text">Grocery </h2>
                    <a href="http://chilka.in/pos" target="_blank" class="btn btn-success">POS</a>
                    <hr>
                    <div class="photo">
                        <?php 
                            $z = _get_current_user_id($this);
                            $img=$this->db->query("SELECT * FROM `users` where user_id='".$z."' ") ;
                            $image= $img->result();
                            //echo $z;
                            foreach($image as $row){
                        ?>
                        <img src="<?php echo $this->config->item('base_url').'/uploads/profile/'.$row->user_image ?>" />
                        <?php } ?>
                    </div>
                    <div class="info">
                        <a data-toggle="collapse" href="#collapseExample" class="collapsed">
                            <?php echo ""._get_current_user_name($this)."" ; ?>
                            <b class="caret"></b>
                        </a>
                        <div class="collapse" id="collapseExample">
                            <ul class="nav">
                                <!--li>
                                    <a href="#">My Profile</a>
                                </li-->
                                <li>
                                    <a href="<?php echo site_url("users/edit_mainuser/"._get_current_user_id($this)); ?>" ><?php echo $this->lang->line("Edit Profile");?></a>
                                </li>
                                <li>
                                    <a href="<?php echo site_url("admin/signout") ?>" ><?php echo $this->lang->line("Log Out");?></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <ul class="nav ">
                    <li>
                        <a href="<?php echo site_url("admin/dashboard"); ?>" >
                            <i class="material-icons">dashboard</i>
                            <p><?php echo $this->lang->line("dashboard");?></p>
                        </a>
                    </li>
                    <li class="">
                        <a href="<?php echo site_url("admin/registers"); ?>">
                            <i class="material-icons">smartphone</i>
                            <p><?php echo $this->lang->line("App Users");?></p>
                        </a>
                    </li>
                    <li class="">
                        <a href="<?php echo site_url("admin/listcategories"); ?>">
                            <i class="material-icons">category</i>
                            <p><?php echo $this->lang->line("Categories");?></p>
                        </a>
                    </li>
                    <li class="">
                        <a href="<?php echo site_url("admin/socity"); ?>">
                            <i class="material-icons">pin_drop</i>
                            <p><?php echo $this->lang->line("Socity");?></p>
                        </a>
                    </li>
                    <li class="">
                        <a href="<?php echo site_url("admin/open_app"); ?>">
                            <i class="material-icons">inbox</i>
                            <p>Message</p>
                        </a>
                    </li>
                    <li class="">
                        <a href="<?php echo site_url("admin/city"); ?>">
                            <i class="material-icons">map</i>
                            <p><?php echo $this->lang->line("City");?></p>
                        </a>
                    </li>
                    <li class="">
                        <a href="<?php echo site_url("admin/set_limit"); ?>">
                            <i class="material-icons"> star</i>
                            <p>Top Selling , Limit</p>
                        </a>
                    </li>
                    <li class="">
                        <a href="<?php echo site_url("files"); ?>">
                            <i class="material-icons">folder</i>
                            <p>Uploads Manager</p>
                        </a>
                    </li>
                    <li>
                        <a data-toggle="collapse" href="#productee">
                             <i class="material-icons"> restaurant_menu</i>
                            <p><?php echo $this->lang->line("Products");?>
                                <b class="caret"></b>
                            </p>
                        </a>
                        <div class="collapse" id="productee">
                            <ul class="nav">
                                <li>
                                    <a href="<?php echo site_url("admin/products"); ?>">List Products</a>
                                </li>
                                <li>
                                    <a href="<?php echo site_url("admin/add_products"); ?>">Add Products</a>
                                </li>
                            </ul>
                        </div>
                    </li>

                    <li>
                        <a data-toggle="collapse" href="#pagesExamples">
                            <i class="material-icons">alarm</i>
                            <p><?php echo $this->lang->line("Delivery Schedule Hours");?>
                                <b class="caret"></b>
                            </p>
                        </a>
                        <div class="collapse" id="pagesExamples">
                            <ul class="nav">
                                <li>
                                    <a href="<?php echo site_url("admin/time_slot"); ?>"> <?php echo $this->lang->line("Time Slot");?></a>
                                </li>
                                <li>
                                    <a href="<?php echo site_url("admin/closing_hours"); ?>"><?php echo $this->lang->line("Closing Hours");?></a>
                                </li>
                            </ul>
                        </div>
                    </li>
                    <li class="">
                        <a href="<?php echo site_url("admin/add_purchase"); ?>">
                            <i class="material-icons">restore_from_trash</i>
                            <p><?php echo $this->lang->line("Stock Update");?></p>
                        </a>
                    </li>
                    <li class="">
                        <a href="<?php echo site_url("admin/orders"); ?>">
                            <i class="material-icons">play_for_work</i>
                            <p><?php echo $this->lang->line("Orders");?></p>
                        </a>
                    </li>
                    <li>
                        <a data-toggle="collapse" href="#StoreManagement">
                            <i class="material-icons">store_mall_directory</i>
                            <p><?php echo $this->lang->line("Store Management");?>
                                <b class="caret"></b>
                            </p>
                        </a>
                        <div class="collapse" id="StoreManagement">
                            <ul class="nav">
                                <li>
                                    <a href="<?php echo site_url("users"); ?>"> <?php echo $this->lang->line("List Store Users");?></a>
                                </li>
                            </ul>
                        </div>
                    </li>
                    <li>
                        <a data-toggle="collapse" href="#Pages">
                            <i class="material-icons">file_copy</i>
                            <p><?php echo $this->lang->line("Pages");?>
                                <b class="caret"></b>
                            </p>
                        </a>
                        <div class="collapse" id="Pages">
                            <ul class="nav">
                                <li>
                                    <a href="<?php echo site_url("admin/allpageapp"); ?>"> <?php echo $this->lang->line("List");?></a>
                                </li>
                            </ul>
                        </div>
                    </li>
                    <li class="">
                        <a href="<?php echo site_url("admin/declared_rewards"); ?>">
                            <i class="material-icons">stars</i>
                            <p><?php echo $this->lang->line("Declared Reward Value");?></p>
                        </a>
                    </li>
                    <li class="">
                        <a href="<?php echo site_url("admin/setting"); ?>">
                            <i class="material-icons">timeline</i>
                            <p>Manage Values</p>
                        </a>
                    </li>
                    <li class="">
                        <a href="<?php echo site_url("admin/stock"); ?>">
                            <i class="material-icons">perm_data_setting</i>
                            <p><?php echo $this->lang->line("Stock");?></p>
                        </a>
                    </li>
                    <li class="">
                        <a href="<?php echo site_url("admin/notification"); ?>">
                            <i class="material-icons">notifications_active</i>
                            <p><?php echo $this->lang->line("Notification");?></p>
                        </a>
                    </li>
                    <li>
                        <a data-toggle="collapse" href="#Slider">
                            <i class="material-icons">perm_media</i>
                            <p><?php echo $this->lang->line("Slider");?>
                                <b class="caret"></b>
                            </p>
                        </a>
                        <div class="collapse" id="Slider">
                            <ul class="nav">
                                <li>
                                    <a href="<?php echo site_url("admin/listslider"); ?>"><?php echo $this->lang->line("Main Slider");?></a>
                                </li>
                                <li>
                                    <a href="<?php echo site_url("admin/banner"); ?>"><?php echo $this->lang->line("Secondary Slider");?></a>
                                </li>
                                <li>
                                    <a href="<?php echo site_url("admin/banner_2"); ?>">2nd Banner</a>
                                </li>
                                <li>
                                    <a href="<?php echo site_url("admin/feature_banner"); ?>"><?php echo $this->lang->line("Feature Brand Slider");?></a>
                                </li>
                            </ul>
                        </div>
                    </li>
                    <li>
                        <a href="<?php echo site_url("admin/coupons"); ?>">
                            <i class="material-icons">theaters</i>
                            <p><?php echo $this->lang->line("Coupons");?></p>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo site_url("admin/dealofday"); ?>">
                            <i class="material-icons">date_range</i>
                            <p><?php echo $this->lang->line("Deal Products");?></p>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo site_url("admin/mobile_number"); ?>">
                            <i class="material-icons">phonelink_setup</i>
                            <p>App Mobile No.</p>
                        </a>
                    </li>
                    
                    <li>
                        <a href="<?php echo site_url("admin/help"); ?>">
                            <i class="material-icons">info</i>
                            <p><?php echo $this->lang->line("Raise a Ticket");?></p>
                        </a>
                    </li>
                </ul>
            </div>
        </div>