<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<style>
    .wrapper
    {
        height:unset !important;
    }
</style>

<nav class="navbar transparent navbar-inverse navbar-absolute">
                <div class="container-fluid">
                    <div class="navbar-minimize">
                        <button id="minimizeSidebar" class="btn btn-round btn-white btn-fill btn-just-icon">
                            <i class="material-icons visible-on-sidebar-regular">more_vert</i>
                            <i class="material-icons visible-on-sidebar-mini">view_list</i>
                        </button>
                    </div>
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="#"  style="color: white;"> <?php echo $this->lang->line("Dashboard");?> </a>
                    </div>
                    
                    
                    <div class="collapse navbar-collapse">
                        <ul class="nav navbar-nav navbar-right">
                            <li>
                                <a href="dashboard" class="dropdown-toggle" data-toggle="dropdown" style="color: white;">
                                    <i class="material-icons">dashboard</i>
                                    <p class="hidden-lg hidden-md">Dashboard</p>
                                </a>
                            </li>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown"  style="color: white;">
                                    <i class="material-icons"></i>
                                       
                                    <i class="material-icons"></i><?php echo ($this->session->set_userdata('language,english')); echo "en";  ?>
                                    <i class="material-icons"></i>
                                    <!--<span class="notification">5</span>-->
                                    <p class="hidden-lg hidden-md">
                                        Notifications
                                        <b class="caret"></b>
                                    </p>
                                </a>
                                
                            </li>
                           
                            <li class="separator hidden-lg hidden-md"></li>
                        </ul>
                        
                    </div>
                    
                    
                </div>
            </nav>


            <div class="content">
                <div class="container-fluid">
                     <?php
            if (file_exists("install/index.php")) {
                echo '<div class="alert alert-danger">Install Folder must be deleted
                <a class="btn btn-success active" href="'.base_url("index.php/Admin/delete_install/").'" style="background: linear-gradient(50deg, red, gray);" datacolor="gr1"><i class="fa fa-trash"></i> Delete Folder</a>
                </div>';
             } else{
                //echo "1";
             }
            ?>
