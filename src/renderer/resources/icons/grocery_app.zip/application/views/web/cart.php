<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title><?php echo $this->config->item('company_title');  ?> | Home</title>
	<?php $this->load->view('commonn/html.head.php'); ?>
</head>
<body>
	<?php $this->load->view('commonn/navabr.php'); ?>

	<div class="text-center" style="background-color: white;">
			<table id="data" class="table table-no-bordered table-hover">
	    <tr>
	        <th>Image</th>
	        <th>Product Name</th>
	        <th>Qty</th>
	        <th>Price</th>
	        <th>Total</th>
	        <th>Action</th>
	    </tr>
	</table>
	<script>
		$.ajax({
	    url: '<?php echo $this->config->item('base_url');?>index.php/cart/view_cartjson',
	    type: "get",
	    dataType: "json",
   
	    success: function(data) {
	        drawTable(data);
	    }
		});

		function drawTable(data) {
		    for (var i = 0; i < data.length; i++) {
		        drawRow(data[i]);
		    }
		}

		function drawRow(rowData) {
		    var row = $("<tr />")
		    $("#data").append(row); 
		    row.append($("<td> <img style='width:50px; height:50px;' src='<?php echo $this->config->item('base_url');?>uploads/products/" + rowData.product_image + "'></td>"));
		    row.append($("<td>" + rowData.product_name + "</td>"));
		    row.append($("<td>" + rowData.qty + "</td>"));
		    row.append($("<td>" + rowData.price + "</td>"));
		    row.append($("<td>" + rowData.total_product_amount + "</td>"));
		    row.append($("<td> <a class='btn btn-danger' href='<?php echo $this->config->item('base_url');?>index.php/cart/delete_from_cart/" + rowData.cart_id + "'><i class='fa fa-delete'></i>Delete</a></td>"));
		}
	</script>
	</div>
</body>
</html>