<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title><?php echo $this->config->item('app_name');  ?> | Home</title>
	<?php $this->load->view('web/commonn/html.head.php'); ?>
</head>
<body>
	<?php $this->load->view('web/commonn/navabr.php'); ?>

	<div class="text-center">
			<?php
			$data["error"] = "";
		    $data["active"] = "listcat";
		    $data["allcat"] = $this->category_model->get_categories();
		    $this->load->view('web/commonn/cat',$data); 
			?>
	</div>
</body>
</html>