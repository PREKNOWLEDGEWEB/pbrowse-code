<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title><?php echo $this->config->item('company_title');  ?> | Home</title>
	<?php $this->load->view('web/commonn/html.head.php'); ?>
</head>
<body>
	 
	<?php $this->load->view('web/commonn/navabr.php'); ?>
	<?php 
       echo $this->session->flashdata('message'); 
       
     ?>
     
     <div class="row" style="margin-left: 10%; margin-right: 10%;">
	<?php foreach($products as $product){ ?>
		<div class="col-sm-2">
		<div class="card">
			<a href="<?php echo $this->config->item('base_url'); ?>index.php/home/product_detail/<?php echo $product->product_id;?>">
		  <img class="img-responsive" src="<?php echo $this->config->item('base_url');  ?>uploads/products/<?php echo $product->product_image; ?>" class="card-img-top" alt="<?php echo $product->product_name; ?>" style="width: 99%; height: 85%;">
		</a>
		  <div class="card-body">
		    <h5 class="card-title" style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis;"><?php echo $product->product_name; ?></h5>
		    <p class="card-text text text-danger">MRP : <?php echo $this->config->item('currency');  ?>:<?php echo $product->mrp; ?></p>
		    <p class="card-text text text-success">Price per <?php echo $product->unit_value; echo $product->unit; ?> is <?php echo $this->config->item('currency');  ?>:<?php echo $product->price; ?> </p>
		    <form action="<?php echo $this->config->item('base_url'); ?>index.php/cart/add" method="post">
		    	<input type="hidden" name="id" value="<?php echo $product->product_id;?> ">
		    	<input type="number" name="qty" value="1" max="<?php echo $product->stock;?>" class="form-control">
		    	<button type="submit" name="add_to_cart" class="btn btn-rose btn-sm btn-round"><i class="fa fa-shopping-cart"></i> Add to Cart</button>
		    </form>
		  </div>
		</div>
	</div>
	
	<?php } ?>
	</div>
</body>
</html>