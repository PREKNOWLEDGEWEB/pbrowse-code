<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title><?php echo $this->config->item('app_name');  ?> | Home</title>
	<?php $this->load->view('commonn/html.head.php'); ?>
</head>
<body>
	<?php $this->load->view('commonn/navabr.php'); ?>

	<div class="text-center">
			
            <!--   you can change the color of the filter page using: data-color="blue | purple | green | orange | red | rose " -->
          
                   
                
                           <!--  <form method="post" action="<?php echo $this->config->item('base_url').'index.php/account/login2' ?>">
                           
                                <div class="card card-login">
                                    <div class="card-header text-center" data-background-color="blue">
									    <h3 class="card-title" style="line-height:3px">Account<h3>
                                        <h4 >Login</h4>
                                       
                                    </div>
                                    
                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                <i class="material-icons">email</i>
                                            </span>
                                            <div class="form-group label-floating">
                                                <label class="control-label">Email</label>
                                                <input type="email" name="user_email" class="form-control" id="email">
                                            </div>
                                        </div>
                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                <i class="material-icons">lock_outline</i>
                                            </span>
                                            <div class="form-group label-floating">
                                                <label class="control-label">Password</label>
                                                <input type="password" name="password" class="form-control" id="password">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="footer text-center">
                                        <button type="submit" class="btn btn-rose btn-round" id="logintoapp">Signin</button>
                                    </div>
                                </div>
                            </form> -->

<form action="<?php echo $this->config->item('base_url').'index.php/account/login2' ?>" method="post" id="fup1">

  <div class="container">
    <label for="user_email"><b>Email</b></label>
    <input type="email" placeholder="Enter Email" name="user_email" required class="form-control">

    <label for="password"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="password" required class="form-control">

    <button type="submit" class="btn btn-rose btn-round">Login</button>
  </div>

  <div class="container" style="background-color:#f1f1f1">
    
  </div>
</form>


<style >
    /* Bordered form */
#fup1 {
  border: 3px solid #f1f1f1;
}
/* Add a hover effect for buttons */
button:hover {
  opacity: 0.8;
}

/* Extra style for the cancel button (red) */
.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}

/* Center the avatar image inside this container */
.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
}

/* Avatar image */
img.avatar {
  width: 40%;
  border-radius: 50%;
}

/* Add padding to containers */
.container {
  padding: 16px;
}

/* The "Forgot password" text */
span.psw {
  float: right;
  padding-top: 16px;
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
    display: block;
    float: none;
  }
  .cancelbtn {
    width: 100%;
  }
}
</style>
                       
            
</body>
</html>