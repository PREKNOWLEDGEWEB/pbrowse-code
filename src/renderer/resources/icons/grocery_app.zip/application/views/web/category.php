<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title><?php echo $this->config->item('company_title');  ?> | Home</title>
	<?php $this->load->view('web/commonn/html.head.php'); ?>
</head>
<body>
	<?php $this->load->view('web/commonn/navabr.php'); ?>

	<div class="text-center">
			
	</div>
</body>
</html>