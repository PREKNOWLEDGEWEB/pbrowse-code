<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title><?php echo $this->config->item('app_name');  ?> | Home</title>
	<?php $this->load->view('commonn/html.head.php'); ?>
</head>
<body>
	<?php $this->load->view('commonn/navabr.php'); ?>
	<h1 align=center>
		404 Not Found
	</h1>
</body>
</html>