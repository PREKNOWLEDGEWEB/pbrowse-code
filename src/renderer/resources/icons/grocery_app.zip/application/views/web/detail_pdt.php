<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title><?php echo $this->config->item('app_name');  ?> | Detail</title>
	<?php $this->load->view('commonn/html.head.php'); ?>
</head>
<body>
	 
	<?php $this->load->view('commonn/navabr.php'); ?>
	<?php 
       echo $this->session->flashdata('message'); 
       
     ?>
     
     <div class="row" style="margin-left: 10%; margin-right: 10%;">
	<?php foreach($products as $product){ ?>
		<div class="col-sm-50" style="width: 100%">
		<div class="card">
			
		  <img class="img-responsive" src="<?php echo $this->config->item('img_url');  ?>uploads/products/<?php echo $product->product_image; ?>" class="card-img-top" alt="<?php echo $product->product_name; ?>" style="width: 99%; height: 85%;">
	
		  <div class="card-body">
		    <h1 class="card-title" style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis;"><?php echo $product->product_name; ?></h1>
		    <p class="card-text text text-danger">MRP : <?php echo $this->config->item('currency');  ?>:<?php echo $product->mrp; ?></p>
		    <p class="card-text text text-success">Price per <?php echo $product->unit_value; echo $product->unit; ?> is <?php echo $this->config->item('currency');  ?>:<?php echo $product->price; ?> </p>
		    <form action="<?php echo $this->config->item('base_url'); ?>index.php/cart/add" method="post">
		    	<input type="hidden" name="id" value="<?php echo $product->product_id;?> ">
		    	<input type="number" name="qty" value="1" max="<?php echo $product->stock;?>" class="form-control">
		    	<button type="submit" name="add_to_cart" class="btn btn-rose btn-lg btn-round"><i class="fa fa-shopping-cart"></i> Add to Cart</button>
		    </form>
		  </div>
		</div>
	</div>
	
	<?php } ?>
	</div>
</body>
</html>