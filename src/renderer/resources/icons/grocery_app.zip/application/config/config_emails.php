<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$config['default_email'] = "support@chilka.in";
$config['email_host'] = "support@chilka.in";
$config['default_email_title'] = "Registration Confirm";
?>