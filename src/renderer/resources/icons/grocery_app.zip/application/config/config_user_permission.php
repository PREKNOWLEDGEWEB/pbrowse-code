<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$config['controllers'] = array("admin"=>array("dashboard","user_types"));
?>