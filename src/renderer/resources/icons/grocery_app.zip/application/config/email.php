<?php
// $config['protocol'] = "smtp";
// $config['smtp_host'] = "ssl://smtp.gmail.com";
// $config['smtp_port'] = "465";
// $config['smtp_user'] = "shreeharitest@gmail.com";  // First Less secure apps enable on security your email : https://myaccount.google.com/lesssecureapps?pli=1 
// $config['smtp_pass'] = "password here";
// $config['charset'] = "utf-8";
// $config['mailtype'] = "html";
// $config['newline'] = "\r\n";

defined('BASEPATH') OR exit('No direct script access allowed');
// $config['default_email'] = "noreply@thecodecafe.in";
// $config['email_host'] = "noreply@thecodecafe.in";
// $config['default_email_title'] = "Registration Confirm";

 
//$this->email->initialize($config);
?>